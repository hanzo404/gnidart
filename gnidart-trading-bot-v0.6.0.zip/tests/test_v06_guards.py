"""تست‌های v0.6 — گارد اکوییتی زنده (شناور) + کلید توقف پیش‌ثبت‌شده.

مبنای پیش‌ثبت (WFO_LAB_REPORT، 2026-09-18): بدترین افت تاریخی G6 =
‎−16.9R → آستانهٔ هالت 25R (‎=12.5٪ با ریسک ۰.۵٪)؛ یا r̄ پنجرهٔ
۱۲ماهه < 0 با n≥40. هالت فقط با acknowledge انسانی برداشته می‌شود
و قله/هالت از ری‌استارت زنده می‌ماند.
"""
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import pandas as pd

from bot.config import BotConfig
from bot.live.runner import LiveRunner, PaperPosition
from bot.risk.kill_switch import KillSwitch

from tests.test_live_runner import make_runner


def next_bar(bars: pd.DataFrame, close: float) -> pd.DataFrame:
    """یک کندل M15 تخت با close دلخواه به انتهای bars می‌چسباند."""
    t = pd.Timestamp(bars["time"].iloc[-1]) + pd.Timedelta(minutes=15)
    row = {"time": t, "open": close, "high": close, "low": close,
           "close": close, "tick_volume": 100.0, "spread": 14.0}
    return pd.concat([bars, pd.DataFrame([row])], ignore_index=True)


def paper(entry: float, pad: float = 500.0) -> PaperPosition:
    """پوزیشن کاغذی با استاپ دور — تا در همان کندل استاپ نخورد."""
    return PaperPosition(id="paper", direction=1, units=0.01, entry=entry,
                         stop=entry - pad, target=entry + 4 * pad,
                         risk_usd=pad)


class TestKillSwitchUnit(unittest.TestCase):
    def test_dd_halt_touch_ack_and_rebase(self):
        ks = KillSwitch(dd_threshold_pct=0.125)
        self.assertIsNone(ks.on_equity(3000.0))          # قله ثبت شد
        self.assertIsNone(ks.on_equity(2990.0))          # افت ۰.۳٪ — رد
        ev = ks.on_equity(2600.0)                        # 13.3٪ ≥ 12.5٪ → لمس=هالت
        self.assertIsNotNone(ev)
        self.assertEqual(ev.kind, "dd_halt")
        self.assertTrue(ks.halted)
        self.assertIsNone(ks.on_equity(2500.0))          # رویداد تکراری نه
        ack = ks.acknowledge()
        self.assertIsNotNone(ack)
        self.assertEqual(ack.kind, "ack")
        self.assertFalse(ks.halted)
        self.assertIsNone(ks.on_equity(2500.0))          # قله re-base → بدون رویداد
        self.assertIsNotNone(ks.on_equity(2100.0))       # 16٪ از قلهٔ جدید

    def test_state_roundtrip_keeps_halt_alive(self):
        ks = KillSwitch(dd_threshold_pct=0.125)
        ks.on_equity(3000.0)
        ks.on_equity(2600.0)
        self.assertTrue(ks.halted)
        ks2 = KillSwitch(dd_threshold_pct=0.125)
        ks2.restore(ks.state())
        self.assertTrue(ks2.halted)
        self.assertEqual(ks2.state()["peak"], 3000.0)

    def test_rolling_window_rules(self):
        now = datetime(2026, 9, 18)
        rows = [{"opened_at": (now - timedelta(days=30)).isoformat(),
                 "r_multiple": -0.1, "symbol": "XAUUSD"}] * 40
        ks = KillSwitch(dd_threshold_pct=1.0, window_days=365, min_trades=40)
        ev = ks.on_trades_window(rows, now)
        self.assertIsNotNone(ev)
        self.assertEqual(ev.kind, "perf_halt")
        # قدیمی‌تر از پنجره → داوری نمی‌شوند
        old = [{"opened_at": (now - timedelta(days=800)).isoformat(),
                "r_multiple": -0.5}] * 40
        self.assertIsNone(
            KillSwitch(1.0).on_trades_window(old, now))
        # n زیر حد نصاب → سکوت (نمونهٔ کوچک داوری‌پذیر نیست)
        self.assertIsNone(
            KillSwitch(1.0).on_trades_window(rows[:39], now))
        # میانگین مثبت → بدون هالت
        pos = [{"opened_at": (now - timedelta(days=30)).isoformat(),
                "r_multiple": 0.2}] * 40
        self.assertIsNone(
            KillSwitch(1.0).on_trades_window(pos, now))

    def test_config_defaults_and_wiring(self):
        cfg = BotConfig()
        self.assertEqual(cfg.risk.kill_dd_r, 25.0)
        self.assertEqual(cfg.risk.kill_window_days, 365)
        self.assertEqual(cfg.risk.kill_min_trades, 40)
        with tempfile.TemporaryDirectory() as tmp:
            r, _, _, _ = make_runner(tmp, dry_run=True)
            self.assertAlmostEqual(r.kill_switch._threshold,
                                   25.0 * 0.005)       # 12.5٪


class TestFloatingEquityGuard(unittest.TestCase):
    """افسانهٔ ۵ گزارش KX: گاردها اکوییتی زنده (شامل شناور) می‌بینند —
    لمس = نقض. تا v0.5.8.2 زیان شناور از دید همهٔ گاردها نامرئی بود."""

    def test_monthly_breaker_sees_floating_loss(self):
        with tempfile.TemporaryDirectory() as tmp:
            r, provider, _, journal = make_runner(tmp, dry_run=True)
            r.on_cycle()
            base = float(r.state["sleeve_base"])        # 3000$
            self.assertAlmostEqual(base, 3000.0)
            r.paper = paper(2000.0)
            # close = 1790 → شناور = (1790−2000)×0.01×100 = −210$ (−7٪)
            provider.bars = next_bar(provider.bars, 1790.0)
            recorded = []
            with patch.object(journal, "record_equity",
                              side_effect=lambda ts, eq, **kw: recorded.append(eq)):
                r.on_cycle()
            self.assertAlmostEqual(recorded[-1], base - 210.0, places=0)
            self.assertTrue(r.breaker.halted)           # −7٪ ≥ سقف ماهانه ۶٪
            self.assertFalse(r.kill_switch.halted)      # −7٪ < 12.5٪ → هنوز نه

    def test_floating_loss_triggers_kill_switch_and_survives_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            r, provider, _, journal = make_runner(tmp, dry_run=True)
            r.on_cycle()
            r.paper = paper(2000.0)
            # close = 1590 → شناور = −410$ → equity 2590 = −13.7٪ از قله 3000
            provider.bars = next_bar(provider.bars, 1590.0)
            kinds = []
            with patch.object(journal, "record_breaker_event",
                              side_effect=lambda ts, kind, *a, **kw: kinds.append(kind)):
                r.on_cycle()
            self.assertTrue(r.kill_switch.halted)
            self.assertIn("dd_halt", kinds)
            # گیت ورود: کلید توقف قبل از هر گیت دیگری
            h4 = provider.candles("H4", 150)
            action = r._maybe_enter(provider.bars, h4,
                                    pd.Timestamp("2026-06-08 12:00"),
                                    pd.Timestamp("2026-06-08 15:00"), 2590.0)
            self.assertIn("کلید توقف", action)
            # ری‌استارت: هالت و قله زنده می‌مانند
            r2, _, _, _ = make_runner(tmp, dry_run=True)
            self.assertTrue(r2.kill_switch.halted)
            self.assertEqual(r2.kill_switch.state()["peak"], 3000.0)
            # رفع فقط با بازبینی انسانی + re-base قله
            r2.acknowledge_kill()
            self.assertFalse(r2.kill_switch.halted)
            self.assertIsNone(r2.kill_switch.state()["peak"])

    def test_rolling_12m_halt_from_journal(self):
        with tempfile.TemporaryDirectory() as tmp:
            r, provider, _, journal = make_runner(tmp, dry_run=True)
            r.on_cycle()
            now = datetime.now()
            for _ in range(40):
                t = now - timedelta(days=200)
                tid = journal.open_trade(
                    opened_at=t, symbol="XAUUSD", direction=1,
                    strategy="t", grade="A", entry=1.0, stop=1.0,
                    target=1.0, size_units=0.01, regime="TREND_UP",
                    features={}, reason="t")
                journal.close_trade(tid, t + timedelta(hours=1), 1.0, -0.2)
            provider.bars = next_bar(
                provider.bars, float(provider.bars["close"].iloc[-1]))
            r.on_cycle()
            self.assertTrue(r.kill_switch.halted)
            self.assertIn("پنجرهٔ", r.kill_switch.reason)


if __name__ == "__main__":
    unittest.main()
