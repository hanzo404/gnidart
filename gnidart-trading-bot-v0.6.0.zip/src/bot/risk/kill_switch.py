"""کلید توقف پیش‌ثبت‌شده — v0.6 (۱۸ سپتامبر ۲۰۲۶).

چرا این ماژول وجود دارد؟
    بریکر ماهانه هر ماه صفر می‌شود و رشته‌باخت‌ها بعد از چند برد ریست؛
    هیچ‌کدام «افتِ کندِ چندماهه از قله» را نمی‌بینند. WFO_LAB نشان داد
    G6 در ۲۰۲۶-۰۳→۰۹ در بدترین افت تاریخش بود (−16.9R) — گاردی لازم است
    که کل عمر آستین را از قله ببیند و فقط با بازبینی انسانی باز شود.

قاعدهٔ پیش‌ثبت‌شده (قبل از پیاده‌سازی، WFO_LAB_REPORT):
    ۱) افت اکوییتی زنده (تحقق‌یافته + شناور) از قله ≥ 25R
       (٪ آستانه = kill_dd_r × risk_per_trade؛ پیش‌فرض 25 × 0.5٪ = 12.5٪
       = ۱.۵ برابرِ بدترین افت تاریخی 16.9R)
    ۲) یا: r̄ پنجرهٔ غلتان ۱۲ماهه < 0 با n ≥ 40 معاملهٔ بسته‌شده

هر دو = هالت ورود (خروج/SL/TP سروری دست نمی‌خورند). برداشتن هالت فقط
با acknowledge() انسانی — که قله را عمداً re-base می‌کند: هر ack یک
تصمیم مستندِ «از اینجا می‌شماریم» است، وگرنه بلافاصله دوباره هالت می‌شد.

نکتهٔ دامو (min-lot force): در حساب کوچک با فاصلهٔ استاپ دور، ریسکِ
موثرِ هر معامله می‌تواند از risk_per_trade بیشتر شود؛ آستانهٔ ٪یِ این
کلید همان 25R طراحی باقی می‌ماند ولی بر حسب R موثر محافظه‌کارانه‌تر
(تنگ‌تر) عمل می‌کند — برای دمو، جهتِ امن است.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional

import pandas as pd


@dataclass(frozen=True)
class KillEvent:
    """رویداد قابل ثبت در ژورنال — ربات باید بتواند توضیح دهد چرا ایستاد."""

    ts: datetime
    kind: str        # dd_halt | perf_halt | ack
    detail: str


class KillSwitch:
    """موجودیت stateful — یک نمونه به ازای هر آستین (سیمبل).

    قله (peak) روی «اکوییتی زندهٔ همان آستین» ردیابی می‌شود و در
    state.json ذخیره می‌شود؛ ری‌استارت ربات آن را فراموش نمی‌کند.
    """

    def __init__(self, dd_threshold_pct: float, window_days: int = 365,
                 min_trades: int = 40) -> None:
        assert 0 < dd_threshold_pct <= 1.0
        assert window_days > 0 and min_trades > 0
        self._threshold = float(dd_threshold_pct)
        self._window_days = int(window_days)
        self._min_trades = int(min_trades)
        self._peak: Optional[float] = None
        self._halted = False
        self._reason = ""

    # ------------------------------------------------------------------ #
    # به‌روزرسانی وضعیت
    # ------------------------------------------------------------------ #
    def on_equity(self, equity: float,
                  ts: Optional[datetime] = None) -> Optional[KillEvent]:
        """هر چرخه با اکوییتی زنده صدا زده می‌شود؛ لمس آستانه = هالت."""
        if self._halted or equity is None or equity <= 0:
            return None
        if self._peak is None or equity > self._peak:
            self._peak = float(equity)
            return None
        dd = (self._peak - equity) / self._peak
        if dd >= self._threshold:
            self._halted = True
            self._reason = (f"افت {dd:.1%} ≥ {self._threshold:.1%} از قلهٔ "
                            f"{self._peak:,.0f}$")
            return KillEvent(ts or datetime.now(), "dd_halt",
                             f"کلید توقف (افت): {self._reason} — پیش‌ثبت 25R")
        return None

    def on_trades_window(self, rows: list,
                         now) -> Optional[KillEvent]:
        """rows: خروجی journal.recent_trades (dict با opened_at/r_multiple).

        فقط معاملات «همین آستین» داخل پنجرهٔ غلتان داوری می‌شوند؛
        فیلتر سیمبل بر عهدهٔ فراخوان است (ژورنال بین آستین‌ها مشترک است).
        """
        if self._halted or not rows:
            return None
        cutoff = pd.Timestamp(now) - pd.Timedelta(days=self._window_days)
        rs: list[float] = []
        for row in rows:
            ts = row.get("opened_at") if isinstance(row, dict) else None
            if ts is None:
                continue
            try:
                if pd.Timestamp(ts) < cutoff:
                    continue
            except (TypeError, ValueError):
                continue
            rs.append(float(row.get("r_multiple") or 0.0))
        if len(rs) < self._min_trades:
            return None
        mean_r = sum(rs) / len(rs)
        if mean_r < 0:
            self._halted = True
            self._reason = (f"r̄ پنجرهٔ {self._window_days}روزه = "
                            f"{mean_r:+.3f} < 0 (n={len(rs)})")
            return KillEvent(pd.Timestamp(now).to_pydatetime(), "perf_halt",
                             f"کلید توقف (عملکرد): {self._reason}")
        return None

    def acknowledge(self, ts: Optional[datetime] = None) -> Optional[KillEvent]:
        """رفع هالت — فقط بعد از بازبینی انسانی (--ack-kill).

        قله re-base می‌شود تا شمارش از تصمیمِ امروز شروع شود.
        """
        if not self._halted:
            return None
        self._halted = False
        self._reason = ""
        self._peak = None
        return KillEvent(ts or datetime.now(), "ack",
                         "کلید توقف با بازبینی انسانی برداشته شد؛ قله re-base")

    # ------------------------------------------------------------------ #
    # پرس‌وجو + ماندگاری
    # ------------------------------------------------------------------ #
    @property
    def halted(self) -> bool:
        return self._halted

    @property
    def reason(self) -> str:
        return self._reason or "—"

    def state(self) -> dict:
        """برای live_state.json — ری‌استارت نباید قله/هالت را فراموش کند."""
        return {"peak": self._peak, "halted": self._halted,
                "reason": self._reason or None,
                "threshold_pct": self._threshold}

    def restore(self, d: dict | None) -> None:
        if not isinstance(d, dict):
            return
        self._peak = float(d["peak"]) if d.get("peak") else None
        self._halted = bool(d.get("halted", False))
        self._reason = str(d.get("reason") or "")
