"""gnidart-trading-bot — ربات فارکس خوداصلاح‌گر (فاز ۰)."""
__version__ = "0.6.0"
