---
name: kx-professional-classical-price-action-expert
description: Professional and classical price-action analysis on DT-P1 OHLC bars with explicit lineage, context, setup lifecycle, known-at control, and CANNOT_DETERMINE boundaries. Use for auditable classical chart reading, hypothesis testing, setup-state classification, and vendor-neutral implementation specifications. Do not use it to infer order flow, liquidity, participant identity, intent, profitability, or execution quality.
---

# KX Professional / Classical Price Action Expert

## Operating boundary

Use only `DT-P1`: OHLC price bars plus timestamp and session semantics. Import market-data truth from SK01 and neutral price geometry from SK02 through `assets/foundation-import-manifest.yaml`. Never silently substitute volume, trades, Footprint, Delta, CVD, quotes, L2/L3, resting liquidity, participant identity, or intent.

This Skill treats professional/classical price action as a family of source-routed practices. It does not collapse Edwards–Magee classical patterns, Nison candlestick context, Brooks bar-by-bar terminology, Grimes context-first analysis, Volman chart reading, or Bulkowski pattern taxonomies into one doctrine.

## Required workflow

1. Validate the provider, instrument, bar construction, session, timezone, adjustment, and bar-finality facts with SK01.
2. Obtain neutral bar, pivot, swing, leg, range, boundary, break, gap, and multi-timeframe geometry from SK02. Do not redefine these primitives.
3. Validate caller data and explicit parameters against `assets/caller-input-contract.yaml`, then resolve the named profiles in `assets/parameter-profile-registry.yaml`. The caller cannot supply direction, state, confirmation truth, invalidation truth, expiry truth, reset truth, Gap branch, No-Trade reason, event-profile identity, or precomputed Style-event truth. No caller-configurable tolerance or count may be implicit; confirmation/event authority and supported expiry/reset modes come only from the runtime registry.
4. Classify context as `TREND_UP`, `TREND_DOWN`, `RANGE`, `TRANSITION`, or `UNCLEAR` under a named rule profile.
5. Use `assets/runtime-authority-registry.yaml` as the sole setup-composition authority. Execute `scripts/reference_semantic_runtime.py` over ordered known-at cuts: raw DT-P1 → exact pinned Foundation objects → registered Style-event producers → Rule predicates → stateful Setup instances.
6. Evaluate BUY and SELL independently for every bidirectional Setup and return both directional results, including disconfirming evidence, expiry and invalidation.
7. Preserve SK01 time roles exactly. `timestamp` is the declared bar market-time coordinate; `known_at` is the information-availability frontier. Never require them to be equal and never compare their numeric values across clocks without an explicit provider mapping.
8. For `CONFIRMED_BARS` expiry, first execute the canonical candidate Rules over ordered known-at cuts. Retain the earliest same-instance cut where they all become true as `first_candidate_known_at`; count only same-session `CONFIRMED` bars whose `known_at` is strictly later. No candidate means no expiry. Reset remains `NOT_SUPPORTED` in v1.0.0.
9. When a full Expert-Brain comparison is requested, resolve `LTF`, `MTF`, and `HTF` under `assets/timeframe-role-registry.yaml`; derive only coarser frames under `assets/resampling-policy-registry.yaml`, or require complete explicit same-instrument frames.
10. Ask for earlier OHLC or a wider chart when more left history can resolve an affected Setup/frame. State an exact missing count only for a proved finite minimum. Re-evaluate supplied history at the same cut. If no more exists, fail closed only for the affected cell and keep it silent in synthesis.
11. Invoke the unchanged R7 runtime independently for every one of the 18 Setups in BUY and SELL on every available role. Freeze all intrinsic frame tables before calculating cross-timeframe evidence. Only evidence-eligible current cells may vote. HTF may support or conflict; it never overrides another frame.
12. Treat `user_hypothesis` only as a raw audit target. Reject caller-supplied audit/verdict fields and derive the audit from frozen Skill evidence.
13. Return only the immediate canonical next transition group and compute lifecycle completion from the ordered unique path, including distinct trigger and confirmation steps. `ACTIVE` has no next event.
14. Compute only the transparent structural ratios declared in `assets/setup-strength-score-contract.yaml`. Rank Active and Pending pools separately under `assets/ranking-contract.yaml`; preserve exact-ratio ties as co-leading reads and return `NONE` for an empty qualified pool.
15. Return evidence and alternatives before any conclusion. A pattern is a candidate, not an automatic trade instruction.

## Output contract

Return:

- data-contract and foundation status;
- lineage/variant and parameter profile;
- current context with evidence and known-at time;
- observed neutral geometry and interpreted price-action evidence;
- separate `buy_result` and `sell_result`, directional active-setup lists, and setup-instance state: `NO_SETUP`, `CANDIDATE`, `PENDING`, `ARMED`, `ACTIVE`, `INVALIDATED`, or `EXPIRED`; report `CANNOT_DETERMINE` separately as evaluation status when evidence is insufficient;
- disconfirming evidence, invalidation, expiry, and alternative interpretations;
- visual annotations defined in `assets/visual-contract.yaml`;
- explicit limitations and prohibited inferences.

For a complete three-frame Expert-Brain request, also return three independent 36-row Setup tables, the 108-cell orchestration count, per-Setup hard gates and exact structural ratios, cross-timeframe support/conflict, separate Active/Pending rankings, co-leading ties, and the final comparative assessment. A single image never receives a fabricated full-brain result.

Do not output Buy/Sell signals, position sizing, Entry/Exit instructions, SL/TP, profitability estimates, backtests, or a production trading engine.

## Truth and uncertainty rules

- A realtime/developing bar is revisable. It cannot satisfy a closed-bar rule unless the selected rule explicitly permits provisional evaluation and labels it `DEVELOPING`.
- A pivot, pattern, or higher-timeframe object is known only when its confirmation inputs are known. Never use future bars retroactively in a live-known-at answer.
- Support and resistance are parameterized regions or boundaries, not universal exact prices.
- Breakout, follow-through, retest, failure, pullback, and reversal definitions are variant-specific. No silent defaults.
- Candle names alone are insufficient. Context, location, sequence, and confirmation must be evaluated.
- OHLC pressure language is interpretive price evidence, not observed aggressor flow or liquidity.
- Missing required data yields `CANNOT_DETERMINE`, never a guessed negative.

## Resources

- Doctrine and lineage: `references/doctrine-and-lineage.md`
- Current practice: `references/current-professional-practice.md`
- Veteran workflow: `references/professional-workflow.md`
- Concepts and variants: `references/concepts-and-variants.md`
- Setup universe: `references/setups.md`
- Data boundary: `references/data-and-limitations.md`
- Engine specification: `references/engine-construction.md`
- Language implementation/parity: `references/language-implementation-parity.md`
- Source register: `references/sources.md`
- R3 adversarial audit: `references/adversarial-audit-r3.md`
- Final closure audit: `references/final-closure-audit.md`
- Frozen-product black-box audit: `references/final-product-black-box-audit.md`
- Expert-Brain orchestration: `references/expert-brain-orchestration.md`
- Final acceptance evidence for Control Room review: `assets/final-acceptance-evidence.yaml`
- Parameter/profile registry: `assets/parameter-profile-registry.yaml`
- Canonical runtime authority: `assets/runtime-authority-registry.yaml`
- Expert-Brain authority and registries: `assets/expert-brain-runtime-authority.yaml`, `assets/timeframe-role-registry.yaml`, `assets/resampling-policy-registry.yaml`, `assets/setup-history-requirement-registry.yaml`, `assets/setup-strength-score-contract.yaml`, `assets/cross-timeframe-relation-registry.yaml`, `assets/ranking-contract.yaml`
- Executable proof and branch ledgers: `assets/final-proof-matrix.yaml`, `assets/branch-coverage-ledger.yaml`, `assets/rule-coverage-ledger.yaml`
- Caller/output contracts: `assets/caller-input-contract.yaml`, `assets/ai-output-schema.yaml`
- Machine contracts: `assets/*.yaml` and `assets/build-manifest.json`
- Final product identity/acceptance: `governance/PRODUCT_IDENTITY_AND_FINAL_ACCEPTANCE.yaml`
- Product evolution lineage: `governance/PRODUCT_EVOLUTION_LINEAGE.md`
- Superseded behavior guardrails: `governance/SUPERSEDED_BEHAVIOR_REGISTER.yaml`
- Final product rulings: `governance/FINAL_PRODUCT_RULINGS.md`

Before operational use, run the targeted final gates in the build manifest. They validate structural integrity, the end-product graph, the retained R7 time/expiry contract, the 108-cell Expert-Brain grid, timeframe/resampling behavior, and exact scoring/cross-timeframe/ranking behavior.
