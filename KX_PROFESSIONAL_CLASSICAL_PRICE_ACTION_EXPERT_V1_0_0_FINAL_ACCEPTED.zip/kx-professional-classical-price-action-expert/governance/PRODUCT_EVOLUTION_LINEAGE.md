# Product Evolution Lineage — KX Professional / Classical Price Action Expert

This file preserves the engineering knowledge of the path that produced the final Skill.
It is **historical/engineering memory only**. It is not a second executable source of Trading truth.
Current executable authority remains the active registries and runtimes referenced by `SKILL.md`.

## Final product

- Product ID: `KX_PROFESSIONAL_CLASSICAL_PRICE_ACTION_EXPERT`
- Skill ID: `MF01-C01`
- Version: `1.0.0`
- State: `FINAL_ACCEPTED_LOCKED`
- Final accepted source candidate SHA-256:
  `dcce22ac098c9e8c3ae424c39171447371d120903a536bc125601cf2d91bbba0`

## Evolution

### Initial / R1 class lessons

Material failure classes found during early construction included:
- mandatory schemas could be weakened by implementation;
- setup tests could bypass actual Rule registries;
- profile semantics could remain unresolved;
- H2/L2 and other operational formalizations could exceed inspected source support;
- exact machine rules could become more precise than the authority actually allowed.

Permanent result:
- schema lock;
- actual-registry execution path;
- explicit profile authority;
- source/formalization parity;
- no invented machine precision.

### R2 class lessons

Material failures included:
- derived Style-event facts behaving as oracle-like inputs;
- lifecycle states not executed fully end-to-end;
- exact Foundation object identity insufficiently proven;
- setup saturation and certain geometry/event paths under-proven;
- metadata-only evidence being too weak for executable doctrine.

Permanent result:
`RAW DT-P1 → exact SK01/SK02 objects → Style events → Rules → lifecycle`,
exact Foundation object IDs, setup-disposition/saturation proof, and no semantic oracle input.

### R3 convergence

R3 established:
- registry-driven actual execution for all retained Setups;
- raw/Foundation contradiction fail-closed behavior;
- stored expected-result mutation resistance;
- exact Foundation stable-ID resolution;
- formula-catalog preservation and source/rights integrity.

Permanent result:
expected answers are never semantic inputs; runtime must derive the result from evidence.

### R4 class lessons

Material failures included:
- Foundation ownership contradictions;
- confirmation-profile bypass;
- advertised expiry/reset modes not truly executable;
- sell-side asymmetry;
- invalidation-authority divergence;
- weak event-value/time testing.

Permanent result:
exact owner map, bidirectional proof, executable profiles/modes, event value/time validation,
and class-wide mutation when a class defect is discovered.

### R5 → R6 single-truth closure

R6 converged the product onto one setup-composition authority:
`assets/runtime-authority-registry.yaml`.

It closed:
- caller-injected Trading answers;
- parameter ambiguity;
- decorative profile mirrors;
- cross-setup generic event fallbacks;
- runtime/profile divergence;
- unsupported reset modes;
- Gap branch ambiguity;
- unsupported deterministic No-Trade classification;
- incomplete active Rule execution proof.

Permanent result:
one runtime truth, strict caller firewall, strict parameter allowlists, internally derived event/profile identity,
bidirectional lifecycle, `CONFIRMED_BARS` expiry, and zero developer Trading-logic guess points.

### R6 → R7 runtime time / expiry closure

Two Control Room blockers were corrected:

1. `timestamp == known_at` was rejected as a universal assumption.
   Final rule:
   - `timestamp` is the declared market-time coordinate;
   - `known_at` is the information-availability frontier;
   - equality is not required;
   - unsupported cross-clock numeric ordering is prohibited.

2. Expiry was corrected from history-start anchoring to actual setup-instance anchoring.
   Final rule:
   - `first_candidate_known_at` = earliest ordered cut where canonical candidate Rules are true;
   - `CONFIRMED_BARS` expiry counts only subsequently confirmed same-instance bars strictly after that cut.

R7 became the accepted single-timeframe technical base.

### Final Expert-Brain integration

The Expert-Brain added:
- explicit LTF/MTF/HTF roles;
- deterministic coarser-frame resampling;
- 18 Setups × BUY/SELL × 3 roles = 108 independent evaluations;
- frozen per-frame results before cross-timeframe synthesis;
- transparent structural evidence ratios;
- separate Active/Pending ranking;
- no automatic HTF dominance;
- no profitability/win-rate scoring;
- no trade-action advice.

### C1 final brain correction

The final Control Room audit identified four product defects plus one Owner-required behavior.

Closed permanently:

1. **History acquisition / sufficiency**
   - no universal invented lookback;
   - use exact finite minimum only when provable;
   - otherwise determine sufficiency from actual dependency closure;
   - if more history may resolve the read, ask for a wider chart or earlier OHLC first;
   - if the user has no more history, fail closed only for the affected setup/frame.

2. **No vote from insufficient evidence**
   - an evidence-ineligible cell is unavailable for synthesis;
   - it cannot support, conflict with, rank, or appear as an alternative valid read.

3. **User hypothesis firewall**
   - caller supplies only the raw hypothesis;
   - Skill derives `MATCH`, `PARTIAL_MATCH`, `NOT_MATCH`, or `CANNOT_DETERMINE`.

4. **Canonical next event and lifecycle completion**
   - next event is the immediate next mandatory transition group;
   - lifecycle completion follows the ordered canonical path and includes distinct trigger/confirmation transitions.

## Permanent product law

Historical rejected behavior must never become active logic again.

The lineage records:
`REJECTED BEHAVIOR → WHY IT FAILED → FINAL LOCKED RULE`.

It never authorizes a historical implementation to override current runtime authority.
