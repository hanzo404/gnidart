# Final Owner / Control-Room Product Rulings

These are active product constraints for `KX_PROFESSIONAL_CLASSICAL_PRICE_ACTION_EXPERT`.

## Analysis law

1. Every configured timeframe is scanned independently before cross-timeframe synthesis.
2. Every retained setup is evaluated in both applicable directions.
3. Current analysis distinguishes Active, Pending and cannot-determine states.
4. A timeframe with insufficient evidence is silent; it does not vote support or conflict.
5. If more history may resolve an affected read, request a wider chart or earlier OHLC before fail-closed.
6. If the user has no more history, only the affected setup/frame fails closed.
7. The user's market hypothesis is audited by the Skill; it is never accepted as a ready-made verdict.
8. Pending output states the exact next required transition, not a vague list of later conditions.
9. Cross-timeframe synthesis has no automatic HTF dominance.
10. Active and Pending pools are ranked separately.
11. Ties remain co-leading valid reads; no fake winner is forced.
12. No historical win probability, profitability score, expected return, Sharpe, or PnL enters the ranking.
13. No trade-action instruction such as BUY NOW / SELL NOW / ENTER / DO NOT ENTER is authorized.
14. No production trading engine or broker execution is part of this Skill.

## Data law

Primary Data Contract: `DT-P1`.

Allowed base evidence:
- OHLC;
- timestamp/session/timeframe semantics;
- exact SK01/SK02 imported objects.

The Skill must never silently convert price-only evidence into:
- executed order flow;
- Footprint;
- Delta/CVD;
- L2/L3;
- resting book liquidity;
- participant identity;
- intent.

## Implementation law

The package must remain vendor-neutral and sufficiently explicit that a developer or capable AI can implement the declared semantics without inventing Trading logic.

Python is the executable reference harness.
Rust, C++ and Go use parity contracts.
Pine and MQL5 are capability-limited adapters and may not weaken doctrine or known-at safety.
