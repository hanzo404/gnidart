# Expert-Brain orchestration

The Expert-Brain is an orchestration layer over the immutable R7 single-timeframe runtime. It does not redefine Price Action concepts, Rules, Setup predicates, lifecycle transitions, invalidation, or expiry.

## Operating sequence

1. Validate the input mode, instrument identity, timeframe labels, session/calendar/timezone semantics, and evaluation frontier.
2. Resolve LTF/MTF/HTF roles by explicit valid caller roles, a selected source-proven mapping, or `KX_RELATIVE_5X_APPROX_V1`.
3. Derive only coarser OHLC frames. Use explicit parent buckets and SK01-compatible finality/known-at rules. Never infer a lower timeframe.
4. Evaluate history separately for every Setup, direction, and selected profile. Use a proved finite minimum where available; otherwise use the actual current dependency closure. Request more evidence before fail-closed when it can resolve the affected cell.
5. Call `scripts/reference_semantic_runtime.py` for all 18 Setup IDs and BUY/SELL on every available structured frame.
6. Freeze the three intrinsic result tables before any cross-timeframe comparison.
7. Preserve the exact R7 lifecycle substate. Normalize current `CANDIDATE`, `PENDING`, and `ARMED` states into Pending pools and `ACTIVE` into Active pools. Keep `INVALIDATED` and `EXPIRED` as terminal history.
8. Compute transparent structural evidence ratios from existing R7 Rule results. Critical predicates and data/history/known-at checks remain hard gates. A failed current-cell gate produces `CANNOT_DETERMINE` for synthesis while retaining the raw R7 substate for audit.
9. Compare frames only after the intrinsic tables are frozen. Admit only eligible current cells to support, conflict, alternatives, and ranking. Every failed cell is `UNAVAILABLE` and excluded from denominators.
10. Derive the audit of any raw `user_hypothesis` internally. Reject caller-supplied audit or verdict fields.
11. Return only the immediate canonical next transition group. Count ordered unique lifecycle conditions, including distinct trigger and confirmation steps; return `NONE` after `ACTIVE`.
12. Rank Active and Pending pools separately with the exact lexicographic comparator. Return all exact co-leaders. Return `NONE` when a qualified pool is empty.

## Input modes

`EXPLICIT_THREE_FRAME_OHLC` supplies structured R7 payloads for LTF, MTF, and HTF. All frames must represent the same instrument and compatible evaluation frontier.

`STRUCTURED_OHLC` supplies a base series. Coarser OHLC can be derived when explicit parent buckets and all resampling metadata are present. Higher-frame SK02 objects are not fabricated; a Setup without required frame-specific Foundation evidence returns `CANNOT_DETERMINE`.

`THREE_FRAME_IMAGE_PACKAGE` validates three visible-image metadata envelopes. Pixel data is not converted into hidden DT-P1/Foundation evidence by the conformance runtime.

`SINGLE_FRAME_IMAGE` permits only the requested single-frame analysis envelope and reports `TIMEFRAME_CONTEXT_INCOMPLETE` for a full Expert-Brain result.

## Strength and lifecycle

`INTRINSIC_FSS` is a rational evidence-completeness ratio, not a win probability. The numerator and denominator are retained. Rounded displays never determine rank. Trigger and confirmation progress remain separate from intrinsic evidence.

`LIFECYCLE_COMPLETION` uses the unique mandatory Rule conditions in the canonical R7 path from candidate to active. If the exact denominator is not available, the result is `CANNOT_DETERMINE`.

No output is an instruction to enter, avoid, buy, sell, place an order, or expect profit.
