# Doctrine and lineage

Professional/classical price action is not one closed doctrine. This Skill preserves six source-shaped lineages and one cross-lineage baseline.

## Classical Western chart analysis

Edwards and Magee supply the long-running classical language of trend, support/resistance, trendlines, channels, consolidation and reversal formations. Modern editions retain that scope. The useful machine boundary is structural: patterns must be constructed from declared pivots, boundaries, legs and confirmation rules. A familiar visual resemblance is not enough.

## Nison candlestick transmission

Nison's work transmitted Japanese candlestick methods to Western technical-analysis practice. The current official Nison ecosystem emphasizes that a candle pattern is only an initial observation: prior price action, trend, support/resistance, location and confirmation change its meaning. This Skill therefore never promotes a candle name directly to an actionable setup.

## Brooks bar-by-bar price action

Brooks uses a dense, proprietary vocabulary for trend/range conditions, signal bars, entries, failed breaks, pullbacks, second entries, wedges and measured moves. The inspected official glossary defines H1/L1 as one-legged pullbacks in bull/bear legs and H2/L2 as two-legged pullbacks in bull/bear moves; it also records second-reversal variants. Therefore `SET-PA-H2-L2` requires a confirmed two-legged counter-direction pullback structure and cannot be reduced to a generic count of entry attempts. The glossary separately distinguishes second-entry/second-signal terminology and describes the wedge family through three pushes, including truncated-third-push variants. These objects remain `PA-BROOKS` variants and do not become universal definitions. The Skill paraphrases the first-party terms and keeps the KX executable operationalization explicitly separate.

## Grimes context-first practice

Grimes joins discretionary chart reading with explicit market structure and statistical caution. His current public work repeatedly prioritizes context, timeframe, trend/chop distinction, waiting, and the possibility that no trade is the professional answer. This lineage is valuable for uncertainty and workflow, not for turning judgement into false numerical precision.

## Volman chart-reading lineage

Volman's books are verified bibliographically as modern price-action works, including a scalping title and a broader price-action title. Publicly accessible authoritative material does not expose enough exact rules for executable reconstruction. The lineage is registered, but any unverified rule claim is `CANNOT_DETERMINE` and cannot seed a machine rule.

## Bulkowski pattern taxonomy

Bulkowski's Wiley encyclopedias demonstrate the breadth and continued publication of chart-pattern and candlestick taxonomies. Proprietary performance statistics are not imported, and no historical ranking is converted into a universal threshold or profitability claim.

## Cross-lineage baseline

The safe intersection is narrow: validate the data; establish context; identify location and sequence; declare the variant; wait for the variant's confirmation; preserve alternatives; manage invalidation and expiry; and respect known-at time. Beyond this intersection, variants remain separate.

## Collision firewall

This Child does not redefine school-neutral pivots, swings, legs, ranges, breaks, gaps or multi-timeframe mapping owned by SK02. It does not import Market Structure, Supply-and-Demand, SMC or ICT vocabularies. Similar-looking objects are labeled with this Child's own lineage and semantics.
