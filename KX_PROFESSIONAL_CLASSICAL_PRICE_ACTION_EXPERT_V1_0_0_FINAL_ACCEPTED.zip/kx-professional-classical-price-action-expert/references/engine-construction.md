# Vendor-neutral engine construction specification

## R6 canonical runtime boundary

`assets/runtime-authority-registry.yaml` is the sole executable Setup-composition authority. An implementation validates `assets/caller-input-contract.yaml`, exact SK01/SK02 owner/version/hash provenance, registered parameters and the current known-at prefix before producing Style events or Rule outputs. It then evaluates BUY and SELL independently and serializes the directional result under `assets/ai-output-schema.yaml`. Setup-catalog lifecycle fields are generated, non-authoritative projections and may never override the registry.

`scripts/reference_semantic_runtime.py` is the registry-driven QA reference. It contains no Setup-specific or Rule-specific IDs and consumes no stored expected result. It is not a production trading engine.

## Components

The machine registry is `assets/engine-interfaces.yaml`. A conforming implementation contains independent adapters for data validation, foundation imports, time/known-at cuts, parameter profiles, context classification, path evaluation, pattern construction, setup lifecycle, variant resolution, visual output, hypothesis audit, replay and provenance.

## Determinism

Convert valid prices to integer ticks with the declared SK01 scale. Preserve explicit operation order. No floating comparison is allowed without the cataloged equality/tolerance rule. `assets/parameter-profile-registry.yaml` is the only parameter-resolution namespace. Caller-configurable tolerances and counts must be declared and strictly validated. Event-profile identity, confirmation Rule identity, reset support and expiry mode are internal runtime authority. In v1.0.0, reset is `NOT_SUPPORTED` and expiry is only `CONFIRMED_BARS`. Missing required parameters yield `CANNOT_DETERMINE`; unknown or invalid parameters yield `CANNOT_DETERMINE_WITH_INVALID_DATA`.

## Live and replay

Evaluation at time `t` may consume only records whose SK01 known-at time is no later than `t`. Developing bars and parent bars are revisionable and separately labeled. Replay must reconstruct the same information frontier, not merely iterate over final historical bars. Late corrections create a revised result with provenance; they do not rewrite the original live-known-at record.

## Language contract

Python is the reference semantic harness. Rust, C++ and Go parity vectors use integer/rational operations. Pine and MQL are `CAPABLE_WITH_LIMITS`: TradingView and MetaQuotes documentation is authoritative only for its own product-native execution, bar-finality, indexing and history-access mechanics. It is not Price Action doctrine. Chart-side subsets are valid only when session, higher-timeframe and repaint controls preserve the same semantics. No language may print fixture expected values or bypass the algorithm.

## Non-goals

The specification does not build a production trading engine, broker adapter, order manager, optimizer, backtest, profitability model or execution system.
## Executable evidence flow

The mandatory chain is `raw DT-P1 → exact SK01/SK02 objects → registered C01 Style-event producers → predicate Rule outputs → lifecycle evaluator`. Injected event maps are rejected. A supplied Foundation object requires an imported stable ID and raw references; contradiction is invalid data.

## Final Expert-Brain orchestration boundary

`scripts/reference_expert_brain_runtime.py` imports and invokes `SemanticRuntime`; it does not copy setup predicates or lifecycle transitions. The orchestration chain is `input QA → role routing → optional coarser resampling → setup-local history acquisition/sufficiency → 18×2 R7 scan per frame → frozen intrinsic tables → exact canonical ratios → evidence-eligible cross-timeframe relations → separate Active/Pending ranking → runtime-derived hypothesis audit → comparative output`.

The ten integration interfaces in `assets/engine-interfaces.yaml` have no Trading-logic choice point. A conforming port must request resolvable missing history before fail-closed, never invent a global lookback, exclude ineligible cells from synthesis, reject caller verdict injection, preserve exact canonical numerators and denominators, keep display rounding non-authoritative, and exclude timeframe size from ranking.
