# Professional workflow

## Pre-chart control

Confirm instrument identity, provider, bar type, interval, timezone, session calendar, adjustment policy, missing bars and bar finality. A screenshot without these facts can support visual description but not time/session-exact reconstruction.

## First read: environment

Read from higher to lower scope without leaking future information. Identify named context candidates: directional trend, range, transition, or unclear. Mark the strongest disconfirming read at the same time. If context depends on an unconfirmed parent bar, label it developing.

## Second read: location and path

Use SK02 geometry to locate the current bar/leg relative to confirmed boundaries, prior pivots, ranges, trendlines/channels and gaps. Then read path: impulse versus overlap, breakout versus failed breakout, pullback depth under the selected profile, tests, and follow-through.

## Setup hypothesis

Instantiate a setup only when its required context, location and sequence exist. Record its lineage, parameters, evidence, missing inputs, alternatives, invalidation, expiry and known-at time. A visually similar object that lacks one required predicate is a near miss.

## Trigger and lifecycle

`NO_SETUP` is the valid initial/disproved classification. `CANDIDATE` means the structural preconditions exist. `PENDING` means the setup awaits a defined trigger or confirmation. `ARMED` means every pre-trigger condition is satisfied. `ACTIVE` records that the declared trigger occurred; it is not an order instruction. `INVALIDATED` and `EXPIRED` are terminal for that instance. `CANNOT_DETERMINE` is an evaluation status, not a fabricated setup state.

## Veteran controls

- Separate observation from interpretation.
- State the alternative before conviction.
- Do not force a trend label in overlapping/noisy conditions.
- Do not use an unfinished bar as if it were closed.
- Do not call a price touch acceptance, liquidity or participant intent.
- Do not retrofit a pivot or pattern using bars unavailable at the decision time.
- Use no-trade/unclear as a valid professional outcome.

## Hypothesis audit

The caller supplies only raw `user_hypothesis`. The runtime rejects any supplied audit or verdict and derives the audit from frozen frame/setup/direction evidence and canonical R7 rules. The result can be `MATCH`, `PARTIAL_MATCH`, `NOT_MATCH`, or `CANNOT_DETERMINE`; it does not approve a trade.

## Expert-Brain three-frame pass

Resolve exact LTF/MTF/HTF labels before analysis. An explicit ordered same-instrument map takes priority; otherwise use only the named operational mapping registry. If coarser frames must be derived, require complete session, calendar, boundary, timestamp-label, and availability-clock metadata. Never derive a finer frame from a coarser bar series.

For each available role, execute all 18 Setups in BUY and SELL through the canonical R7 runtime, producing 36 intrinsic records per role. Apply history evidence independently. Ask for more earlier history when it can resolve the cell, and re-evaluate at the same cut if supplied. If none exists, keep only that affected cell silent. Freeze the three tables before any comparison.

Cross-timeframe synthesis describes same-Setup reinforcement, same-direction complementary evidence, opposite-direction conflict, neutrality, or unavailable context. It does not change a Setup's state or intrinsic score. Rank structurally qualified Active and Pending records in separate pools with exact ratios; ties remain visible as co-leading valid reads. The final assessment is comparative Price Action evidence, never a trade instruction.
