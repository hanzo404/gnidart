# Sources and evidence policy

The authoritative machine registers are:

- `assets/source-index.yaml`: identity, authority tier, access date, canonical URL, locator and status;
- `assets/claim-ledger.yaml`: atomic claims with source support and downstream use;
- `assets/rights-and-reuse-register.yaml`: ownership, access, reuse limits and handling;
- `assets/source-coverage-matrix.yaml`: concept/rule/setup/profile/source coverage;
- `assets/parameter-profile-registry.yaml`: source/claim-traced fixed values and explicit caller-required values;
- `assets/source-saturation-report.yaml`: discovery pass and independent second pass;
- `assets/conflict-register.yaml`: unresolved or intentionally preserved conflicts.

Search-result snippets are never evidence. Publisher/catalog pages prove bibliographic identity and high-level scope only. Exact machine rules require an accessible official text or a foundation-owned primitive. Unauthorized scans, anonymous posts and SEO summaries are rejected. Copyrighted sources are synthesized; no protected instructional passage, table or chart is copied.

Source authority is claim-relative: exchanges/platforms own their mechanics, publishers/authors own their terminology and scope, locked foundations own their semantic objects, and academic sources can support formalization/subjectivity claims without becoming doctrine authorities. `SRC-PA-016`, `SRC-PA-017` and `SRC-PA-018` are classified as official Product-Native platform mechanics (`S4`), not doctrine or independent practice evidence. Brooks H1/H2/L1/L2, second-entry and wedge claims route to exact entries in the inspected official glossary; machine predicates layered on them are labeled governed KX operational formalizations.
- `SRC-PA-023` — IG Academy, “Trends and channels”; full relevant sections inspected 2026-08-30. Used for current classical trendline/channel practice, never as a universal engine default.
