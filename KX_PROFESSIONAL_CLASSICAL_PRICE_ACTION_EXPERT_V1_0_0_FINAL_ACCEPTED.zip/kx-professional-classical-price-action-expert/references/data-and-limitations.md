# Data contract and limitations

## DT-P1

Required fields are provider/instrument identity, bar interval/construction, timestamp convention, timezone/session semantics, open, high, low, close and bar finality. Price values are converted to integer ticks only when tick size and price scale are valid.

## Foundation ownership

SK01 owns field meaning, time, session, bar construction, adjustment and known-at semantics. SK02 owns neutral geometry such as bar relations, pivots, swings, legs, ranges, boundaries, breaks, gaps and multi-timeframe mapping. This Skill consumes those objects and adds lineage-specific interpretation.

## Prohibited substitutions

OHLC does not reveal exact intrabar path, executed volume, aggressor side, Footprint, Delta, CVD, quotes, bid/ask, L2/L3, resting depth, queue, participant identity, hidden liquidity or intent. Price rejection is not proof of resting liquidity. A candle color is not observed buying/selling volume. A bar high/low is not an exact event sequence.

A classical support/resistance zone is a price-location interpretation built from SK02 geometry and an explicit tolerance. It is not a Supply-and-Demand doctrine object and does not imply unfilled orders or resting liquidity.

## Missing and invalid data

Missing required fields, invalid OHLC constraints, unknown bar finality, unsatisfied session identity, unknown adjustment regime, or unavailable confirmation inputs produce `CANNOT_DETERMINE`. Missing evidence is not false evidence.

## Screenshots

A screenshot can support geometry only if scale, timestamps, interval, session and bar finality are visible or separately supplied. A screenshot is not hidden order-flow evidence. Hidden history, off-screen pivots and unlabeled overlays cannot be assumed.

A three-image Expert-Brain package requires visible or separately supplied instrument identity, exact timeframe, observation cut, and sufficient metadata on all LTF/MTF/HTF frames. A single image can be described under its declared role but is insufficient for a complete three-frame synthesis. The reference orchestration runtime validates image metadata only; it does not fabricate DT-P1 bars or SK02 objects from pixels.

## Resampling and history limits

Only coarser OHLC frames may be derived. The source and target interval, timezone, calendar/version, session, boundary rule, timestamp-label role, availability clock, duplicate handling, missing-bar policy, and partial-parent policy must all be explicit. A developing parent cannot satisfy a closed-bar rule. Corrections create revised parents with later provenance; they never backdate availability.

Only Inside-Break and Outside-Resolve have a proven finite minimum of two eligible confirmed bars. For every other Setup, sufficiency is decided from the actual material R7/Foundation dependency closure at the current cut. An unknown fixed minimum does not block a Setup whose required current evidence is fully determinable. If more history can resolve missing evidence, request earlier OHLC or a wider chart first. If the user has no more history, fail closed only for the affected cell. No universal lookback is invented.

## Richer-data proposals

A source may recommend volume or other evidence. Such a branch is tagged `RICHER_DATA_PROPOSAL`, excluded from the DT-P1 baseline, and cannot affect a baseline result unless the user explicitly changes data contracts in a future governed Skill.
