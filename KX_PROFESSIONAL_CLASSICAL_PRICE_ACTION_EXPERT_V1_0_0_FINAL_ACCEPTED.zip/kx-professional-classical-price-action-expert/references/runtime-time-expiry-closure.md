# MF01-C01 R7 Runtime Time / Expiry Closure

## Scope

This is the narrow R6→R7 correction of runtime time semantics and candidate-relative expiry. All 18 Setup IDs, DT-P1, exact SK01/SK02 pins, doctrine, sources, rights, strict caller/parameter firewalls, bidirectional evaluation, Gap branching, No-Trade retirement and reset `NOT_SUPPORTED` status are preserved.

## Time authority

- `timestamp` retains the exact SK01/provider-declared bar timestamp role.
- `known_at` is the information-availability frontier for the retained bar version/finality.
- The runtime does not require `timestamp == known_at`.
- The runtime does not infer a numeric ordering between those fields unless an explicit provider clock mapping exists.
- A closed-bar Rule may consume a bar only when `bar_finality == CONFIRMED` and `bar.known_at <= evaluation_time`.
- A later `REVISED` record remains a revision record; it is not silently treated as a confirmed bar.

## Candidate-relative expiry algorithm

For each `(setup_id, direction, instrument_id, timeframe, session_id, profile_id)` branch:

1. Validate raw DT-P1, exact Foundation ownership/version/hash, caller keys and profile parameters.
2. Enumerate evidence frontiers in increasing `known_at` order up to `evaluation_time`.
3. At each cut, exclude future bars/objects and execute the setup's canonical `candidate_rule_ids` from `assets/runtime-authority-registry.yaml`.
4. The earliest cut at which all candidate Rules are `TRUE` is `first_candidate_known_at`.
5. If no such cut exists, `expiry_time = null`.
6. Otherwise, select bars for the same instance session with `bar_finality == CONFIRMED` and `bar.known_at > first_candidate_known_at`.
7. Sort by retained known-at order. For registered `expiry_confirmed_bars = N`, `expiry_time` is the Nth selected bar's `known_at`, or `null` until it exists.
8. Bars in prior sessions cannot move this instance's candidate or expiry frontier.
9. Confirmation before expiry activates the instance; a later expiry does not close an ACTIVE instance. If confirmation and expiry share the first post-candidate frontier, expiry closes the pre-ACTIVE instance.

## Executable evidence

`assets/runtime-time-expiry-proof-ledger.yaml` maps every one of the 18 Setups to BUY and SELL proof fixtures (36 total). Each proof executes the same registry-driven `scripts/reference_semantic_runtime.py` used by all semantic/lifecycle validation and covers:

- timestamp/known-at separation;
- canonical first-candidate discovery;
- no-candidate/no-expiry behavior and delayed-candidate translation;
- no expiry before candidate;
- exact N=1 and N=3 frontiers;
- prior-session prehistory invariance;
- future-known-at exclusion;
- revision handling.

No proof supplies candidate truth, expiry truth, state truth or a precomputed Style event to the runtime. Expected values are checked only after execution.

## Closure status

`OPEN_BLOCKER=0`

`OPEN_MAJOR=0`

This is Work self-audit evidence only. Control Room retains final acceptance and lock authority.
