# Language Implementation & Semantic Parity Contract

This document is a human-readable map of the machine contracts in:
- `assets/formula-catalog.yaml`
- `assets/engine-interfaces.yaml`
- `assets/runtime-authority-registry.yaml`
- `assets/expert-brain-runtime-authority.yaml`
- `scripts/validate_math_contract.py`
- `scripts/validate_parity_contract.py`

It introduces no new Trading semantics.

## Language-neutral rule

The canonical product is the data contract + machine registries + algorithms, not a programming language.

For the same:
- normalized DT-P1 evidence,
- known-at cut,
- selected valid parameter/profile,
- setup authority,
- timeframe context,

a conforming implementation must produce semantically equivalent:
- rule truth/unknown state,
- setup lifecycle,
- direction,
- invalidation/expiry,
- Expert-Brain evidence ratios,
- cross-timeframe relations,
- ranking order/ties,
- hypothesis-audit verdict.

## Python

Status: `REFERENCE_EXECUTABLE`.

Use:
- arbitrary-precision integers where appropriate;
- `Decimal` or exact declared conversion for price-to-tick normalization;
- timezone-aware timestamps;
- explicit bar finality;
- no access beyond current known-at prefix;
- typed/explicit tri-state and cannot-determine outputs.

Reference execution:
- `scripts/reference_semantic_runtime.py`
- `scripts/reference_expert_brain_runtime.py`

## Rust

Status: `PARITY_CONTRACT_COMPLETE`.

Required:
- integer-tick semantic core;
- checked arithmetic for production paths;
- typed enums for states/directions/status;
- `Option`/`Result` or equivalent explicit missing/error boundary;
- deterministic event ordering;
- no expected-answer constants in runtime logic.

## C++

Status: `PARITY_CONTRACT_COMPLETE`.

Required:
- integer-tick semantic core;
- checked/guarded production arithmetic;
- explicit enums/status types;
- validated container/array bounds;
- deterministic event-time ordering;
- no fixture-answer shortcuts.

## Go

Status: `PARITY_CONTRACT_COMPLETE`.

Required:
- `int64` tick representation where contract permits;
- checked production arithmetic;
- typed status values;
- explicit missing/error returns;
- deterministic event ordering;
- no expected-output constants.

## Pine Script

Status: `CAPABLE_WITH_LIMITS`.

Required controls:
- closed-bar rules use confirmed-bar semantics;
- higher-timeframe requests must be non-repainting;
- session/timezone must be explicit;
- developing results are visibly provisional.

Limit:
chart history, realtime rollback and unavailable richer data cannot be reconstructed.

## MQL5

Status: `CAPABLE_WITH_LIMITS`.

Required controls:
- bar zero is the current incomplete bar;
- closed-bar rules begin on confirmed bars;
- session/timezone adaptation must be explicit;
- history window must preserve known-at safety.

Limit:
broker bar construction may differ; unavailable intrabar path/richer data cannot be reconstructed.

## Formula implementation rule

Every formula/procedure in `assets/formula-catalog.yaml` owns:
- input semantics;
- units/scales;
- preconditions;
- algorithm/operation order;
- parameters;
- equality/tolerance;
- missing/invalid behavior;
- known-at;
- output semantics;
- engine mapping;
- Golden fixture linkage.

A port may optimize software architecture.
It may not change those Trading/data semantics.

## Parity proof

`validate_parity_contract.py` and the Golden vectors are the parity authority for deterministic calculations.
A language that cannot faithfully implement the required data or timing contract must report capability limits rather than silently approximate the doctrine.
