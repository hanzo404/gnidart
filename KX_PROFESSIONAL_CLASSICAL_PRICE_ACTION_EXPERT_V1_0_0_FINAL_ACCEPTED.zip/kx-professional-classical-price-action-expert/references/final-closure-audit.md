# MF01-C01 Final Single-Truth Closure Audit — R6

Work state: `RETURNED_FOR_CONTROL_ROOM_FINAL_AUDIT`. Only Control Room can accept or lock this candidate.

## Preserved product boundary

R6 patches the R5 candidate in place. It preserves DT-P1, the exact SK01/SK02 v1.0.0 pins, the stable Concepts/Formulas/Setups, the corrected Brooks two-legged-pullback semantics, the source and rights records, bidirectional lifecycle coverage, and valid fixtures. It does not add SK03–SK05, richer market data, adjacent MF01 doctrine, profitability work, or a production trading engine.

## Complete affected-class remediation

| Defect class | R6 closure |
|---|---|
| Caller answers | Exact normalized-input allowlist. Direction, state, confirmation, invalidation, expiry, reset, Gap branch, No-Trade reason, and event-profile truth are prohibited. |
| Parameter ambiguity | `machine_parameter_schema` is the sole type/range authority. Required and allowed keys are exact per Setup. Missing values fail closed; unknown and invalid values reject. |
| Profile mirrors | Setup profiles expose only non-semantic runtime parameters. Confirmation Rule, event profile, reset support, and expiry mode resolve internally from canonical authority. |
| Event fallback | Removed cross-Setup generic fallback. Each producer uses the Setup authority's event derivation and known-at contract. |
| Runtime composition | `assets/runtime-authority-registry.yaml` is the sole Setup composition authority. The QA runtime is registry-driven and contains no Setup/Rule routing IDs. |
| Reset/expiry | Reset stable IDs are inactive/retired and have no active downstream path. All active surfaces implement only confirmed-bar expiry. |
| Gap | Both continuation and fill hypotheses are derived internally for each directional evaluation. Caller branch selection is impossible. |
| No-Trade | The unsupported deterministic classifier is retired. No caller-fed reason can manufacture a classification. |
| Rule proof | All 95 active Rules have executable coverage records. TRUE/FALSE and applicable cannot-determine/invalid branches are recomputed by the same runtime. |
| AI/engine | Input and output schemas mirror the caller/runtime authority. Engine components declare zero developer Trading-logic choice points. |

## Fresh defects discovered and repaired

The class-wide audit found that the R5 generic confirmation fallback could activate one Setup using an unrelated Gap or candle event present in the shared fixture envelope. R6 removed that fallback, added registry-specific primary-event selection, and required structural objects to be known before a derived cross. Existing legitimate lifecycle outputs were then rerun in both directions.

The audit also found that branch counts alone did not prove the two internal Gap hypotheses. R6 added four raw-evidence executions for up-gap/down-gap continuation and fill, and linked them to two explicit branch-ledger records.

## Validation result

The packaged validators, all prior Control Room gates, the R5→R6 gate, semantic fixtures, math/parity, source/claim/rights, Data Firewall, known-at, dependency graph, mutation suite, and clean-extract black-box protocol pass. Exact commands, hashes, counts, and clean-extract results are recorded in the receipt.

`OPEN_BLOCKER=0`

`OPEN_MAJOR=0`
