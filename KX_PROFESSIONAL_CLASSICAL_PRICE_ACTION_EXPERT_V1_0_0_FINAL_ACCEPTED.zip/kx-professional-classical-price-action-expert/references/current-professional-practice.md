# Current professional practice

The current-practice pass was checked on 2026-08-30 and is independent from the historical lineage pass. It includes the fully inspected IG Academy trends-and-channels page (`SRC-PA-023`): C01 supports trendline/channel interaction only as a Style interpretation over exact SK02 line/channel objects, never as reconstructed geometry, inferred intent, or an automatic signal.

## Practice map

| Current source | Evidence of present practice | Safe contribution | Boundary |
|---|---|---|---|
| Brooks Price Action official site | Active books, course, articles, glossary and practitioner community | Bar-by-bar context, trend/range spectrum, failed breaks, second entries, wedges | Brooks-specific vocabulary remains variant-scoped |
| Candlecharts / Steve Nison | Active official education stresses trend, location, support/resistance and confirmation | Context-qualified candlestick workflow | Commercial self-description is not independent effectiveness evidence |
| Adam Grimes official site | 2025 articles discuss context, clean versus noisy charts, waiting and no-trade decisions | Context-first workflow and explicit expert judgement | Blog examples are illustrative, not universal algorithms |
| IG Academy and analysis | Current institutional education covers trend, support/resistance, channels, patterns, breakouts/fakeouts | Evidence that classical chart reading remains professionally taught | Volume-confirmation branches exceed DT-P1 and are excluded |
| Charles Schwab education | 2025 candlestick lesson combines candles with support/resistance | Independent institutional corroboration of context-qualified candles | Educational material is not a performance guarantee |
| CMT Association | Current chart commentary uses direct price-path interpretation | Independent professional-community evidence of ongoing chart practice | Indicator/Fibonacci overlays are outside the baseline |

## Practice consensus and disagreements

The sources converge on context, location, confirmation, risk of false breaks, and the value of waiting. They disagree on naming, pattern boundaries, trigger timing, acceptable discretion, bar-count conventions and whether auxiliary volume/indicator evidence is required. The Skill exposes those differences through `variant-registry.yaml` and `conflict-register.yaml`.

## Independent saturation pass

The second pass searched current institutional education, a professional association, platform execution documentation and practitioner-controlled sources for missing families or implementation hazards. It added explicit no-trade context, unconfirmed-bar handling, higher-timeframe confirmation, breakout/fakeout practice, and a DT-P1 exclusion for volume-dependent confirmation. No new source changed the locked data contract or justified a universal threshold.

Saturation is semantic, not a source-count claim. It is reached only because each mandatory concept/setup family has at least one lineage authority, a current-practice route where available, an implementation boundary, and an explicit conflict or limitation where authorities do not support convergence.
