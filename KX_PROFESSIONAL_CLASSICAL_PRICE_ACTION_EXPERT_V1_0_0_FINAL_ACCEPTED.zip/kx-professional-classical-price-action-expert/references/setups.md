# Complete setup universe

The executable catalog in `assets/setup-catalog.yaml` covers the mandatory professional/classical families:

1. trend pullback continuation;
2. breakout continuation;
3. breakout pullback/retest;
4. failed breakout reversal;
5. range-boundary rejection;
6. range breakout;
7. double-top/double-bottom resolution;
8. head-and-shoulders neckline resolution;
9. triangle breakout;
10. flag/pennant continuation;
11. wedge/three-push reversal;
12. Brooks High-2/Low-2 two-legged pullback (not generic attempt counting);
13. Brooks second-entry failed break, with first failure and second trigger represented as distinct sourced events;
14. context-qualified rejection candle;
15. context-qualified engulfing relation;
16. inside-bar breakout mode;
17. outside-bar context resolution;
18. session-gap continuation/fill-hypothesis branches.

Each setup declares its lineage, context, location, sequence, trigger, confirmation, disqualification, invalidation, expiry, typed cannot-determine conditions, known-at semantics, visual contract, engine mapping, source/claim links and positive/negative/near-miss fixtures. Material parameters resolve through `assets/parameter-profile-registry.yaml`; missing caller-required tolerance/count values do not inherit a hidden default. Reset is not supported in v1.0.0, and the only executable expiry mode is confirmed-bar count.

The setup fixtures carry raw DT-P1 bars plus versioned SK02-style foundation objects. The semantic harness evaluates each setup's `predicate_rule_ids`, lifecycle precedence and known-at frontier. Stored expected results are assertions only.

These are hypothesis classifiers, not trading instructions. A setup becoming `ACTIVE` means its chosen trigger predicate is observed. It does not imply an order, expected return, stop, target or position size.
## Saturation disposition

The machine-readable `assets/setup-saturation-ledger.yaml` records every material additional Brooks family found in the accepted first-party glossary. Named-but-under-specified proprietary families are reference-only or blocked-source-gap; they are not converted into invented setups.
