# Concepts and variants

The canonical concept registry is `assets/ontology.yaml`. Each concept is a complete machine contract with explicit data, inputs, temporal and spatial rules, confirmation, invalidation, expiry, missing/invalid handling, known-at semantics, provenance and fixtures.

## Core concept groups

- Data and time: confirmed bar, developing bar, known-at cut, session-relative bar.
- Context: trend-up, trend-down, range, transition and unclear.
- Location: support/resistance zone, trendline/channel interaction, range boundary, gap reference.
- Path: impulse, pullback, test, breakout, follow-through, retest, failed breakout and measured-move projection.
- Bar/candle evidence: rejection bar, inside bar, outside bar, doji-like indecision, engulfing relation.
- Pattern evidence: double top/bottom, head-and-shoulders, triangle, flag/pennant and wedge/three-push.
- Workflow: signal-bar candidate, confirmation, alternative hypothesis and no-trade state.

## Variant discipline

`variant-registry.yaml` records the lineage owner, compatible source claims, executable status and collision rules. `conflict-register.yaml` records disagreements such as zone versus exact line, close-confirmed versus intrabar breakout, immediate versus follow-through confirmation, and Brooks-specific counting. When a conflict changes the result and the user has not selected a profile, return alternatives or `CANNOT_DETERMINE`.

No concept interprets OHLC as observed buying/selling volume, resting liquidity, participant identity, queue state, institutional activity or intent.
## Exact trendline/channel interpretation boundary

C01 consumes `FND02-CON-1155` line objects and `FND02-CON-1162` channel objects. It adds only contextual interaction classifications. Geometry construction, touch, penetration, containment, and break remain SK02-owned. Every classification is known-at safe and tolerance-profiled; no line/channel event implies a trade.
