#!/usr/bin/env python3
"""Execute the minimum 18 x 2 x 3 Expert-Brain orchestration proof."""
from copy import deepcopy
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from reference_expert_brain_runtime import ExpertBrainRuntime  # noqa: E402

ROLES = {"LTF": "5m", "MTF": "30m", "HTF": "2h"}


def select_payloads(runtime):
    rows = yaml.safe_load((ROOT / "assets/semantic-fixtures.yaml").read_text(encoding="utf-8"))["fixtures"]
    selected = {}
    for row in rows:
        setup_id = row.get("setup_id")
        if row.get("fixture_type") == "SETUP_LIFECYCLE_RAW_EVIDENCE" and setup_id in runtime.setup_ids and setup_id not in selected:
            selected[setup_id] = {
                key: deepcopy(value) for key, value in row.items()
                if key not in {"fixture_id", "fixture_type", "expected_state", "expected_result", "purpose"}
            }
    if set(selected) != set(runtime.setup_ids):
        raise AssertionError(f"missing lifecycle payloads: {sorted(set(runtime.setup_ids) - set(selected))}")
    return selected


def frame(role, payloads):
    adapted = {}
    for setup_id, payload in payloads.items():
        item = deepcopy(payload)
        item["normalized_inputs"]["instrument_id"] = "TEST"
        item["normalized_inputs"]["timeframe"] = ROLES[role]
        item["raw_dt_p1"]["instrument_id"] = "TEST"
        item["raw_dt_p1"]["bar_interval"] = ROLES[role]
        item["raw_dt_p1"]["timeframe"] = ROLES[role]
        adapted[setup_id] = item
    return {
        "instrument_id": "TEST", "timeframe": ROLES[role], "timezone": "UTC",
        "calendar_id": "TEST-24X7", "calendar_version": "1", "session_id": "S1",
        "evaluation_cut": 30, "setup_payloads": adapted,
    }


def document(payloads):
    return {
        "mode": "EXPLICIT_THREE_FRAME_OHLC", "input_timeframe": "5m",
        "explicit_roles": deepcopy(ROLES), "evaluation_cut": 30,
        "frames": {role: frame(role, payloads) for role in ROLES},
    }


def intrinsic_projection(record):
    return {
        key: deepcopy(record[key]) for key in (
            "current_classification", "lifecycle_substate", "satisfied_conditions",
            "violated_conditions", "missing_conditions", "intrinsic_fss",
            "component_ratios", "lifecycle_completion", "hard_gate",
        )
    }


def main():
    runtime = ExpertBrainRuntime()
    errors = []
    payloads = select_payloads(runtime)
    doc = document(payloads)
    result = runtime.analyze(doc)
    tables = {role: result.get(f"{role.lower()}_complete_setup_table", []) for role in ROLES}
    records = [row for role in ROLES for row in tables[role]]

    if result.get("result_state") is not None:
        errors.append(f"unexpected result_state: {result.get('result_state')}")
    if result.get("orchestration_record_count") != 108 or len(records) != 108:
        errors.append(f"expected 108 records, got output={result.get('orchestration_record_count')} actual={len(records)}")
    expected_cells = {(role, setup_id, direction) for role in ROLES for setup_id in runtime.setup_ids for direction in ("BUY", "SELL")}
    actual_cells = {(x.get("frame_role"), x.get("setup_id"), x.get("direction")) for x in records}
    if actual_cells != expected_cells:
        errors.append(f"cell identity mismatch missing={sorted(expected_cells-actual_cells)} extra={sorted(actual_cells-expected_cells)}")
    if any(len(tables[role]) != 36 for role in ROLES):
        errors.append("one or more per-frame complete tables do not contain 36 rows")
    if any(x.get("r7_invoked") is not True for x in records):
        errors.append("at least one cell lacks an R7 invocation marker")
    if result.get("frame_tables_frozen_before_synthesis") is not True:
        errors.append("frame-table freeze marker is absent")
    required_history_fields = {
        "history_evidence_status", "history_request_required", "history_request_reason",
        "requested_additional_history", "history_availability", "raw_r7_lifecycle_substate",
    }
    if any(not required_history_fields <= set(row) for row in records):
        errors.append("one or more cells omit required C1 history/raw-R7 fields")
    if any(
        row["hard_gate"]["history_status"]["status"] != "HISTORY_SUFFICIENT"
        for row in records if row["raw_r7_lifecycle_substate"] in {"CANDIDATE", "PENDING", "ARMED", "ACTIVE"}
    ):
        errors.append("a determinable current fixture remains barred only by unknown fixed history")

    for setup_id in runtime.setup_ids:
        for direction in ("BUY", "SELL"):
            direct = runtime.r7.evaluate_branch_details(setup_id, payloads[setup_id], direction)["state"]
            row = next(x for x in tables["LTF"] if x["setup_id"] == setup_id and x["direction"] == direction)
            if row["lifecycle_substate"] != direct:
                errors.append(f"R7 state mismatch for {setup_id}/{direction}: {row['lifecycle_substate']} != {direct}")

    before = {(x["setup_id"], x["direction"]): intrinsic_projection(x) for x in tables["LTF"]}
    isolated = deepcopy(doc)
    isolated["frames"]["HTF"]["setup_payloads"][runtime.setup_ids[0]] = {}
    isolated["frames"]["HTF"]["setup_history_availability"] = {runtime.setup_ids[0]: "NO_MORE_AVAILABLE"}
    changed = runtime.analyze(isolated)
    after_rows = changed.get("ltf_complete_setup_table", [])
    after = {(x["setup_id"], x["direction"]): intrinsic_projection(x) for x in after_rows}
    if before != after:
        errors.append("HTF evidence modified an intrinsic LTF setup state or score")
    affected = [
        row for row in changed.get("htf_complete_setup_table", [])
        if row["setup_id"] == runtime.setup_ids[0]
    ]
    if len(affected) != 2 or any(row["current_classification"] != "CANNOT_DETERMINE" for row in affected):
        errors.append("NO_MORE_AVAILABLE did not fail closed only for the affected setup/frame cells")
    unaffected_before = [row for row in tables["HTF"] if row["setup_id"] != runtime.setup_ids[0]]
    unaffected_after = [row for row in changed.get("htf_complete_setup_table", []) if row["setup_id"] != runtime.setup_ids[0]]
    if [intrinsic_projection(x) for x in unaffected_before] != [intrinsic_projection(x) for x in unaffected_after]:
        errors.append("affected history failure changed unrelated HTF cells")
    if any(
        row["setup_id"] == runtime.setup_ids[0]
        for row in changed.get("alternative_valid_reads", [])
        if row["frame_role"] == "HTF"
    ):
        errors.append("history-ineligible HTF cell appeared as a valid alternative")

    explicit_bad = deepcopy(doc)
    explicit_bad["frames"]["HTF"]["instrument_id"] = "OTHER"
    if runtime.analyze(explicit_bad).get("result_state") != "TIMEFRAME_CONTEXT_INCOMPLETE":
        errors.append("cross-instrument explicit frames were accepted")
    one_image = runtime.analyze({
        "mode": "SINGLE_FRAME_IMAGE", "requested_role": "LTF",
        "images": {"LTF": {"instrument_id": "TEST", "timeframe": "5m", "observation_cut": 30, "visible_metadata_sufficient": True}},
    })
    if one_image.get("timeframe_context") != "VALIDATED_IMAGE_METADATA" or one_image.get("result_state") != "IMAGE_EVIDENCE_REQUIRES_STRUCTURED_FOUNDATION_EXTRACTION":
        errors.append("valid single-image metadata contract was not preserved")
    if one_image.get("history_evidence_status") != "MORE_HISTORY_REQUIRED" or one_image.get("requested_additional_history", {}).get("kind") != "WIDER_LONGER_CHART" or one_image.get("requested_additional_history", {}).get("exact_count") is not None:
        errors.append("image mode did not request a wider/longer chart without inventing an exact count")
    incomplete = runtime.analyze({"mode": "THREE_FRAME_IMAGE_PACKAGE", "images": {"LTF": {}}})
    if incomplete.get("result_state") != "CANNOT_DETERMINE":
        errors.append("incomplete image package did not fail closed")

    if errors:
        print("EXPERT-BRAIN VALIDATION: FAIL")
        for error in errors:
            print("FAIL:", error)
        return 2
    print("EXPERT-BRAIN VALIDATION: PASS (18 setups x BUY/SELL x LTF/MTF/HTF = 108 R7 calls; intrinsic isolation; image contract)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
