#!/usr/bin/env python3
"""Execute all MF01-C01 semantic evidence through the reference runtime."""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from reference_semantic_runtime import SemanticRuntime, CD, INVALID, MISSING  # noqa: E402


def load(name):
    return yaml.safe_load((ROOT / "assets" / name).read_text(encoding="utf-8"))


def direction(row):
    return (row.get("test_assertions") or {}).get("direction", "BUY")


def evaluate_setup_sequence(runtime, row):
    """Execute the canonical ordered-cut state machine; never look up stored states."""
    return runtime.evaluate_sequence(row["setup_id"], row["input_fixture"], row["evaluation_cuts"], direction(row))


def evaluate_r7_time_expiry_proof(runtime, row, fixture_by_id):
    """Execute the class-wide R7 time/expiry mutation contract from raw evidence."""
    base = deepcopy(fixture_by_id.get(row.get("base_fixture_id")))
    if not isinstance(base, dict):
        return CD
    setup_id, branch = row["setup_id"], row["direction"]
    bars = base["raw_dt_p1"]["bars"]
    base["normalized_inputs"]["evaluation_time"] = max(bar["known_at"] for bar in bars)
    base["normalized_inputs"]["profile_parameters"]["expiry_confirmed_bars"] = 1_000_000
    baseline = runtime.evaluate_branch_details(setup_id, base, branch)
    first_candidate = baseline["first_candidate_known_at"]
    if first_candidate is None:
        return "FALSE"

    no_candidate = deepcopy(base)
    no_candidate["normalized_inputs"]["evaluation_time"] = min(bar["known_at"] for bar in bars) - 1
    no_candidate_details = runtime.evaluate_branch_details(setup_id, no_candidate, branch)
    if no_candidate_details["first_candidate_known_at"] is not None or no_candidate_details["expiry_time"] is not None:
        return "FALSE"

    # Market timestamp and information availability are independent SK01 roles.
    separated = deepcopy(base)
    for bar in separated["raw_dt_p1"]["bars"]:
        bar["timestamp"] = f"MARKET-TIME-{bar['session_id']}-{bar['index']}"
    separated_details = runtime.evaluate_branch_details(setup_id, separated, branch)
    if separated_details["first_candidate_known_at"] != first_candidate:
        return "FALSE"

    # Ensure at least three same-instance confirmed bars after the candidate.
    expanded = deepcopy(separated)
    expanded_bars = expanded["raw_dt_p1"]["bars"]
    next_known_at = max(bar["known_at"] for bar in expanded_bars)
    next_index = max(bar["index"] for bar in expanded_bars)
    price = expanded_bars[-1]["close"]
    for offset in range(1, 4):
        expanded_bars.append({
            "index": next_index + offset,
            "timestamp": f"MARKET-TIME-APPENDED-{next_index + offset}",
            "known_at": next_known_at + 10 * offset,
            "open": price, "high": price + 1, "low": price - 1, "close": price,
            "finality": "CONFIRMED", "bar_finality": "CONFIRMED",
            "session_id": expanded["normalized_inputs"]["session_id"],
        })
    expanded["normalized_inputs"]["evaluation_time"] = expanded_bars[-1]["known_at"]
    post_candidate = [
        bar["known_at"] for bar in expanded_bars
        if bar["session_id"] == expanded["normalized_inputs"]["session_id"]
        and bar["bar_finality"] == "CONFIRMED"
        and bar["known_at"] > first_candidate
    ]
    if len(post_candidate) < 3:
        return "FALSE"
    for count, wanted in ((1, post_candidate[0]), (3, post_candidate[2])):
        proof = deepcopy(expanded)
        proof["normalized_inputs"]["profile_parameters"]["expiry_confirmed_bars"] = count
        actual = runtime.evaluate_branch_details(setup_id, proof, branch)
        if actual["first_candidate_known_at"] != first_candidate or actual["expiry_time"] != wanted:
            return "FALSE"

    # Delaying the availability stream delays candidate and expiry without any
    # market-timestamp rewrite or raw-history-index anchoring.
    delayed = deepcopy(expanded)
    def shift_known_at(value, delta):
        if isinstance(value, dict):
            for key, item in value.items():
                if key == "known_at" and type(item) in {int, float}:
                    value[key] = item + delta
                else:
                    shift_known_at(item, delta)
        elif isinstance(value, list):
            for item in value:
                shift_known_at(item, delta)
    shift_known_at(delayed.get("raw_dt_p1", {}), 100)
    shift_known_at(delayed.get("foundation_objects", {}), 100)
    shift_known_at(delayed.get("foundation_object_provenance", {}), 100)
    delayed["normalized_inputs"]["evaluation_time"] += 100
    delayed["normalized_inputs"]["profile_parameters"]["expiry_confirmed_bars"] = 3
    delayed_details = runtime.evaluate_branch_details(setup_id, delayed, branch)
    if delayed_details["first_candidate_known_at"] != first_candidate + 100 or delayed_details["expiry_time"] != post_candidate[2] + 100:
        return "FALSE"

    # At the candidate cut there is no eligible post-candidate confirmed bar.
    at_candidate = deepcopy(expanded)
    at_candidate["normalized_inputs"]["evaluation_time"] = first_candidate
    at_candidate["normalized_inputs"]["profile_parameters"]["expiry_confirmed_bars"] = 1
    candidate_details = runtime.evaluate_branch_details(setup_id, at_candidate, branch)
    if candidate_details["first_candidate_known_at"] != first_candidate or candidate_details["expiry_time"] is not None:
        return "FALSE"

    # A bar whose known_at is after the cut cannot leak into the first expiry.
    before_first_post = deepcopy(expanded)
    before_first_post["normalized_inputs"]["evaluation_time"] = (first_candidate + post_candidate[0]) / 2
    before_first_post["normalized_inputs"]["profile_parameters"]["expiry_confirmed_bars"] = 1
    if runtime.evaluate_branch_details(setup_id, before_first_post, branch)["expiry_time"] is not None:
        return "FALSE"

    # Prior-session history cannot move this instance's candidate or expiry.
    prehistory = deepcopy(expanded)
    first_bar = prehistory["raw_dt_p1"]["bars"][0]
    prior = {
        "index": first_bar["index"] - 1,
        "timestamp": "PRIOR-SESSION-MARKET-TIME",
        "known_at": first_bar["known_at"] - 1,
        "open": first_bar["open"], "high": first_bar["high"],
        "low": first_bar["low"], "close": first_bar["close"],
        "finality": "CONFIRMED", "bar_finality": "CONFIRMED",
        "session_id": "R7-PRIOR-SESSION",
    }
    prehistory["raw_dt_p1"]["bars"].insert(0, prior)
    prehistory["normalized_inputs"]["profile_parameters"]["expiry_confirmed_bars"] = 3
    prehistory_details = runtime.evaluate_branch_details(setup_id, prehistory, branch)
    if prehistory_details["first_candidate_known_at"] != first_candidate or prehistory_details["expiry_time"] != post_candidate[2]:
        return "FALSE"

    # A later REVISED record is not silently reclassified as a confirmed bar.
    revised = deepcopy(expanded)
    revised_bar = deepcopy(revised["raw_dt_p1"]["bars"][-1])
    revised_bar["index"] += 1
    revised_bar["known_at"] += 10
    revised_bar["timestamp"] = "REVISED-MARKET-TIME"
    revised_bar["finality"] = revised_bar["bar_finality"] = "REVISED"
    revised["raw_dt_p1"]["bars"].append(revised_bar)
    revised["normalized_inputs"]["evaluation_time"] = revised_bar["known_at"]
    revised["normalized_inputs"]["profile_parameters"]["expiry_confirmed_bars"] = 3
    revised_details = runtime.evaluate_branch_details(setup_id, revised, branch)
    if revised_details["first_candidate_known_at"] != first_candidate or revised_details["expiry_time"] != post_candidate[2]:
        return "FALSE"
    return "TRUE"


def validate_runtime_contract(runtime):
    """Cross-check rule-catalog.yaml/setup predicate_rule_ids and material profile controls."""
    errors = []
    setup_rows = load("setup-catalog.yaml")["setups"]
    profile_ids = {p["profile_id"] for p in load("parameter-profile-registry.yaml")["profiles"]}
    for setup in setup_rows:
        authority = runtime.authorities[setup["setup_id"]]
        predicate_rule_ids = setup["predicate_rule_ids"]
        if not set(predicate_rule_ids) <= set(runtime.rules):
            errors.append(setup["setup_id"] + ": unresolved predicate Rule")
        expiry_mode = authority["expiry_policy"]["mode"]
        expiry_profile_id = setup["parameters"]["expiry_profile_id"]
        expiry_confirmed_bars = authority["expiry_policy"]["parameter"]
        confirmation_rule_id = setup["parameters"]["confirmation_rule_id"]
        if expiry_mode != "CONFIRMED_BARS" or expiry_profile_id not in profile_ids or expiry_confirmed_bars != "expiry_confirmed_bars":
            errors.append(setup["setup_id"] + ": incomplete expiry contract")
        if confirmation_rule_id not in authority["confirmation_rule_ids"]:
            errors.append(setup["setup_id"] + ": confirmation binding diverges")
    return errors


def evaluate(runtime, row, fixture_by_id):
    kind = row.get("fixture_type")
    if kind == "R7_RUNTIME_TIME_EXPIRY_PROOF":
        return evaluate_r7_time_expiry_proof(runtime, row, fixture_by_id)
    if kind == "GAP_INTERNAL_BRANCH_RAW_EVIDENCE":
        assertion = row["test_assertions"]
        d = assertion["direction"]
        branch = runtime.derive_analysis_branch_for_test(row["setup_id"], row, d)
        state = runtime.evaluate_branch(row["setup_id"], row, d)
        return "TRUE" if branch == assertion["analysis_branch"] and state == assertion["lifecycle_state"] else "FALSE"
    if kind == "SETUP_LIFECYCLE_SEQUENCE":
        return evaluate_setup_sequence(runtime, row)
    if kind == "SETUP_STATE_AT_CUT_SEQUENCE":
        path = evaluate_setup_sequence(runtime, row)
        return path[-1] if path else "CANNOT_DETERMINE"
    if kind == "HYPOTHESIS_AUDIT":
        evidence = runtime.evaluate_branch(row["setup_id"], row["input_fixture"], direction(row))
        if evidence in {CD, INVALID}: return CD
        if evidence == row["claimed_state"]: return "MATCH"
        if row["claimed_state"] == "ACTIVE" and evidence in {"CANDIDATE", "PENDING", "ARMED"}: return "PARTIAL_MATCH"
        return "NOT_MATCH"
    if kind == "RULE_UNIT": return runtime.evaluate_rule_fixture(row)
    if kind == "STYLE_EVENT_UNIT":
        assertion = row.get("event_assertion", {})
        setup_id = row.get("setup_id") or row["input_fixture"].get("setup_id")
        d = direction(row) if (row.get("test_assertions") or {}).get("direction") else direction(row["input_fixture"])
        actual = runtime.derive_event_for_test(setup_id, row["input_fixture"], d, row["event_id"])
        if actual is MISSING: return CD
        if assertion.get("mode") == "EXACT_ABSENCE": return "TRUE" if actual is None else "FALSE"
        return "TRUE" if actual == assertion.get("value") and assertion.get("known_at_cut") == row["input_fixture"]["normalized_inputs"]["evaluation_time"] else "FALSE"
    if row.get("setup_id") in runtime.authorities:
        return runtime.evaluate_branch(row["setup_id"], row, direction(row))
    return runtime.evaluate_utility(row)


def main():
    runtime = SemanticRuntime()
    fixtures = load("semantic-fixtures.yaml")["fixtures"]
    fixture_by_id = {row["fixture_id"]: row for row in fixtures}
    errors, count, actual_by_fixture = validate_runtime_contract(runtime), 0, {}
    for row in fixtures:
        if row.get("fixture_type") == "MATH_GOLDEN": continue
        actual = evaluate(runtime, row, fixture_by_id)
        actual_by_fixture[row["fixture_id"]] = actual
        wanted = row.get("expected_result")
        count += 1
        if actual != wanted: errors.append(f"{row['fixture_id']}: actual={actual!r} wanted={wanted!r}")

    coverage = load("rule-coverage-ledger.yaml")["rules"]
    expected_by_key = {
        "true_fixture_ids": "TRUE",
        "false_fixture_ids": "FALSE",
        "cannot_determine_fixture_ids": CD,
        "invalid_fixture_ids": INVALID,
    }
    for record in coverage:
        for key, expected in expected_by_key.items():
            for fixture_id in record.get(key, []):
                if actual_by_fixture.get(fixture_id) != expected:
                    errors.append(f"{record['rule_id']}: {key} fixture {fixture_id} recomputed {actual_by_fixture.get(fixture_id)!r}")

    active_by_setup = {sid: set() for sid in runtime.authorities}
    samples = [r for r in fixtures if r.get("setup_id") in runtime.authorities and r.get("fixture_type") == "SETUP_LIFECYCLE_RAW_EVIDENCE" and r.get("expected_result") == "ACTIVE"]
    for sample in samples:
        sid, d = sample["setup_id"], direction(sample)
        active_by_setup[sid].add(d)
        base = runtime.evaluate_branch(sid, sample, d)
        if base != "ACTIVE": continue
        mutation = deepcopy(sample)
        for bar in mutation["raw_dt_p1"]["bars"]: bar.update(open=100, high=100, low=100, close=100)
        if runtime.evaluate_branch(sid, mutation, d) == "ACTIVE": errors.append(f"{sid}/{d}: flat-price mutation remained ACTIVE")
        mutation = deepcopy(sample)
        for bar in mutation["raw_dt_p1"]["bars"]: bar["finality"] = bar["bar_finality"] = "DEVELOPING"
        if runtime.evaluate_branch(sid, mutation, d) == "ACTIVE": errors.append(f"{sid}/{d}: developing-bar mutation remained ACTIVE")
        mutation = deepcopy(sample); mutation["normalized_inputs"]["profile_parameters"]["undeclared_parameter"] = 1
        if runtime.evaluate_branch(sid, mutation, d) != INVALID: errors.append(f"{sid}/{d}: undeclared parameter not rejected")
        mutation = deepcopy(sample); mutation["normalized_inputs"]["__UNKNOWN_NORMALIZED_KEY__"] = 1
        if runtime.evaluate_branch(sid, mutation, d) != INVALID: errors.append(f"{sid}/{d}: unknown normalized input not rejected")
        mutation = deepcopy(sample); mutation["normalized_inputs"]["profile_id"] = "UNKNOWN-PROFILE"
        if runtime.evaluate_branch(sid, mutation, d) not in {CD, INVALID}: errors.append(f"{sid}/{d}: unknown profile not rejected")
        mutation = deepcopy(sample)
        record = next(iter(mutation["foundation_object_provenance"].values())); record["foundation_sha256"] = "0" * 64
        if runtime.evaluate_branch(sid, mutation, d) != INVALID: errors.append(f"{sid}/{d}: Foundation hash corruption not rejected")
        mutation = deepcopy(sample)
        first = next(iter(mutation["foundation_object_provenance"].values())); first["foundation_skill_id"] = "SK02" if first["foundation_skill_id"] == "SK01" else "SK01"
        if runtime.evaluate_branch(sid, mutation, d) != INVALID: errors.append(f"{sid}/{d}: Foundation owner corruption not rejected")
        mutation = deepcopy(sample); mutation["expected_result"] = "MUTATED_ASSERTION"
        if runtime.evaluate_branch(sid, mutation, d) != base: errors.append(f"{sid}/{d}: stored assertion changed runtime output")
        mutation = deepcopy(sample)
        for bar in mutation["raw_dt_p1"]["bars"][1:]: bar["known_at"] += 1000
        if runtime.evaluate_branch(sid, mutation, d) == "ACTIVE": errors.append(f"{sid}/{d}: future-shift mutation leaked into earlier cut")
        mutation = deepcopy(sample); mutation["normalized_inputs"]["profile_parameters"]["confirmation_rule_id"] = "UNKNOWN-CONFIRMATION"
        if runtime.evaluate_branch(sid, mutation, d) != INVALID: errors.append(f"{sid}/{d}: wrong confirmation binding not rejected")
    for sid, dirs in active_by_setup.items():
        if dirs != {"BUY", "SELL"}: errors.append(f"{sid}: directional ACTIVE proof incomplete: {sorted(dirs)}")

    active_rules = {rid for rid, rule in runtime.rules.items() if rule.get("status", "ACTIVE") == "ACTIVE"}
    missing = active_rules - runtime.executed_rules
    if missing: errors.append("active Rule contracts not executed: " + ", ".join(sorted(missing)))
    if errors:
        print("SEMANTIC FIXTURES: FAIL")
        for error in errors[:400]: print("FAIL:", error)
        if len(errors) > 400: print("FAIL: ...", len(errors) - 400, "more")
        return 2
    print(f"SEMANTIC FIXTURES: PASS ({count} non-math fixtures; {len(runtime.executed_rules)}/{len(active_rules)} active Rule contracts; {len(runtime.authorities)} setups; BUY+SELL complete)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
