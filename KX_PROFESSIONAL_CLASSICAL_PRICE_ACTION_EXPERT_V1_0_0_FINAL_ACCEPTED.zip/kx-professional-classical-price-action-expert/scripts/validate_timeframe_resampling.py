#!/usr/bin/env python3
"""Targeted timeframe routing and OHLC resampling conformance proof."""
from copy import deepcopy
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from reference_expert_brain_runtime import ExpertBrainRuntime  # noqa: E402


def child(index, start, end, o, h, l, c, known_at, finality="CONFIRMED"):
    return {
        "index": index, "interval_start": start, "interval_end": end,
        "timestamp": end, "open": o, "high": h, "low": l, "close": c,
        "bar_finality": finality, "known_at": known_at, "session_id": "S1",
    }


def metadata(source="1m", target="5m", partial="REJECT"):
    return {
        "instrument_id": "TEST", "source_timeframe": source, "target_timeframe": target,
        "timezone": "UTC", "calendar_id": "TEST-24X7", "calendar_version": "1",
        "session_id": "S1", "boundary_rule": "EXPLICIT_PARENT_BUCKETS",
        "timestamp_label_role": "INTERVAL_END", "availability_clock_id": "CLOCK-A",
        "evaluation_cut": 100,
        "missing_bar_policy": "REQUIRE_COMPLETE_EXPECTED_SET", "duplicate_policy": "REJECT",
        "partial_target_policy": partial,
    }


def bucket(start=0, end=5, parent_known=75, expected=None):
    return {
        "interval_start": start, "interval_end": end, "parent_end_known_at": parent_known,
        "session_id": "S1", "expected_child_intervals": expected or [[x, x + 1] for x in range(start, end)],
    }


def main():
    runtime = ExpertBrainRuntime()
    errors = []

    expected_routes = {
        "1m": ("1m", "5m", "30m"), "3m": ("3m", "15m", "1h"),
        "5m": ("5m", "30m", "2h"), "15m": ("15m", "1h", "4h"),
        "30m": ("30m", "2h", "8h"), "1h": ("1h", "4h", "1D"),
        "4h": ("4h", "1D", "1W"), "1D": ("1D", "1W", "1M"),
    }
    for source, route in expected_routes.items():
        first = runtime.resolve_roles(source)
        second = runtime.resolve_roles(source)
        if first != second or tuple(first.get("roles", {}).get(x) for x in ("LTF", "MTF", "HTF")) != route:
            errors.append(f"route mismatch for {source}: {first}")
    if runtime.resolve_roles("2m").get("status") != "CANNOT_DETERMINE_TIMEFRAME_ROUTING":
        errors.append("unsupported mapping did not fail closed")
    if runtime.resolve_roles(None, {"LTF": "5m", "MTF": "5m", "HTF": "2h"}).get("roles"):
        errors.append("unordered explicit roles were accepted")

    bars = [
        child(0, 0, 1, 100, 103, 99, 102, 11),
        child(1, 1, 2, 102, 104, 100, 101, 24),
        child(2, 2, 3, 101, 102, 96, 97, 31),
        child(3, 3, 4, 97, 105, 95, 103, 48),
        child(4, 4, 5, 103, 107, 102, 106, 62),
    ]
    result = runtime.resample_bars(bars, [bucket()], metadata())
    replay = runtime.resample_bars(deepcopy(bars), [bucket()], metadata())
    if result != replay:
        errors.append("identical replay was not deterministic")
    expected_parent = {
        "open": 100, "high": 107, "low": 95, "close": 106,
        "known_at": 75, "timestamp": 5, "bar_finality": "CONFIRMED",
    }
    if result.get("status") != "DETERMINED" or len(result.get("bars", [])) != 1:
        errors.append(f"valid resample failed: {result}")
    else:
        parent = result["bars"][0]
        for key, expected in expected_parent.items():
            if parent.get(key) != expected:
                errors.append(f"parent {key}={parent.get(key)!r}, expected {expected!r}")
        if parent["known_at"] == parent["timestamp"]:
            errors.append("timestamp and known_at were improperly collapsed")

    lower = runtime.resample_bars(bars, [bucket()], metadata("5m", "1m"))
    if lower.get("status") != "CANNOT_DERIVE_LOWER_TIMEFRAME":
        errors.append("lower-timeframe derivation was not rejected")
    missing_meta = metadata()
    del missing_meta["calendar_version"]
    if runtime.resample_bars(bars, [bucket()], missing_meta).get("status") != "CANNOT_DETERMINE_SESSION_ALIGNMENT":
        errors.append("missing session metadata did not fail closed")
    duplicate = bars + [deepcopy(bars[-1])]
    if runtime.resample_bars(duplicate, [bucket()], metadata()).get("status") != "INVALID_DUPLICATE_SOURCE_BAR":
        errors.append("duplicate source interval was not rejected")
    future = deepcopy(bars)
    future.append(child(99, 4, 5, 103, 109, 101, 108, 120))
    if runtime.resample_bars(future, [bucket()], metadata()) != result:
        errors.append("future-known child changed the resampled parent")
    if runtime.resample_bars(bars[:-1], [bucket()], metadata()).get("status") != "CANNOT_DETERMINE_COVERAGE":
        errors.append("missing expected child interval was not detected")
    developing = deepcopy(bars)
    developing[-1]["bar_finality"] = "DEVELOPING"
    dev = runtime.resample_bars(developing, [bucket()], metadata(partial="EMIT_DEVELOPING"))
    if dev.get("status") != "DETERMINED" or dev["bars"][0].get("bar_finality") != "DEVELOPING":
        errors.append("partial parent was not explicitly emitted as developing")
    closed_result = runtime.r7.evaluate_utility({
        "operation": "closed_bar_eligible",
        "input": {
            "bar_finality": dev["bars"][0]["bar_finality"],
            "bar_known_at": dev["bars"][0]["known_at"],
            "evaluation_time": 100,
        },
    })
    if closed_result == "TRUE":
        errors.append("developing parent satisfied a closed-bar predicate")

    roles = runtime.resolve_roles("1m")
    structured_doc = {
        "base_frame": {"instrument_id": "TEST", "timeframe": "1m", "bars": bars},
        "setup_payload_templates": {},
        "resampling_requests": [
            {"role": "MTF", "parent_buckets": [bucket()], "metadata": metadata("1m", "5m")},
            {"role": "HTF", "parent_buckets": [bucket()], "metadata": metadata("1m", "30m")},
        ],
    }
    prepared = runtime._prepare_structured_frames(structured_doc, roles)
    if set(prepared) != {"LTF", "MTF", "HTF"} or any(prepared[x].get("resampling_status") != "DETERMINED" for x in ("MTF", "HTF")):
        errors.append("single structured OHLC did not derive only the requested coarser frames")

    if errors:
        print("TIMEFRAME/RESAMPLING VALIDATION: FAIL")
        for error in errors:
            print("FAIL:", error)
        return 2
    print("TIMEFRAME/RESAMPLING VALIDATION: PASS (8 mappings; explicit order; OHLC; coverage; duplicates; partial bars; known_at)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
