#!/usr/bin/env python3
"""Black-box structural audit of the complete MF01-C01 Expert-Brain graph."""
from pathlib import Path
import json
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    return yaml.safe_load((ROOT / "assets" / name).read_text(encoding="utf-8"))


def main():
    errors = []
    setups = load("setup-catalog.yaml")["setups"]
    authorities = load("runtime-authority-registry.yaml")["setup_runtime_authorities"]
    proofs = load("final-proof-matrix.yaml")["setup_proofs"]
    branches = load("branch-coverage-ledger.yaml")["branches"]
    fixtures = load("semantic-fixtures.yaml")["fixtures"]
    rule_coverage = load("rule-coverage-ledger.yaml")["rules"]
    claims = load("claim-ledger.yaml")["claims"]
    sources = load("source-index.yaml")["sources"]
    fixture_ids = {x["fixture_id"] for x in fixtures}
    coverage_by_rule = {x["rule_id"]: x for x in rule_coverage}
    claim_by_id = {x["claim_id"]: x for x in claims}
    source_ids = {x["source_id"] for x in sources}
    by_setup = {}
    for row in authorities:
        by_setup.setdefault(row["setup_id"], []).append(row)
    proof_by_setup = {x["setup_id"]: x for x in proofs}
    for setup in setups:
        sid = setup["setup_id"]
        if len(by_setup.get(sid, [])) != 1: errors.append(sid + ": runtime authority cardinality is not one")
        proof = proof_by_setup.get(sid, {})
        directions = {x.get("direction") for x in proof.get("direction_proofs", []) if x.get("applicable", True)}
        if setup.get("direction") == "BIDIRECTIONAL" and directions != {"BUY", "SELL"}: errors.append(sid + ": BUY/SELL proof incomplete")
    for rule in load("rule-catalog.yaml")["rules"]:
        if rule.get("status", "ACTIVE") != "ACTIVE": continue
        record = coverage_by_rule.get(rule["rule_id"])
        if not record: errors.append(rule["rule_id"] + ": missing Rule coverage record"); continue
        if not record.get("n_a_with_evidence") and (not record.get("true_fixture_ids") or not record.get("false_fixture_ids")):
            errors.append(rule["rule_id"] + ": incomplete Rule polarity proof")
    for branch in branches:
        if branch.get("applicable", True):
            if branch.get("executed") is not True or not branch.get("fixture_ids"): errors.append(branch.get("branch_id", "?") + ": unexecuted applicable branch")
            if not set(branch.get("fixture_ids", [])) <= fixture_ids: errors.append(branch.get("branch_id", "?") + ": unresolved fixture")
        elif not branch.get("na_reason"): errors.append(branch.get("branch_id", "?") + ": unexplained N/A")

    classes = (
        (load("ontology.yaml")["concepts"], "concept_id"),
        (load("formula-catalog.yaml")["formula_procedures"], "formula_or_procedure_id"),
        (load("rule-catalog.yaml")["rules"], "rule_id"),
        (setups, "setup_id"),
        (load("parameter-profile-registry.yaml")["profiles"], "profile_id"),
        (load("style-event-registry.yaml")["events"], "event_id"),
        (load("engine-interfaces.yaml")["components"], "component_id"),
        (authorities, "authority_id"),
    )
    for rows, id_key in classes:
        for row in rows:
            oid = row[id_key]
            for source_id in row.get("source_ids", []):
                if not source_id.startswith(("KX-AUTH-", "KX-FND-")) and source_id not in source_ids: errors.append(oid + ": unresolved source " + source_id)
            for claim_id in row.get("claim_ids", []):
                claim = claim_by_id.get(claim_id)
                if not claim or oid not in claim.get("downstream_object_ids", []): errors.append(oid + ": claim edge incomplete " + claim_id)

    graph = load("product-dependency-graph.yaml")
    if graph.get("mandatory_foundations_exactly") != ["SK01", "SK02"]: errors.append("dependency graph Foundation set invalid")
    caller_blob = re.sub(r"[\s-]+", "_", json.dumps(load("caller-input-contract.yaml"), ensure_ascii=False).lower())
    for forbidden in ("setup_direction", "setup_state", "confirmation_truth", "invalidation_truth", "expiry_truth", "style_event_truth"):
        if forbidden not in caller_blob: errors.append("caller prohibition missing " + forbidden)
    runtime_text = (ROOT / "scripts/reference_semantic_runtime.py").read_text(encoding="utf-8")
    if re.search(r"(?:SET|RULE)-PA-", runtime_text): errors.append("reference runtime hard-codes setup/rule IDs")
    if "expected_result" in runtime_text or "expected_output" in runtime_text: errors.append("reference runtime consumes stored answers")
    brain_text = (ROOT / "scripts/reference_expert_brain_runtime.py").read_text(encoding="utf-8")
    if "from reference_semantic_runtime import" not in brain_text or "evaluate_branch_details" not in brain_text:
        errors.append("Expert-Brain runtime does not invoke the R7 runtime interface")
    if re.search(r"RULE-PA-", brain_text):
        errors.append("Expert-Brain runtime hard-codes canonical Rule IDs")
    brain = load("expert-brain-runtime-authority.yaml")
    if brain.get("orchestration_grid") != {"setup_count": 18, "directions": ["BUY", "SELL"], "roles": ["LTF", "MTF", "HTF"], "expected_complete_three_frame_cells": 108}:
        errors.append("Expert-Brain orchestration grid contract mismatch")
    history = load("setup-history-requirement-registry.yaml").get("requirements", [])
    expected_history = {(x["setup_id"], direction) for x in setups for direction in ("BUY", "SELL")}
    actual_history = {(x.get("setup_id"), direction) for x in history for direction in x.get("directions", [])}
    if actual_history != expected_history:
        errors.append("Expert-Brain history coverage mismatch")
    expert_engines = {"ENG-PA-INPUT", "ENG-PA-TF-ROUTER", "ENG-PA-RESAMPLE", "ENG-PA-DATA-QA", "ENG-PA-HISTORY", "ENG-PA-SETUP-SCAN", "ENG-PA-SCORE", "ENG-PA-CROSS-TF", "ENG-PA-RANK", "ENG-PA-OUTPUT"}
    if not expert_engines <= {x["component_id"] for x in load("engine-interfaces.yaml")["components"]}:
        errors.append("Expert-Brain engine graph incomplete")
    for engine in load("engine-interfaces.yaml")["components"]:
        if "NONE" not in str(engine.get("developer_choice_points", "")).upper(): errors.append(engine["component_id"] + ": developer Trading guess point")
    if errors:
        print("END-PRODUCT GRAPH: FAIL")
        for error in errors: print("FAIL:", error)
        return 2
    print(f"END-PRODUCT GRAPH: PASS ({len(setups)} setups; {len(authorities)} authorities; {len(branches)} branches; {len(fixtures)} fixtures)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
