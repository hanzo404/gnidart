#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
REQ = [
    "SKILL.md", "references/doctrine-and-lineage.md", "references/current-professional-practice.md", "references/professional-workflow.md", "references/concepts-and-variants.md", "references/setups.md", "references/data-and-limitations.md", "references/engine-construction.md", "references/sources.md",
    "assets/foundation-import-manifest.yaml", "assets/source-requirement-profile.yaml", "assets/source-index.yaml", "assets/source-coverage-matrix.yaml", "assets/source-saturation-report.yaml", "assets/claim-ledger.yaml", "assets/rights-and-reuse-register.yaml", "assets/conflict-register.yaml", "assets/variant-registry.yaml", "assets/ontology.yaml", "assets/data-contract.yaml", "assets/formula-catalog.yaml", "assets/parameter-profile-registry.yaml", "assets/rule-catalog.yaml", "assets/setup-catalog.yaml", "assets/setup-saturation-ledger.yaml", "assets/style-event-registry.yaml", "assets/state-model.yaml", "assets/visual-contract.yaml", "assets/hypothesis-audit-schema.yaml", "assets/engine-interfaces.yaml", "assets/semantic-fixtures.yaml", "assets/build-manifest.json",
    "assets/runtime-authority-registry.yaml", "assets/final-proof-matrix.yaml", "assets/branch-coverage-ledger.yaml", "assets/ai-output-schema.yaml", "assets/caller-input-contract.yaml", "assets/product-dependency-graph.yaml",
    "assets/rule-coverage-ledger.yaml", "assets/runtime-time-expiry-proof-ledger.yaml",
    "scripts/reference_semantic_runtime.py", "scripts/validate_end_product_graph.py", "scripts/validate_skill.py", "scripts/validate_semantic_fixtures.py", "scripts/validate_math_contract.py", "scripts/validate_parity_contract.py", "scripts/validate_runtime_time_expiry.py", "references/final-product-black-box-audit.md", "references/runtime-time-expiry-closure.md",
    "references/expert-brain-orchestration.md", "assets/expert-brain-runtime-authority.yaml", "assets/timeframe-role-registry.yaml", "assets/resampling-policy-registry.yaml", "assets/setup-history-requirement-registry.yaml", "assets/setup-predicate-component-map.yaml", "assets/setup-strength-score-contract.yaml", "assets/cross-timeframe-relation-registry.yaml", "assets/ranking-contract.yaml", "scripts/reference_expert_brain_runtime.py", "scripts/validate_expert_brain.py", "scripts/validate_timeframe_resampling.py", "scripts/validate_scoring_cross_tf_ranking.py",
]
CONCEPT_FIELDS = ["concept_id","canonical_name","aliases","style_id","lineage_variant","exact_definition","trader_meaning","professional_purpose","not_the_same_as","primary_data_contract","required_data","optional_data","prohibited_substitutes","foundation_input_ids","input_types","input_semantics","units_scale","structural_location","spatial_rules","temporal_rules","formation_sequence","known_at","formula_procedure_ids","parameters","defaults_if_authoritative","thresholds_if_sourced","equality_tolerance","rounding","confirmation","disqualification","invalidation","expiry","true_output","false_output","unknown_output","missing_data","invalid_data","edge_cases","formalization_class","visual_class","pseudocode","engine_interface_id","source_ids","claim_ids","fixture_ids","version","status"]
FORMULA_FIELDS = ["formula_or_procedure_id","kind","purpose","source_ids","claim_ids","inputs","input_types","input_semantics","units_scales","preconditions","valid_domain","formula_algorithm","operation_order","time_window","sequence_rule","normalization","rounding","equality","tie_break","missing","invalid","edge_cases","known_at","output_type","output_semantics","pseudocode","engine_mapping","golden_fixture_ids"]
RULE_FIELDS = ["rule_id","target_object_ids","lineage_variant","primary_data_contract","required_inputs","known_at","preconditions","conditions","condition_order","thresholds_if_sourced","state_dependencies","true_output","false_output","unknown_output","invalidation","conflict_priority","source_ids","claim_ids","fixture_ids","pseudocode","engine_mapping"]
SETUP_FIELDS = ["setup_id","name","style_lineage_variant","direction","objective","market_context","primary_data_contract","required_data","optional_data","prerequisites","required_features","optional_features","formation_sequence","structural_placement","spatial_rules","temporal_rules","parameters","formulas","candidate_rule","pending_rule","armed_rule","trigger","confirmation","active_rule","invalidation","expiry","buy_logic","sell_logic","management_interpretation_if_native","exit_interpretation_if_native","conflicts","alternative_reads","near_miss","edge_cases","missing_data","cannot_determine","positive_fixtures","negative_fixtures","near_miss_fixtures","source_ids","claim_ids","pseudocode","engine_mapping"]
STATE_FIELDS = ["transition_id","from_state","event_condition","required_data","known_at","to_state","priority","conflict_rule","reset_rule","source_ids","claim_ids","fixture_ids"]
ENGINE_FIELDS = ["component_id","responsibility","inputs","outputs","data_types","preconditions","algorithm","pseudocode","state_dependencies","error_behavior","missing_data_behavior","determinism_requirement","performance_considerations","testable_acceptance_behavior","source_rule_traceability"]
PROFILE_FIELDS = ["profile_id","style_lineage_variant","purpose","source_ids","claim_ids","applies_to_rule_ids","applies_to_setup_ids","parameters","types","units","allowed_values_ranges","authoritative_defaults_if_any","caller_required_values","tolerance_equality","confirmation_rule","expiry_reset","known_at","missing_behavior","conflict_routing","status"]
ALLOWED_FORMAL = {"DETERMINISTIC","PARAMETERIZED_DETERMINISTIC","BOUNDED_HEURISTIC","VARIANT_DEPENDENT","EXPERT_JUDGMENT_REQUIRED","NOT_FORMALIZABLE_WITHOUT_DISTORTION"}
ALLOWED_VISUAL = {"VISUALLY_OBSERVABLE","VISUAL_WITH_METADATA_REQUIRED","VISUAL_PLUS_DATA_REQUIRED","DATA_ONLY","NOT_RELIABLY_DETERMINABLE"}


def load(name): return yaml.safe_load((ROOT / name).read_text())


def missing_fields(record, fields): return [f for f in fields if f not in record or record[f] in (None, "", [])]


def main():
    errors = []
    for name in REQ:
        if not (ROOT / name).is_file(): errors.append("missing file " + name)
    if errors:
        print("SKILL VALIDATION: FAIL"); [print("FAIL:", e) for e in errors]; return 2
    fm = yaml.safe_load(re.match(r"^---\n(.*?)\n---", (ROOT/"SKILL.md").read_text(), re.S).group(1))
    if fm.get("name") != "kx-professional-classical-price-action-expert": errors.append("frontmatter name mismatch")
    fi, dc, src, rights, claims = load("assets/foundation-import-manifest.yaml"), load("assets/data-contract.yaml"), load("assets/source-index.yaml")["sources"], load("assets/rights-and-reuse-register.yaml")["rights"], load("assets/claim-ledger.yaml")["claims"]
    expected_hashes = {"SK01":"f9c85f33444f593ac43883c229deea4e979c0bcfd245bade4a3171c1f770caf6", "SK02":"c8f9751173b39154f79ae8e63b580d4ae7e471c1a407bdef5088674ee8c17517"}
    for f in fi["mandatory_foundations"]:
        if f["skill_id"] in expected_hashes and f["sha256"] != expected_hashes[f["skill_id"]]: errors.append("foundation hash mismatch " + f["skill_id"])
    if {f["skill_id"] for f in fi["mandatory_foundations"]} != {"SK01","SK02"}: errors.append("mandatory foundations must be exactly SK01/SK02")
    if dc.get("primary_data_contract_id") != "DT-P1": errors.append("data contract is not DT-P1")
    accepted_ids = {s["source_id"] for s in src if s["accept_or_reject"] == "ACCEPT"}; all_src_ids = {s["source_id"] for s in src}
    if {r["source_id"] for r in rights} != accepted_ids: errors.append("rights coverage does not exactly match accepted sources")
    claim_ids = {c["claim_id"] for c in claims}
    for c in claims:
        if not c["downstream_object_ids"]: errors.append(c["claim_id"] + " has no downstream objects")
        if not set(c["source_ids"]) <= all_src_ids: errors.append(c["claim_id"] + " has unresolved sources")
    concepts = load("assets/ontology.yaml")["concepts"]
    formulas = load("assets/formula-catalog.yaml")["formula_procedures"]
    rules = load("assets/rule-catalog.yaml")["rules"]
    setups = load("assets/setup-catalog.yaml")["setups"]
    runtime_authorities = load("assets/runtime-authority-registry.yaml")["setup_runtime_authorities"]
    authority_by_setup = {}
    for authority in runtime_authorities:
        authority_by_setup.setdefault(authority["setup_id"], []).append(authority)
    profiles = load("assets/parameter-profile-registry.yaml")["profiles"]
    event_ids = {e["event_id"] for e in load("assets/style-event-registry.yaml")["events"]}
    engines = load("assets/engine-interfaces.yaml")["components"]
    engine_ids = {e["component_id"] for e in engines}
    expert_engine_ids = {
        "ENG-PA-INPUT", "ENG-PA-TF-ROUTER", "ENG-PA-RESAMPLE", "ENG-PA-DATA-QA", "ENG-PA-HISTORY",
        "ENG-PA-SETUP-SCAN", "ENG-PA-SCORE", "ENG-PA-CROSS-TF", "ENG-PA-RANK", "ENG-PA-OUTPUT",
    }
    if not expert_engine_ids <= engine_ids: errors.append("Expert-Brain engine interface set incomplete")
    fixture_ids = {f["fixture_id"] for f in load("assets/semantic-fixtures.yaml")["fixtures"]}
    fixture_rows = load("assets/semantic-fixtures.yaml")["fixtures"]
    caller = load("assets/caller-input-contract.yaml")
    allowed_normalized = set(caller.get("machine_contract", {}).get("allowed_normalized_input_keys", []))
    forbidden_semantic = {"scenario_direction", "setup_state", "confirmation_truth", "invalidation_truth", "expiry_truth", "precomputed_style_event", "gap_branch", "no_trade_reason", "event_profile_id", "confirmation_rule_id", "expiry_profile_id", "expiry_mode", "reset_event_id"}
    if not allowed_normalized or allowed_normalized & forbidden_semantic: errors.append("caller normalized-input allowlist invalid")
    expert_fields = caller.get("expert_brain_contract", {}).get("top_level_fields", {})
    if expert_fields.get("user_hypothesis") != "OPTIONAL_RAW_AUDIT_TARGET" or expert_fields.get("user_hypothesis_audit") != "PROHIBITED_CALLER_RESULT":
        errors.append("Expert-Brain caller hypothesis firewall is incomplete")
    for fixture in fixture_rows:
        normalized = fixture.get("normalized_inputs", {})
        if isinstance(normalized, dict) and set(normalized) & forbidden_semantic: errors.append(fixture["fixture_id"] + " carries semantic caller input")
    for c in concepts:
        m = missing_fields(c, CONCEPT_FIELDS)
        if m: errors.append(c.get("concept_id","?") + " missing concept fields " + ",".join(m))
        if not set(c["source_ids"]) <= all_src_ids or not set(c["claim_ids"]) <= claim_ids: errors.append(c["concept_id"] + " unresolved provenance")
        if c["engine_interface_id"] not in engine_ids: errors.append(c["concept_id"] + " unresolved engine interface")
        if c["formalization_class"] not in ALLOWED_FORMAL: errors.append(c["concept_id"] + " invalid formalization class")
        if c["visual_class"] not in ALLOWED_VISUAL: errors.append(c["concept_id"] + " invalid visual class")
    for f in formulas:
        m = missing_fields(f, FORMULA_FIELDS)
        if m: errors.append(f.get("formula_or_procedure_id","?") + " missing formula fields " + ",".join(m))
        if not set(f["source_ids"]) <= all_src_ids or not set(f["claim_ids"]) <= claim_ids: errors.append(f["formula_or_procedure_id"] + " unresolved provenance")
        if not set(f["golden_fixture_ids"]) <= fixture_ids: errors.append(f["formula_or_procedure_id"] + " missing golden fixture")
    for r in rules:
        m = missing_fields(r, RULE_FIELDS)
        if m: errors.append(r.get("rule_id","?") + " missing rule fields " + ",".join(m))
        if not set(r["source_ids"]) <= all_src_ids or not set(r["claim_ids"]) <= claim_ids: errors.append(r["rule_id"] + " unresolved provenance")
        if r.get("status", "ACTIVE") == "ACTIVE" and not set(r["fixture_ids"]) <= fixture_ids: errors.append(r["rule_id"] + " unresolved fixture IDs")
    rule_coverage = {x["rule_id"]: x for x in load("assets/rule-coverage-ledger.yaml")["rules"]}
    for rule in rules:
        if rule.get("status", "ACTIVE") != "ACTIVE": continue
        record = rule_coverage.get(rule["rule_id"])
        if not record: errors.append(rule["rule_id"] + " missing active Rule coverage record"); continue
        if not record.get("n_a_with_evidence") and (not record.get("true_fixture_ids") or not record.get("false_fixture_ids")):
            errors.append(rule["rule_id"] + " incomplete polarity proof")
        for key in ("true_fixture_ids", "false_fixture_ids", "cannot_determine_fixture_ids", "invalid_fixture_ids", "near_miss_fixture_ids"):
            if not set(record.get(key, [])) <= fixture_ids: errors.append(rule["rule_id"] + " unresolved Rule coverage fixture")
    for s in setups:
        m = missing_fields(s, SETUP_FIELDS)
        if m: errors.append(s.get("setup_id","?") + " missing setup fields " + ",".join(m))
        refs = set(s["positive_fixtures"] + s["negative_fixtures"] + s["near_miss_fixtures"])
        if not refs <= fixture_ids: errors.append(s["setup_id"] + " unresolved fixture IDs")
        if not set(s["source_ids"]) <= all_src_ids or not set(s["claim_ids"]) <= claim_ids: errors.append(s["setup_id"] + " unresolved provenance")
        if not set(s["predicate_rule_ids"]) <= {r["rule_id"] for r in rules}: errors.append(s["setup_id"] + " unresolved predicate rule IDs")
        authority=s.get("lifecycle_authority",{})
        registry_rows = authority_by_setup.get(s["setup_id"], [])
        if authority.get("source_of_truth")!="CANONICAL_RULE_ID_LIFECYCLE" or authority.get("authority_scope")!="LEGACY_NON_EXECUTABLE_RULE_GROUP_PROJECTION" or len(registry_rows) != 1:
            errors.append(s["setup_id"]+" must have exactly one runtime-registry lifecycle authority")
            registry_authority = {}
        else:
            registry_authority = registry_rows[0]
            if s.get("runtime_authority_id") != registry_authority.get("authority_id"):
                errors.append(s["setup_id"]+" runtime authority ID mismatch")
            if registry_authority.get("reset_policy", {}).get("mode") != "NOT_SUPPORTED" or registry_authority.get("reset_rule_ids") not in ([], None):
                errors.append(s["setup_id"] + " reset authority divergence")
            if registry_authority.get("expiry_policy", {}).get("mode") != "CONFIRMED_BARS":
                errors.append(s["setup_id"] + " expiry authority divergence")
        mirror_map={"candidate_rule":"candidate_rule_ids","pending_rule":"pending_rule_ids","armed_rule":"armed_rule_ids","active_rule":"active_rule_ids"}
        for field,key in mirror_map.items():
            if s.get(field,{}).get("generated_from_rule_ids") != registry_authority.get(key):
                errors.append(s["setup_id"]+f" lifecycle mirror divergence {field}")
    state_doc = load("assets/state-model.yaml")
    for t in state_doc["transitions"]:
        m = missing_fields(t, STATE_FIELDS)
        if m: errors.append(t.get("transition_id","?") + " missing state fields " + ",".join(m))
        if not set(t["fixture_ids"]) <= fixture_ids: errors.append(t["transition_id"] + " unresolved fixture IDs")
    for e in engines:
        m = missing_fields(e, ENGINE_FIELDS)
        if m: errors.append(e.get("component_id","?") + " missing engine fields " + ",".join(m))
        if e["component_id"] in expert_engine_ids and str(e.get("developer_choice_points", "")).upper() != "NONE":
            errors.append(e["component_id"] + " has an Expert-Brain developer choice point")
    profile_ids = {p["profile_id"] for p in profiles}
    for p in profiles:
        m = missing_fields(p, PROFILE_FIELDS)
        if m: errors.append(p.get("profile_id","?") + " missing profile fields " + ",".join(m))
        if not set(p["source_ids"]) <= all_src_ids or not set(p["claim_ids"]) <= claim_ids: errors.append(p["profile_id"] + " unresolved provenance")
        if not set(p["applies_to_rule_ids"]) <= {r["rule_id"] for r in rules}: errors.append(p["profile_id"] + " unresolved rule IDs")
        if not set(p["applies_to_setup_ids"]) <= {s["setup_id"] for s in setups}: errors.append(p["profile_id"] + " unresolved setup IDs")
    resolvable_downstream = (
        {c["concept_id"] for c in concepts} |
        {f["formula_or_procedure_id"] for f in formulas} |
        {r["rule_id"] for r in rules} |
        {s["setup_id"] for s in setups} |
        engine_ids |
        {v["variant_id"] for v in load("assets/variant-registry.yaml")["variants"]} |
        {x["conflict_id"] for x in load("assets/conflict-register.yaml")["conflicts"]} |
        {x["state_id"] for x in state_doc["state_records"]} |
        profile_ids |
        event_ids |
        {x["authority_id"] for x in runtime_authorities} |
        {"DC-DT-P1", "IMP-SK01", "IMP-SK02", "CPM-PA-2026", "AUD-PA-HYPOTHESIS", "AI-PA-OUTPUT", "SETUP-CATALOG"}
    )
    for c in claims:
        unresolved = set(c["downstream_object_ids"]) - resolvable_downstream
        if unresolved: errors.append(c["claim_id"] + " unresolved downstream IDs " + ",".join(sorted(unresolved)))
    coverage = load("assets/source-coverage-matrix.yaml")["records"]
    material_ids = ({c["concept_id"] for c in concepts} | {f["formula_or_procedure_id"] for f in formulas} | {r["rule_id"] for r in rules} | {s["setup_id"] for s in setups} | (engine_ids - expert_engine_ids) | profile_ids | event_ids | {x["authority_id"] for x in runtime_authorities})
    covered_ids = {x["object_id"] for x in coverage if x.get("coverage_status") == "PASS"}
    if not material_ids <= covered_ids: errors.append("source coverage missing material IDs " + ",".join(sorted(material_ids-covered_ids)))
    sat = load("assets/source-saturation-report.yaml")
    if sat["status"] != "SATURATED" or sat["independent_second_pass"] is not True: errors.append("source saturation/second pass not complete")
    time_contract = dc.get("runtime_time_contract", {})
    if time_contract.get("equality_rule") != "NEVER_UNIVERSALLY_REQUIRE_TIMESTAMP_EQUALS_KNOWN_AT":
        errors.append("runtime time contract does not preserve timestamp/known-at separation")
    proof_ledger = load("assets/runtime-time-expiry-proof-ledger.yaml")
    directional = proof_ledger.get("directional_proofs", [])
    ledger_pairs = {
        (row.get("setup_id"), direction, row.get(direction))
        for row in directional for direction in ("BUY", "SELL")
    }
    expected_pairs = {(setup_id, direction) for setup_id in authority_by_setup for direction in ("BUY", "SELL")}
    actual_pairs = {(setup_id, direction) for setup_id, direction, fixture_id in ledger_pairs if fixture_id in fixture_ids}
    if len(directional) != 18 or len(ledger_pairs) != 36 or actual_pairs != expected_pairs:
        errors.append("R7 Runtime Time/Expiry directional proof ledger incomplete")
    brain = load("assets/expert-brain-runtime-authority.yaml")
    if brain.get("orchestration_grid", {}).get("expected_complete_three_frame_cells") != 108:
        errors.append("Expert-Brain complete grid is not 108 cells")
    if brain.get("baseline_foundations_exactly") != ["SK01", "SK02"]:
        errors.append("Expert-Brain Foundation set is not exactly SK01/SK02")
    tf_profiles = load("assets/timeframe-role-registry.yaml").get("profiles", [])
    operational = next((x for x in tf_profiles if x.get("profile_id") == "KX_RELATIVE_5X_APPROX_V1"), {})
    if len(operational.get("mappings", [])) != 8:
        errors.append("Expert-Brain operational timeframe mapping must have eight rows")
    history = load("assets/setup-history-requirement-registry.yaml").get("requirements", [])
    history_pairs = {(x.get("setup_id"), direction) for x in history for direction in x.get("directions", [])}
    if history_pairs != {(x["setup_id"], direction) for x in setups for direction in ("BUY", "SELL")}:
        errors.append("Expert-Brain setup-history coverage is not exactly 18 x 2")
    exact_history = [x for x in history if x.get("minimum_confirmed_bars") is not None]
    dependency_history = [x for x in history if x.get("evaluation_mode") == "ACTUAL_DEPENDENCY_CLOSURE"]
    if {(x["setup_id"], x.get("minimum_confirmed_bars")) for x in exact_history} != {
        ("SET-PA-INSIDE-BREAK", 2), ("SET-PA-OUTSIDE-RESOLVE", 2)
    } or len(dependency_history) != 16:
        errors.append("history authority must contain exactly two proved finite minima and sixteen dependency-closure families")
    output_schema = load("assets/ai-output-schema.yaml")
    required_output = {"ltf_complete_setup_table", "mtf_complete_setup_table", "htf_complete_setup_table", "active_pool_ranking", "pending_pool_ranking", "strongest_current_active_setup", "strongest_current_pending_setup", "final_expert_comparative_assessment"}
    if not required_output <= set(output_schema.get("expert_brain_required_fields", {})):
        errors.append("Expert-Brain output schema is incomplete")
    record_fields = set(output_schema.get("expert_brain_directional_setup_record", {}).get("fields", []))
    c1_record_fields = {"raw_r7_lifecycle_substate", "history_evidence_status", "history_request_required", "history_request_reason", "requested_additional_history", "history_availability", "next_required_event", "lifecycle_completion"}
    if not c1_record_fields <= record_fields:
        errors.append("C1 history/lifecycle directional output fields are incomplete")
    verdicts = set(output_schema.get("user_hypothesis_audit_contract", {}).get("verdict_enum", []))
    if verdicts != {"MATCH", "PARTIAL_MATCH", "NOT_MATCH", "CANNOT_DETERMINE"}:
        errors.append("runtime-derived hypothesis verdict enum is incomplete")
    manifest = json.loads((ROOT/"assets/build-manifest.json").read_text())
    actual_counts = {"sources":len(src),"accepted_sources":len(accepted_ids),"claims":len(claims),"concepts":len(concepts),"formulas_procedures":len(formulas),"parameter_profiles":len(profiles),"rules":len(rules),"setups":len(setups),"state_transitions":len(state_doc["transitions"]),"semantic_fixtures":len(load("assets/semantic-fixtures.yaml")["fixtures"]),"engine_interfaces":len(engines)}
    if manifest["counts"] != actual_counts: errors.append("manifest counts mismatch")
    if manifest["state"] not in {"RETURNED_FOR_CONTROL_ROOM_FINAL_AUDIT", "FINAL_ACCEPTED_LOCKED"} or manifest["work_self_acceptance"] is not False:
        errors.append("manifest state/self-acceptance invalid")
    if manifest["state"] == "FINAL_ACCEPTED_LOCKED":
        final_identity = load("governance/PRODUCT_IDENTITY_AND_FINAL_ACCEPTANCE.yaml")
        if final_identity.get("status") != "FINAL_ACCEPTED_LOCKED" or final_identity.get("product_id") != "KX_PROFESSIONAL_CLASSICAL_PRICE_ACTION_EXPERT":
            errors.append("final Control Room identity/acceptance record invalid")
    actual_files = {
        p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in ROOT.rglob("*")
        if p.is_file() and ".git" not in p.parts and "__pycache__" not in p.parts and not p.name.endswith(".pyc") and p.relative_to(ROOT).as_posix() != "assets/build-manifest.json"
    }
    if manifest.get("file_hashes_excluding_manifest") != actual_files: errors.append("manifest file-hash inventory mismatch")
    material_exclusions = {"assets/build-manifest.json", "assets/final-proof-matrix.yaml", "assets/branch-coverage-ledger.yaml", "assets/final-acceptance-evidence.yaml", "references/final-product-black-box-audit.md"}
    digest = hashlib.sha256()
    for rel in sorted(actual_files):
        if rel in material_exclusions: continue
        digest.update(rel.encode()); digest.update(b"\0"); digest.update((ROOT/rel).read_bytes()); digest.update(b"\0")
    if manifest.get("material_content_freeze_sha256") != digest.hexdigest(): errors.append("material content freeze mismatch")
    text = "\n".join(p.read_text(errors="ignore") for p in ROOT.rglob("*.md"))
    if manifest["state"] != "FINAL_ACCEPTED_LOCKED":
        if re.search(r"\bFINAL_ACCEPTED_LOCKED\b", text) and "Do not" not in text:
            errors.append("self-lock language detected")
    forbidden_terms = (
        "return row[" + "\"ex" + "pected\"]",
        "return row[" + "'ex" + "pected']",
        "choose a " + "reasonable",
        "use appropriate " + "logic",
    )
    for term in forbidden_terms:
        for p in ROOT.rglob("*"):
            if p.resolve() == Path(__file__).resolve(): continue
            if p.is_file() and p.suffix in (".py",".yaml",".md") and term.lower() in p.read_text(errors="ignore").lower(): errors.append("forbidden shortcut/vagueness in " + str(p.relative_to(ROOT)))
    if errors:
        print("SKILL VALIDATION: FAIL"); [print("FAIL:", e) for e in errors]; return 2
    print("SKILL VALIDATION: PASS", json.dumps(actual_counts, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
