#!/usr/bin/env python3
"""MF01-C01 Expert-Brain conformance runtime.

This module orchestrates the immutable R7 single-timeframe runtime. It does not
implement Price Action predicates, lifecycle transitions, or order execution.
"""
from __future__ import annotations

from copy import deepcopy
from fractions import Fraction
from pathlib import Path
import argparse
import json
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from reference_semantic_runtime import (  # noqa: E402
    CD,
    INVALID,
    MISSING,
    SemanticRuntime,
    known_at_view,
)

ROLES = ("LTF", "MTF", "HTF")
DIRECTIONS = ("BUY", "SELL")
CURRENT_STATES = {"CANDIDATE", "PENDING", "ARMED", "ACTIVE"}
INTRINSIC_COMPONENTS = {
    "CONTEXT_FIT",
    "LOCATION_GEOMETRY_FIT",
    "FORMATION_INTEGRITY",
    "EVIDENCE_QUALITY",
}
AUTHORITY_FIELDS = (
    "context_rule_ids",
    "candidate_rule_ids",
    "pending_rule_ids",
    "armed_rule_ids",
    "trigger_rule_ids",
    "confirmation_rule_ids",
    "active_rule_ids",
    "invalidation_rule_ids",
    "expiry_rule_ids",
)
TIMEFRAME_RANK = {
    "1m": 1, "3m": 2, "5m": 3, "15m": 4, "30m": 5,
    "1h": 6, "2h": 7, "4h": 8, "8h": 9,
    "1D": 10, "1W": 11, "1M": 12,
}
QUALITY_RANK = {"VALID": 3, "CANNOT_DETERMINE": 1, "INVALID": 0}
HISTORY_AVAILABILITY = {"UNKNOWN", "MORE_AVAILABLE", "NO_MORE_AVAILABLE"}
HISTORY_SUFFICIENT = "HISTORY_SUFFICIENT"
MORE_HISTORY_REQUIRED = "MORE_HISTORY_REQUIRED"
HISTORY_INSUFFICIENT_EXACT = "HISTORY_INSUFFICIENT_EXACT"
NO_MORE_HISTORY_CD = "NO_MORE_HISTORY_CANNOT_DETERMINE"
CALLER_VERDICT_FIELDS = {
    "user_hypothesis_audit", "final_verdict", "verdict", "audit_result",
    "support_result", "conflict_result", "structurally_qualified",
    "hypothesis_verdict", "setup_state", "next_required_rule_truth",
}


def load_yaml(relative_path):
    return yaml.safe_load((ROOT / relative_path).read_text(encoding="utf-8"))


def ratio(numerator, denominator):
    if denominator == 0:
        return {"status": CD, "numerator": 0, "denominator": 0, "display_percent": None}
    return {
        "status": "DETERMINED",
        "numerator": int(numerator),
        "denominator": int(denominator),
        "display_percent": round(100 * numerator / denominator, 6),
    }


def fraction_of(record, default=Fraction(-1, 1)):
    if not isinstance(record, dict) or record.get("status") != "DETERMINED":
        return default
    den = record.get("denominator")
    num = record.get("numerator")
    if type(num) is not int or type(den) is not int or den <= 0:
        return default
    return Fraction(num, den)


class ExpertBrainRuntime:
    def __init__(self):
        self.r7 = SemanticRuntime()
        self.authority = load_yaml("assets/expert-brain-runtime-authority.yaml")
        self.timeframes = load_yaml("assets/timeframe-role-registry.yaml")
        self.resampling = load_yaml("assets/resampling-policy-registry.yaml")
        self.history_doc = load_yaml("assets/setup-history-requirement-registry.yaml")
        self.component_doc = load_yaml("assets/setup-predicate-component-map.yaml")
        self.strength_doc = load_yaml("assets/setup-strength-score-contract.yaml")
        self.cross_tf_doc = load_yaml("assets/cross-timeframe-relation-registry.yaml")
        self.ranking_doc = load_yaml("assets/ranking-contract.yaml")
        self.setup_ids = list(self.r7.authorities)
        self.setup_names = {x["setup_id"]: x.get("name", x["setup_id"]) for x in self.r7.setup_doc["setups"]}
        self.history_index = {}
        for row in self.history_doc["requirements"]:
            for direction in row["directions"]:
                self.history_index[(row["setup_id"], direction, row["profile_id"])] = row
        self.component_by_field = {
            row["authority_field"]: row for row in self.component_doc["classification_order"]
        }

    def resolve_roles(self, input_timeframe, explicit_roles=None, profile_id="KX_RELATIVE_5X_APPROX_V1"):
        if explicit_roles is not None:
            if set(explicit_roles) != set(ROLES):
                return {"status": "CANNOT_DETERMINE_TIMEFRAME_ROUTING", "roles": {}}
            labels = [explicit_roles[x] for x in ROLES]
            if any(x not in TIMEFRAME_RANK for x in labels) or not (
                TIMEFRAME_RANK[labels[0]] < TIMEFRAME_RANK[labels[1]] < TIMEFRAME_RANK[labels[2]]
            ):
                return {"status": "CANNOT_DETERMINE_TIMEFRAME_ROUTING", "roles": {}}
            return {"status": "DETERMINED_EXPLICIT", "roles": dict(explicit_roles)}
        profile = next((x for x in self.timeframes["profiles"] if x["profile_id"] == profile_id), None)
        mapping = next((x for x in (profile or {}).get("mappings", []) if x["input"] == input_timeframe), None)
        if not mapping:
            return {"status": "CANNOT_DETERMINE_TIMEFRAME_ROUTING", "roles": {}}
        return {"status": "DETERMINED_KX_OPERATIONAL", "roles": {x: mapping[x] for x in ROLES}}

    @staticmethod
    def _validate_bar(bar):
        required = {
            "interval_start", "interval_end", "timestamp", "open", "high", "low", "close",
            "bar_finality", "known_at", "session_id",
        }
        if not isinstance(bar, dict) or not required <= set(bar):
            return False
        if bar["bar_finality"] not in {"DEVELOPING", "CONFIRMED", "REVISED"}:
            return False
        if any(type(bar[x]) not in {int, float} or isinstance(bar[x], bool) for x in ("open", "high", "low", "close", "known_at")):
            return False
        return bar["high"] >= max(bar["open"], bar["close"]) and bar["low"] <= min(bar["open"], bar["close"]) and bar["high"] >= bar["low"]

    def resample_bars(self, source_bars, parent_buckets, metadata):
        required_metadata = set(self.resampling["required_metadata"])
        if not isinstance(metadata, dict) or not required_metadata <= set(metadata):
            return {"status": "CANNOT_DETERMINE_SESSION_ALIGNMENT", "bars": []}
        source_tf, target_tf = metadata["source_timeframe"], metadata["target_timeframe"]
        if source_tf not in TIMEFRAME_RANK or target_tf not in TIMEFRAME_RANK:
            return {"status": "CANNOT_DETERMINE_TIMEFRAME_ROUTING", "bars": []}
        if TIMEFRAME_RANK[target_tf] <= TIMEFRAME_RANK[source_tf]:
            return {"status": "CANNOT_DERIVE_LOWER_TIMEFRAME", "bars": []}
        if metadata["duplicate_policy"] != "REJECT":
            return {"status": "INVALID_DUPLICATE_SOURCE_BAR", "bars": []}
        if metadata["partial_target_policy"] not in {"EMIT_DEVELOPING", "REJECT"}:
            return {"status": "INVALID_SOURCE_BAR", "bars": []}
        if metadata["missing_bar_policy"] not in {"REQUIRE_COMPLETE_EXPECTED_SET", "SOURCE_OMITS_EMPTY_INTERVALS"}:
            return {"status": "CANNOT_DETERMINE_COVERAGE", "bars": []}
        if not isinstance(source_bars, list) or not source_bars or any(not self._validate_bar(x) for x in source_bars):
            return {"status": "INVALID_SOURCE_BAR", "bars": []}
        evaluation_cut = metadata.get("evaluation_cut")
        if type(evaluation_cut) not in {int, float} or isinstance(evaluation_cut, bool):
            return {"status": "CANNOT_DETERMINE_CLOCK_RELATION", "bars": []}
        eligible = [x for x in source_bars if x["known_at"] <= evaluation_cut]
        keys = [(x["interval_start"], x["interval_end"], x["session_id"]) for x in eligible]
        if len(keys) != len(set(keys)):
            return {"status": "INVALID_DUPLICATE_SOURCE_BAR", "bars": []}
        ordered = sorted(eligible, key=lambda x: (x["interval_start"], x["known_at"]))
        out = []
        for index, bucket in enumerate(parent_buckets or []):
            if not {"interval_start", "interval_end", "parent_end_known_at", "session_id"} <= set(bucket):
                return {"status": "CANNOT_DETERMINE_SESSION_ALIGNMENT", "bars": []}
            if type(bucket["parent_end_known_at"]) not in {int, float} or isinstance(bucket["parent_end_known_at"], bool):
                return {"status": "CANNOT_DETERMINE_CLOCK_RELATION", "bars": []}
            if bucket["parent_end_known_at"] > evaluation_cut:
                continue
            children = [
                x for x in ordered
                if x["session_id"] == bucket["session_id"]
                and x["interval_start"] >= bucket["interval_start"]
                and x["interval_end"] <= bucket["interval_end"]
            ]
            if not children:
                continue
            expected = bucket.get("expected_child_intervals")
            actual = [[x["interval_start"], x["interval_end"]] for x in children]
            if metadata["missing_bar_policy"] == "REQUIRE_COMPLETE_EXPECTED_SET":
                if not isinstance(expected, list) or sorted(expected) != sorted(actual):
                    return {"status": "CANNOT_DETERMINE_COVERAGE", "bars": []}
            elif bucket.get("source_omits_empty_intervals_confirmed") is not True:
                return {"status": "CANNOT_DETERMINE_COVERAGE", "bars": []}
            all_confirmed = all(x["bar_finality"] == "CONFIRMED" for x in children)
            if not all_confirmed and metadata["partial_target_policy"] == "REJECT":
                return {"status": "INVALID_SOURCE_BAR", "bars": []}
            first, last = children[0], children[-1]
            known_at_values = [bucket["parent_end_known_at"]] + [x["known_at"] for x in children]
            if any(type(x) not in {int, float} or isinstance(x, bool) for x in known_at_values):
                return {"status": "CANNOT_DETERMINE_CLOCK_RELATION", "bars": []}
            out.append({
                "interval_start": bucket["interval_start"],
                "interval_end": bucket["interval_end"],
                "timestamp": bucket["interval_start"] if metadata["timestamp_label_role"] == "INTERVAL_START" else bucket["interval_end"],
                "open": first["open"],
                "high": max(x["high"] for x in children),
                "low": min(x["low"] for x in children),
                "close": last["close"],
                "finality": "CONFIRMED" if all_confirmed else "DEVELOPING",
                "bar_finality": "CONFIRMED" if all_confirmed else "DEVELOPING",
                "known_at": max(known_at_values),
                "session_id": bucket["session_id"],
                "index": index,
                "aggregation_provenance": {
                    "policy_id": self.resampling["policy_id"],
                    "source_indices": [x.get("index") for x in children],
                    "availability_clock_id": metadata["availability_clock_id"],
                },
            })
        return {"status": "DETERMINED", "bars": out}

    @staticmethod
    def _history_result(status, availability, reason, request_required=False, requested=None, required=None, observed=0):
        return {
            "status": status,
            "history_evidence_status": status,
            "history_request_required": bool(request_required),
            "history_request_reason": reason,
            "requested_additional_history": requested,
            "history_availability": availability,
            "required": required,
            "observed": observed,
        }

    def history_status(self, setup_id, direction, payload, state=None, outcomes=None, authority=None, history_availability="UNKNOWN"):
        ni = payload.get("normalized_inputs", {}) if isinstance(payload, dict) else {}
        profile_id = ni.get("profile_id")
        row = self.history_index.get((setup_id, direction, profile_id))
        availability = history_availability if history_availability in HISTORY_AVAILABILITY else "UNKNOWN"
        if not row:
            reason = "No setup-direction-profile history authority record is available."
            status = NO_MORE_HISTORY_CD if availability == "NO_MORE_AVAILABLE" else MORE_HISTORY_REQUIRED
            return self._history_result(
                status, availability, reason,
                request_required=availability != "NO_MORE_AVAILABLE",
                requested=None if availability == "NO_MORE_AVAILABLE" else {
                    "kind": "EARLIER_OHLC", "exact_count": None,
                    "request": "Provide additional earlier OHLC rows for this affected timeframe.",
                },
            )
        evaluation_time = ni.get("evaluation_time")
        session_id = ni.get("session_id")
        bars = payload.get("raw_dt_p1", {}).get("bars", []) if isinstance(payload, dict) else []
        observed = sum(
            1 for x in bars
            if x.get("bar_finality") == "CONFIRMED"
            and x.get("session_id") == session_id
            and isinstance(evaluation_time, (int, float))
            and isinstance(x.get("known_at"), (int, float))
            and x["known_at"] <= evaluation_time
        )
        required = row.get("minimum_confirmed_bars")
        if isinstance(required, int) and required > 0:
            if observed >= required:
                return self._history_result(HISTORY_SUFFICIENT, availability, "The exact finite history minimum is satisfied.", required=required, observed=observed)
            missing = required - observed
            reason = f"The exact setup dependency requires {required} confirmed same-session bars; {observed} are available at the evaluation cut."
            if availability == "NO_MORE_AVAILABLE":
                return self._history_result(NO_MORE_HISTORY_CD, availability, reason, required=required, observed=observed)
            return self._history_result(
                HISTORY_INSUFFICIENT_EXACT, availability, reason, request_required=True,
                requested={
                    "kind": "EARLIER_OHLC", "exact_count": missing,
                    "request": f"Provide {missing} additional earlier confirmed OHLC bar{'s' if missing != 1 else ''} for this affected timeframe.",
                }, required=required, observed=observed,
            )

        authority = authority or self.r7.authorities.get(setup_id, {})
        outcomes = outcomes or {}
        reached_field = {
            "CANDIDATE": "candidate_rule_ids", "PENDING": "pending_rule_ids",
            "ARMED": "armed_rule_ids", "ACTIVE": "active_rule_ids",
        }.get(state)
        if reached_field:
            material_ids = list(authority.get(reached_field, []))
        else:
            material_ids = list(authority.get("candidate_rule_ids", []))
        material_ids.extend(authority.get("invalidation_rule_ids", []))
        material_ids.extend(authority.get("expiry_rule_ids", []))
        material_ids = list(dict.fromkeys(material_ids))
        material_values = [outcomes.get(rule_id) for rule_id in material_ids]
        dependency_closed = bool(material_ids) and all(value in {"TRUE", "FALSE"} for value in material_values)
        if dependency_closed:
            return self._history_result(
                HISTORY_SUFFICIENT, availability,
                "The actual current R7/Foundation dependency closure is determinable at the evaluation cut.",
                required=None, observed=observed,
            )
        reason = row.get("reason") or "One or more material current-evaluation dependencies can remain unresolved because left history is truncated."
        if availability == "NO_MORE_AVAILABLE":
            return self._history_result(NO_MORE_HISTORY_CD, availability, reason, required=None, observed=observed)
        return self._history_result(
            MORE_HISTORY_REQUIRED, availability, reason, request_required=True,
            requested={
                "kind": "EARLIER_OHLC", "exact_count": None,
                "request": "Provide additional earlier OHLC rows for this affected timeframe, then re-evaluate at the same evaluation cut.",
            }, required=None, observed=observed,
        )

    def _rule_outcomes(self, setup_id, payload, direction):
        authority = self.r7.authorities[setup_id]
        if not isinstance(payload, dict) or self.r7.validate_caller(payload) != "TRUE":
            return {}
        view = deepcopy(payload)
        view["setup_id"] = setup_id
        if self.r7._profile_check(view, authority) != "TRUE":
            return {}
        now = view.get("normalized_inputs", {}).get("evaluation_time")
        if type(now) not in {int, float} or self.r7.validate_foundations(view) != "TRUE":
            return {}
        first_candidate = self.r7.first_candidate_known_at(setup_id, deepcopy(view), direction, authority)
        view = self.r7._view_at_cut(view, setup_id, authority, direction, now)
        derived = self.r7.derive_events(view, authority, first_candidate_known_at=first_candidate)
        if derived is MISSING:
            return {}
        view["derived_events"] = derived
        ids = []
        for field in AUTHORITY_FIELDS:
            ids.extend(authority.get(field, []))
        return {rule_id: self.r7.execute_rule(rule_id, view) for rule_id in dict.fromkeys(ids)}

    def _component_assignment(self, authority):
        assignment = {}
        reasons = {}
        for field in self.component_by_field:
            spec = self.component_by_field[field]
            for rule_id in authority.get(field, []):
                if rule_id not in assignment:
                    assignment[rule_id] = spec["component"]
                    reasons[rule_id] = spec.get("reason")
        return assignment, reasons

    @staticmethod
    def _canonical_transition_groups(authority):
        ordered_fields = (
            ("CANDIDATE", "candidate_rule_ids"),
            ("PENDING", "pending_rule_ids"),
            ("ARMED", "armed_rule_ids"),
            ("TRIGGER", "trigger_rule_ids"),
            ("CONFIRMATION", "confirmation_rule_ids"),
            ("ACTIVE", "active_rule_ids"),
        )
        seen = set()
        groups = []
        for ordinal, (name, field) in enumerate(ordered_fields):
            delta = []
            for rule_id in authority.get(field, []):
                if rule_id not in seen:
                    seen.add(rule_id)
                    delta.append(rule_id)
            if delta:
                groups.append({"transition_group": name, "authority_field": field, "ordinal": ordinal, "rule_ids": delta})
        return groups

    def _lifecycle_completion(self, authority, outcomes, state):
        groups = self._canonical_transition_groups(authority)
        path_ids = [rule_id for group in groups for rule_id in group["rule_ids"]]
        if not path_ids:
            return {
                **ratio(0, 0), "canonical_transition_groups": [],
                "completed_rule_ids": [], "remaining_rule_ids": [],
            }
        completed = [rule_id for rule_id in path_ids if outcomes.get(rule_id) == "TRUE"]
        if state == "ACTIVE":
            completed = list(path_ids)
        result = ratio(len(completed), len(path_ids))
        result.update({
            "canonical_transition_groups": groups,
            "completed_rule_ids": completed,
            "remaining_rule_ids": [rule_id for rule_id in path_ids if rule_id not in completed],
        })
        return result

    def _next_required_event(self, authority, state, outcomes):
        if state == "ACTIVE":
            return "NONE"
        groups = self._canonical_transition_groups(authority)
        current_ordinal = {
            "NO_SETUP": -1, "CANDIDATE": 0, "PENDING": 1, "ARMED": 2,
        }.get(state)
        if current_ordinal is None:
            return {"status": CD, "reason": "The current lifecycle substate does not define a canonical next transition."}
        next_group = next((group for group in groups if group["ordinal"] > current_ordinal), None)
        if not next_group:
            return {"status": CD, "reason": "No non-invented next transition group can be established."}
        result = {
            "status": "REQUIRED",
            "from_lifecycle_substate": state,
            "transition_group": next_group["transition_group"],
            "rule_ids": next_group["rule_ids"],
        }
        if (
            authority.get("analysis_branch_mode") == "AUTO_EVALUATE_ALL"
            and next_group["transition_group"] == "PENDING"
            and authority.get("analysis_branches")
        ):
            result.update({
                "status": "ALTERNATIVE_TRANSITIONS",
                "alternatives": [
                    {
                        "branch_id": branch["branch_id"],
                        "rule_ids": list(next_group["rule_ids"]),
                        "known_at": branch.get("known_at"),
                    }
                    for branch in authority["analysis_branches"]
                ],
            })
        return result

    def _scores(self, authority, outcomes, state):
        assignment, reasons = self._component_assignment(authority)
        components = {}
        for component in sorted(set(assignment.values()) - {"UNSCORED_WITH_REASON"}):
            applicable = [x for x, category in assignment.items() if category == component]
            components[component] = ratio(sum(outcomes.get(x) == "TRUE" for x in applicable), len(applicable))
        unscored = [
            {"rule_id": rule_id, "reason": reasons[rule_id]}
            for rule_id, component in assignment.items() if component == "UNSCORED_WITH_REASON"
        ]
        intrinsic_ids = [x for x, component in assignment.items() if component in INTRINSIC_COMPONENTS]
        intrinsic = ratio(sum(outcomes.get(x) == "TRUE" for x in intrinsic_ids), len(intrinsic_ids))
        lifecycle = self._lifecycle_completion(authority, outcomes, state)
        return components, intrinsic, lifecycle, unscored

    @staticmethod
    def _normalized_state(state, direction):
        if state == "ACTIVE":
            return "ACTIVE_" + direction
        if state in {"CANDIDATE", "PENDING", "ARMED"}:
            return "PENDING_" + direction
        if state in {"INVALIDATED", "EXPIRED"}:
            return "TERMINAL_HISTORY"
        if state in {CD, INVALID}:
            return "CANNOT_DETERMINE"
        return state

    @staticmethod
    def _required_reached_ids(authority, state):
        field = {
            "CANDIDATE": "candidate_rule_ids",
            "PENDING": "pending_rule_ids",
            "ARMED": "armed_rule_ids",
            "ACTIVE": "active_rule_ids",
        }.get(state)
        return authority.get(field, []) if field else []

    def evaluate_cell(self, role, timeframe, setup_id, direction, payload, history_availability="UNKNOWN"):
        payload = deepcopy(payload) if isinstance(payload, dict) else {}
        details = self.r7.evaluate_branch_details(setup_id, payload, direction)
        outcomes = self._rule_outcomes(setup_id, payload, direction)
        authority = self.r7.authorities[setup_id]
        state = details["state"]
        history = self.history_status(
            setup_id, direction, payload, state=state, outcomes=outcomes,
            authority=authority, history_availability=history_availability,
        )
        components, intrinsic, lifecycle, unscored = self._scores(authority, outcomes, state)
        reached_ids = self._required_reached_ids(authority, state)
        reached_satisfied = bool(reached_ids) and all(outcomes.get(x) == "TRUE" for x in reached_ids)
        data_status = "INVALID" if state == INVALID else "CANNOT_DETERMINE" if state == CD else "VALID"
        known_at = payload.get("normalized_inputs", {}).get("evaluation_time") if isinstance(payload, dict) else None
        known_at_status = "VALID" if type(known_at) in {int, float} and not isinstance(known_at, bool) else "CANNOT_DETERMINE"
        structurally_qualified = (
            state in CURRENT_STATES
            and reached_satisfied
            and data_status == "VALID"
            and known_at_status == "VALID"
            and history["status"] == HISTORY_SUFFICIENT
            and not any(outcomes.get(x) == "TRUE" for x in authority.get("invalidation_rule_ids", []))
        )
        evidence_available = (
            data_status == "VALID"
            and known_at_status == "VALID"
            and history["status"] == HISTORY_SUFFICIENT
            and not any(outcomes.get(x) == "TRUE" for x in authority.get("invalidation_rule_ids", []))
        )
        ambiguity = sum(x in {CD, INVALID, None} for x in outcomes.values())
        if history["status"] != HISTORY_SUFFICIENT:
            ambiguity += 1
        if known_at_status != "VALID":
            ambiguity += 1
        normalized = self._normalized_state(state, direction)
        if state in CURRENT_STATES and not structurally_qualified:
            normalized = "CANNOT_DETERMINE"
        return {
            "frame_role": role,
            "timeframe": timeframe,
            "setup_id": setup_id,
            "setup_name": self.setup_names[setup_id],
            "direction": direction,
            "current_classification": normalized,
            "lifecycle_substate": state,
            "raw_r7_lifecycle_substate": state,
            "r7_invoked": True,
            "r7_runtime_authority_id": authority["authority_id"],
            "hard_gate": {
                "structurally_qualified": structurally_qualified,
                "evidence_available_for_synthesis": evidence_available,
                "data_status": data_status,
                "history_status": history,
                "known_at_status": known_at_status,
                "reached_substate_predicates_satisfied": reached_satisfied,
                "invalidation_active": any(outcomes.get(x) == "TRUE" for x in authority.get("invalidation_rule_ids", [])),
            },
            "history_evidence_status": history["history_evidence_status"],
            "history_request_required": history["history_request_required"],
            "history_request_reason": history["history_request_reason"],
            "requested_additional_history": history["requested_additional_history"],
            "history_availability": history["history_availability"],
            "satisfied_conditions": [x for x, value in outcomes.items() if value == "TRUE"],
            "violated_conditions": [x for x, value in outcomes.items() if value == "FALSE"],
            "missing_conditions": [x for x, value in outcomes.items() if value in {CD, INVALID, None}],
            "trigger_rule_ids": authority.get("trigger_rule_ids", []),
            "confirmation_rule_ids": authority.get("confirmation_rule_ids", []),
            "invalidation_rule_ids": authority.get("invalidation_rule_ids", []),
            "expiry_rule_ids": authority.get("expiry_rule_ids", []),
            "first_candidate_known_at": details.get("first_candidate_known_at"),
            "expiry_time": details.get("expiry_time"),
            "next_required_event": self._next_required_event(authority, state, outcomes),
            "intrinsic_fss": intrinsic,
            "intrinsic_fss_qualification": "QUALIFIED" if structurally_qualified else "NOT_QUALIFIED",
            "component_ratios": components,
            "lifecycle_completion": lifecycle,
            "unscored_predicates": unscored,
            "cross_timeframe_evidence": None,
            "data_quality_class": data_status,
            "unresolved_ambiguity_count": ambiguity,
            "limitations": [] if structurally_qualified else ["One or more hard qualification gates did not pass; this cell is silent in cross-timeframe synthesis."],
        }

    def scan_frame(self, role, frame):
        timeframe = frame.get("timeframe")
        setup_payloads = frame.get("setup_payloads", {})
        default_history = frame.get("history_availability", "UNKNOWN")
        setup_history = frame.get("setup_history_availability", {})
        records = []
        for setup_id in self.setup_ids:
            payload = setup_payloads.get(setup_id, {}) if isinstance(setup_payloads, dict) else {}
            for direction in DIRECTIONS:
                availability = default_history
                if isinstance(setup_history, dict):
                    availability = setup_history.get(f"{setup_id}:{direction}", setup_history.get(setup_id, availability))
                records.append(self.evaluate_cell(role, timeframe, setup_id, direction, payload, availability))
        return records

    @staticmethod
    def _is_current(record):
        return record["current_classification"].startswith(("ACTIVE_", "PENDING_"))

    @classmethod
    def _synthesis_eligible(cls, record):
        return cls._is_current(record) and record.get("hard_gate", {}).get("structurally_qualified") is True

    @staticmethod
    def _frame_evidence_available(record):
        gate = record.get("hard_gate", {})
        if "evidence_available_for_synthesis" in gate:
            return gate["evidence_available_for_synthesis"] is True
        return (
            record.get("data_quality_class") == "VALID"
            and record.get("current_classification") not in {"CANNOT_DETERMINE"}
        )

    def _cross_timeframe(self, tables):
        def component_compatibility(anchor, candidates, component):
            anchor_ratio = (anchor.get("component_ratios") or {}).get(component)
            candidate_ratios = [(x.get("component_ratios") or {}).get(component) for x in candidates]
            if not candidate_ratios or fraction_of(anchor_ratio) < 0 or any(fraction_of(x) < 0 for x in candidate_ratios):
                return CD
            return "COMPATIBLE_PRESENT" if fraction_of(anchor_ratio) > 0 and any(fraction_of(x) > 0 for x in candidate_ratios) else "NO_SHARED_POSITIVE_EVIDENCE"

        evidence = {}
        for role, records in tables.items():
            for record in records:
                if not self._synthesis_eligible(record):
                    continue
                comparisons = []
                support_count = same_setup_count = conflict_count = available_count = 0
                for other_role in ROLES:
                    if other_role == role:
                        continue
                    other = tables.get(other_role)
                    if other is None:
                        comparisons.append({"frame_role": other_role, "summary_class": "UNAVAILABLE", "flags": ["UNAVAILABLE"]})
                        continue
                    current = [x for x in other if self._synthesis_eligible(x)]
                    unavailable = not any(self._frame_evidence_available(x) for x in other)
                    if unavailable:
                        comparisons.append({"frame_role": other_role, "summary_class": "UNAVAILABLE", "flags": ["UNAVAILABLE"]})
                        continue
                    available_count += 1
                    same_direction = [x for x in current if x["direction"] == record["direction"]]
                    same_setup = [x for x in same_direction if x["setup_id"] == record["setup_id"]]
                    opposite = [x for x in current if x["direction"] != record["direction"]]
                    flags = []
                    if same_setup:
                        flags.append("SUPPORTING")
                        support_count += 1
                        same_setup_count += 1
                        if any(x["current_classification"] == record["current_classification"] for x in same_setup):
                            flags.append("REINFORCING")
                    elif same_direction:
                        flags.append("COMPLEMENTARY")
                        support_count += 1
                    if opposite:
                        flags.append("CONFLICTING")
                        conflict_count += 1
                    if not flags:
                        flags.append("NEUTRAL")
                    summary = "CONFLICTING" if "CONFLICTING" in flags else flags[0]
                    comparisons.append({
                        "frame_role": other_role, "summary_class": summary, "flags": flags,
                        "compatibility": {
                            "context": component_compatibility(record, same_direction, "CONTEXT_FIT"),
                            "location": component_compatibility(record, same_direction, "LOCATION_GEOMETRY_FIT"),
                            "state": "COMPATIBLE" if any(x["current_classification"] == record["current_classification"] for x in same_direction) else ("DIFFERENT" if same_direction else CD),
                            "data_known_at": "AVAILABLE",
                        },
                    })
                evidence[(role, record["setup_id"], record["direction"])] = {
                    "comparisons": comparisons,
                    "same_direction_support_ratio": ratio(support_count, available_count),
                    "same_setup_support_ratio": ratio(same_setup_count, available_count),
                    "conflict_ratio": ratio(conflict_count, available_count),
                }
        return evidence

    @staticmethod
    def _rank_tuple(record):
        cross = record.get("cross_timeframe_evidence") or {}
        return (
            1 if record["hard_gate"]["structurally_qualified"] else 0,
            fraction_of(record["intrinsic_fss"]),
            fraction_of(record["lifecycle_completion"]),
            fraction_of(cross.get("same_direction_support_ratio")),
            fraction_of(cross.get("same_setup_support_ratio")),
            -fraction_of(cross.get("conflict_ratio"), Fraction(2, 1)),
            QUALITY_RANK.get(record.get("data_quality_class"), 0),
            -record.get("unresolved_ambiguity_count", 0),
        )

    def rank_pool(self, records, pool):
        prefix = "ACTIVE_" if pool == "ACTIVE_POOL" else "PENDING_"
        pool_records = [x for x in records if x["current_classification"].startswith(prefix)]
        excluded = [x for x in pool_records if not x["hard_gate"]["structurally_qualified"]]
        ranked = sorted(
            [x for x in pool_records if x["hard_gate"]["structurally_qualified"]],
            key=self._rank_tuple, reverse=True,
        )
        if not ranked:
            return {"pool": pool, "ranked": [], "excluded_by_hard_gate": excluded, "strongest": "NONE", "tie_state": None}
        top_tuple = self._rank_tuple(ranked[0])
        leaders = [x for x in ranked if self._rank_tuple(x) == top_tuple]
        return {
            "pool": pool,
            "ranked": ranked,
            "excluded_by_hard_gate": excluded,
            "strongest": leaders,
            "tie_state": "CO_LEADING_VALID_READS" if len(leaders) > 1 else "UNIQUE_LEADER",
        }

    @staticmethod
    def _validate_frame_identity(frames):
        identities = {x.get("instrument_id") for x in frames.values() if isinstance(x, dict)}
        return len(identities) == 1 and None not in identities

    @staticmethod
    def _validate_explicit_frame_metadata(frames, evaluation_cut):
        required = {
            "instrument_id", "timeframe", "timezone", "calendar_id", "calendar_version",
            "session_id", "evaluation_cut", "setup_payloads",
        }
        if any(not isinstance(frame, dict) or not required <= set(frame) for frame in frames.values()):
            return False
        compatibility_fields = (
            "instrument_id", "timezone", "calendar_id", "calendar_version", "session_id", "evaluation_cut",
        )
        if any(len({frames[role][field] for role in ROLES}) != 1 for field in compatibility_fields):
            return False
        return all(frames[role]["evaluation_cut"] == evaluation_cut for role in ROLES)

    def _prepare_structured_frames(self, document, role_result):
        base = deepcopy(document.get("base_frame", {}))
        base.setdefault("history_availability", document.get("history_availability", "UNKNOWN"))
        frames = {"LTF": base}
        base.setdefault("timeframe", role_result["roles"].get("LTF"))
        templates = document.get("setup_payload_templates", {})
        for request in document.get("resampling_requests", []):
            role = request.get("role")
            if role not in {"MTF", "HTF"}:
                continue
            result = self.resample_bars(base.get("bars", []), request.get("parent_buckets", []), request.get("metadata", {}))
            setup_payloads = {}
            if result["status"] == "DETERMINED":
                for setup_id, template in templates.items():
                    payload = deepcopy(template)
                    payload.setdefault("raw_dt_p1", {})["bars"] = deepcopy(result["bars"])
                    payload.setdefault("normalized_inputs", {})["timeframe"] = request["metadata"]["target_timeframe"]
                    setup_payloads[setup_id] = payload
            frames[role] = {
                "instrument_id": base.get("instrument_id"),
                "timeframe": role_result["roles"].get(role),
                "setup_payloads": setup_payloads,
                "resampling_status": result["status"],
                "history_availability": request.get("history_availability", document.get("history_availability", "UNKNOWN")),
            }
        return frames

    @staticmethod
    def _contains_forbidden_verdict(value, inside_hypothesis=False):
        if isinstance(value, dict):
            for key, item in value.items():
                if key == "user_hypothesis":
                    if ExpertBrainRuntime._contains_forbidden_verdict(item, inside_hypothesis=True):
                        return True
                    continue
                forbidden = {"final_verdict", "verdict", "audit_result", "hypothesis_verdict"} if inside_hypothesis else CALLER_VERDICT_FIELDS
                if key in forbidden:
                    return True
                if ExpertBrainRuntime._contains_forbidden_verdict(item, inside_hypothesis=inside_hypothesis):
                    return True
        elif isinstance(value, list):
            return any(ExpertBrainRuntime._contains_forbidden_verdict(item, inside_hypothesis=inside_hypothesis) for item in value)
        return False

    def _audit_user_hypothesis(self, hypothesis, records):
        if hypothesis is None:
            return {"status": "NOT_REQUESTED"}
        base = {
            "proposed_interpretation": deepcopy(hypothesis),
            "applicable_ruleset": [],
            "required_conditions": [],
            "satisfied_conditions": [],
            "missing_conditions": [],
            "violated_conditions": [],
            "data_gaps": [],
            "final_verdict": CD,
        }
        if not isinstance(hypothesis, dict):
            base["data_gaps"].append("A structured frame_role, setup_id and direction are required for deterministic audit.")
            return base
        role = hypothesis.get("frame_role")
        setup_id = hypothesis.get("setup_id")
        direction = hypothesis.get("direction")
        claimed_classification = hypothesis.get("claimed_classification")
        claimed_substate = hypothesis.get("claimed_lifecycle_substate")
        if direction is None and isinstance(claimed_classification, str):
            direction = next((item for item in DIRECTIONS if claimed_classification.endswith("_" + item)), None)
        if role not in ROLES or setup_id not in self.r7.authorities or direction not in DIRECTIONS:
            base["data_gaps"].append("The hypothesis target does not resolve to one configured frame/setup/direction cell.")
            return base
        target = next((row for row in records if row["frame_role"] == role and row["setup_id"] == setup_id and row["direction"] == direction), None)
        if target is None:
            base["data_gaps"].append("The target cell is not present in the frozen 108-cell result.")
            return base
        authority = self.r7.authorities[setup_id]
        claimed_state = claimed_substate
        if claimed_state is None and isinstance(claimed_classification, str):
            claimed_state = "ACTIVE" if claimed_classification.startswith("ACTIVE_") else "PENDING" if claimed_classification.startswith("PENDING_") else "NO_SETUP" if claimed_classification == "NO_SETUP" else None
        field = {
            "CANDIDATE": "candidate_rule_ids", "PENDING": "pending_rule_ids",
            "ARMED": "armed_rule_ids", "ACTIVE": "active_rule_ids",
        }.get(claimed_state)
        required = list(authority.get(field, [])) if field else []
        base["applicable_ruleset"] = [{"runtime_authority_id": authority["authority_id"], "authority_field": field}]
        base["required_conditions"] = required
        base["satisfied_conditions"] = [rule_id for rule_id in required if rule_id in target["satisfied_conditions"]]
        base["violated_conditions"] = [rule_id for rule_id in required if rule_id in target["violated_conditions"]]
        base["missing_conditions"] = [rule_id for rule_id in required if rule_id in target["missing_conditions"]]
        history = target["hard_gate"]["history_status"]
        if history["status"] != HISTORY_SUFFICIENT:
            base["data_gaps"].append({"history_evidence_status": history["status"], "requested_additional_history": history.get("requested_additional_history")})
        if target["current_classification"] == "CANNOT_DETERMINE" or base["data_gaps"]:
            base["final_verdict"] = CD
            return base
        classification_match = claimed_classification is None or claimed_classification == target["current_classification"]
        substate_match = claimed_substate is None or claimed_substate == target["raw_r7_lifecycle_substate"]
        if classification_match and substate_match:
            base["final_verdict"] = "MATCH"
        elif required and base["satisfied_conditions"] and len(base["satisfied_conditions"]) < len(required):
            base["final_verdict"] = "PARTIAL_MATCH"
        else:
            base["final_verdict"] = "NOT_MATCH"
        return base

    def analyze(self, document):
        if not isinstance(document, dict) or self._contains_forbidden_verdict(document):
            return {"result_state": "INVALID_CALLER_INPUT", "reason": "Caller-supplied audit verdict or semantic result is prohibited."}
        mode = document.get("mode")
        if mode not in self.authority["supported_modes"]:
            return {"result_state": "INVALID_INPUT_MODE"}
        if mode in {"THREE_FRAME_IMAGE_PACKAGE", "SINGLE_FRAME_IMAGE"}:
            images = document.get("images", {})
            required = set(ROLES) if mode == "THREE_FRAME_IMAGE_PACKAGE" else {document.get("requested_role", "LTF")}
            metadata_ok = required <= set(images) and all(
                isinstance(images[x], dict)
                and {"instrument_id", "timeframe", "observation_cut", "visible_metadata_sufficient"} <= set(images[x])
                and images[x]["visible_metadata_sufficient"] is True
                for x in required
            )
            if metadata_ok:
                metadata_ok = (
                    len({images[x]["instrument_id"] for x in required}) == 1
                    and len({images[x]["observation_cut"] for x in required}) == 1
                    and all(images[x]["timeframe"] in TIMEFRAME_RANK for x in required)
                )
            if metadata_ok and mode == "THREE_FRAME_IMAGE_PACKAGE":
                metadata_ok = TIMEFRAME_RANK[images["LTF"]["timeframe"]] < TIMEFRAME_RANK[images["MTF"]["timeframe"]] < TIMEFRAME_RANK[images["HTF"]["timeframe"]]
            availability = document.get("history_availability", "UNKNOWN")
            request_required = availability != "NO_MORE_AVAILABLE"
            history_status = NO_MORE_HISTORY_CD if not request_required else MORE_HISTORY_REQUIRED
            return {
                "style": "KX Professional / Classical Price Action",
                "data_mode": mode,
                "timeframe_context": "VALIDATED_IMAGE_METADATA" if metadata_ok else "TIMEFRAME_CONTEXT_INCOMPLETE",
                "result_state": "IMAGE_EVIDENCE_REQUIRES_STRUCTURED_FOUNDATION_EXTRACTION" if metadata_ok else CD,
                "history_evidence_status": history_status,
                "history_request_required": request_required,
                "history_request_reason": "The visible chart does not prove the complete left-history dependency closure for the affected timeframe.",
                "requested_additional_history": None if not request_required else {
                    "kind": "WIDER_LONGER_CHART", "exact_count": None,
                    "request": "Provide a wider or longer chart with more left-side historical context on the affected timeframe.",
                },
                "history_availability": availability,
                "user_hypothesis_audit": self._audit_user_hypothesis(document.get("user_hypothesis"), []),
                "limitations": ["The conformance runtime does not fabricate DT-P1 or SK02 objects from pixels."],
            }
        if mode == "EXPLICIT_THREE_FRAME_OHLC":
            frames = deepcopy(document.get("frames", {}))
            for frame in frames.values():
                if isinstance(frame, dict):
                    frame.setdefault("history_availability", document.get("history_availability", "UNKNOWN"))
            role_result = self.resolve_roles(document.get("input_timeframe"), document.get("explicit_roles"))
            if set(frames) != set(ROLES) or not self._validate_explicit_frame_metadata(frames, document.get("evaluation_cut")):
                return {"result_state": "TIMEFRAME_CONTEXT_INCOMPLETE", "timeframe_context": role_result}
            if not role_result["roles"] or any(frames[role]["timeframe"] != role_result["roles"].get(role) for role in ROLES):
                return {"result_state": "CANNOT_DETERMINE_TIMEFRAME_ROUTING", "timeframe_context": role_result}
        else:
            role_result = self.resolve_roles(document.get("input_timeframe"), document.get("explicit_roles"))
            if not role_result["roles"]:
                return {"result_state": role_result["status"]}
            frames = self._prepare_structured_frames(document, role_result)
        if set(frames) != set(ROLES) or not self._validate_frame_identity(frames):
            return {"result_state": "TIMEFRAME_CONTEXT_INCOMPLETE", "timeframe_context": role_result}
        tables = {role: self.scan_frame(role, frames[role]) for role in ROLES}
        cross = self._cross_timeframe(tables)
        all_records = []
        for role in ROLES:
            for record in tables[role]:
                record["cross_timeframe_evidence"] = cross.get(
                    (role, record["setup_id"], record["direction"]),
                    {"status": "UNAVAILABLE", "comparisons": [], "reason": "Cell is not eligible to vote in cross-timeframe synthesis."},
                )
                all_records.append(record)
        active = self.rank_pool(all_records, "ACTIVE_POOL")
        pending = self.rank_pool(all_records, "PENDING_POOL")
        both_empty = active["strongest"] == "NONE" and pending["strongest"] == "NONE"
        return {
            "style": "KX Professional / Classical Price Action",
            "data_mode": mode,
            "evaluation_cut": document.get("evaluation_cut"),
            "timeframe_context": role_result,
            "timeframe_sufficiency": "COMPLETE",
            "frame_tables_frozen_before_synthesis": True,
            "ltf_complete_setup_table": tables["LTF"],
            "mtf_complete_setup_table": tables["MTF"],
            "htf_complete_setup_table": tables["HTF"],
            "active_pool_ranking": active,
            "pending_pool_ranking": pending,
            "strongest_current_active_setup": active["strongest"],
            "strongest_current_pending_setup": pending["strongest"],
            "cross_timeframe_support": [x for x in cross.values() if fraction_of(x["same_direction_support_ratio"], Fraction(0, 1)) > 0],
            "cross_timeframe_conflict": [x for x in cross.values() if fraction_of(x["conflict_ratio"], Fraction(0, 1)) > 0],
            "alternative_valid_reads": [x for x in all_records if self._synthesis_eligible(x)],
            "missing_data": [x for x in all_records if x["hard_gate"]["history_status"]["status"] != HISTORY_SUFFICIENT],
            "cannot_determine_items": [x for x in all_records if x["current_classification"] == "CANNOT_DETERMINE"],
            "user_hypothesis_audit": self._audit_user_hypothesis(document.get("user_hypothesis"), all_records),
            "final_expert_comparative_assessment": "NO_STRUCTURALLY_QUALIFIED_SETUP" if both_empty else "COMPARATIVE_READS_AVAILABLE",
            "orchestration_record_count": len(all_records),
            "profitability_claim": False,
            "trade_action_advice": False,
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", nargs="?")
    args = parser.parse_args()
    runtime = ExpertBrainRuntime()
    if not args.input_json:
        print(json.dumps({"runtime": "READY", "setups": len(runtime.setup_ids), "expected_three_frame_cells": 108}, sort_keys=True))
        return 0
    document = json.loads(Path(args.input_json).read_text(encoding="utf-8"))
    print(json.dumps(runtime.analyze(document), sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
