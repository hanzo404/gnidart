#!/usr/bin/env python3
"""Execute the MF01-C01 R7 class-wide Runtime Time/Expiry proof matrix."""
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from reference_semantic_runtime import SemanticRuntime  # noqa: E402
from validate_semantic_fixtures import evaluate_r7_time_expiry_proof  # noqa: E402


def main():
    fixture_doc = yaml.safe_load((ROOT / "assets/semantic-fixtures.yaml").read_text(encoding="utf-8"))
    fixtures = fixture_doc["fixtures"]
    fixture_by_id = {row["fixture_id"]: row for row in fixtures}
    proofs = [row for row in fixtures if row.get("fixture_type") == "R7_RUNTIME_TIME_EXPIRY_PROOF"]
    runtime = SemanticRuntime()
    errors = []
    seen = set()
    for row in proofs:
        key = (row.get("setup_id"), row.get("direction"))
        seen.add(key)
        actual = evaluate_r7_time_expiry_proof(runtime, row, fixture_by_id)
        if actual != "TRUE":
            errors.append(f"{row.get('fixture_id')}: computed {actual!r}")
    expected = {(setup_id, direction) for setup_id in runtime.authorities for direction in ("BUY", "SELL")}
    if seen != expected:
        errors.append(f"directional proof matrix mismatch: missing={sorted(expected-seen)} extra={sorted(seen-expected)}")
    if len(proofs) != 36:
        errors.append(f"expected 36 directional proof records, got {len(proofs)}")
    if errors:
        print("R7 RUNTIME TIME/EXPIRY: FAIL")
        for error in errors:
            print("FAIL:", error)
        return 2
    print("R7 RUNTIME TIME/EXPIRY: PASS (18 setups x BUY/SELL; timestamp separation; no-candidate; delayed candidate; N=1/N=3; no-pre-candidate expiry; future-known-at; prehistory; revision)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
