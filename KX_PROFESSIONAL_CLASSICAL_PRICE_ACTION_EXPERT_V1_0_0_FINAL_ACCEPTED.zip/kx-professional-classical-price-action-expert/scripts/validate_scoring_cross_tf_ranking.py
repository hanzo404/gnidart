#!/usr/bin/env python3
"""Targeted exact-score, cross-timeframe, hard-gate, and ranking proof."""
from copy import deepcopy
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from reference_expert_brain_runtime import (  # noqa: E402
    ExpertBrainRuntime, HISTORY_INSUFFICIENT_EXACT, HISTORY_SUFFICIENT,
    MORE_HISTORY_REQUIRED, NO_MORE_HISTORY_CD, fraction_of, ratio,
)


def record(setup, direction, state="ACTIVE_BUY", fss=(1, 2), life=(1, 2), qualified=True, ambiguity=0):
    return {
        "frame_role": "LTF", "timeframe": "5m", "setup_id": setup, "direction": direction,
        "current_classification": state,
        "hard_gate": {
            "structurally_qualified": qualified,
            "evidence_available_for_synthesis": qualified,
        },
        "intrinsic_fss": ratio(*fss), "lifecycle_completion": ratio(*life),
        "cross_timeframe_evidence": {
            "same_direction_support_ratio": ratio(0, 2), "same_setup_support_ratio": ratio(0, 2),
            "conflict_ratio": ratio(0, 2),
        },
        "data_quality_class": "VALID", "unresolved_ambiguity_count": ambiguity,
    }


def history_payload(count):
    return {
        "normalized_inputs": {
            "profile_id": "PROFILE-PA-INSIDE-BREAK-001", "evaluation_time": 30, "session_id": "S1",
        },
        "raw_dt_p1": {"bars": [
            {"bar_finality": "CONFIRMED", "session_id": "S1", "known_at": 10 + index}
            for index in range(count)
        ]},
    }


def main():
    runtime = ExpertBrainRuntime()
    errors = []

    if fraction_of(ratio(2, 3)) != fraction_of(ratio(4, 6)):
        errors.append("exact rational equality failed")
    if ratio(0, 0).get("status") != "CANNOT_DETERMINE" or ratio(0, 0).get("display_percent") is not None:
        errors.append("zero denominator did not return CANNOT_DETERMINE")
    sufficient = runtime.history_status("SET-PA-INSIDE-BREAK", "BUY", history_payload(2))
    insufficient = runtime.history_status("SET-PA-INSIDE-BREAK", "BUY", history_payload(1))
    no_more = runtime.history_status("SET-PA-INSIDE-BREAK", "BUY", history_payload(1), history_availability="NO_MORE_AVAILABLE")
    unresolved = runtime.history_status("SET-PA-WEDGE", "BUY", history_payload(2), state="ACTIVE", outcomes={})
    if sufficient.get("status") != HISTORY_SUFFICIENT or insufficient.get("status") != HISTORY_INSUFFICIENT_EXACT:
        errors.append("two-bar history boundary failed")
    if insufficient.get("requested_additional_history", {}).get("exact_count") != 1:
        errors.append("provable exact missing history count was not emitted")
    if no_more.get("status") != NO_MORE_HISTORY_CD or no_more.get("history_request_required") is not False:
        errors.append("NO_MORE_AVAILABLE did not fail closed only at the affected history gate")
    if unresolved.get("status") != MORE_HISTORY_REQUIRED or unresolved.get("requested_additional_history", {}).get("exact_count") is not None:
        errors.append("unknown finite minimum did not request non-invented additional history")

    fixtures = yaml.safe_load((ROOT / "assets/semantic-fixtures.yaml").read_text(encoding="utf-8"))["fixtures"]
    by_id = {x["fixture_id"]: x for x in fixtures}
    unknown_minimum_setups = {
        row["setup_id"] for row in runtime.history_doc["requirements"]
        if row.get("evaluation_mode") == "ACTUAL_DEPENDENCY_CLOSURE"
    }
    dependency_closed = set()
    for setup_id in unknown_minimum_setups:
        payload = by_id.get(f"FIX-{setup_id}-ACTIVE")
        if not payload:
            continue
        details = runtime.r7.evaluate_branch_details(setup_id, payload, "BUY")
        outcomes = runtime._rule_outcomes(setup_id, payload, "BUY")
        status = runtime.history_status(
            setup_id, "BUY", payload, state=details["state"], outcomes=outcomes,
            authority=runtime.r7.authorities[setup_id],
        )
        if status.get("status") == HISTORY_SUFFICIENT:
            dependency_closed.add(setup_id)
    if dependency_closed != unknown_minimum_setups:
        errors.append(f"unknown-minimum families remain permanently barred: {sorted(unknown_minimum_setups-dependency_closed)}")
    required_examples = {"SET-PA-TREND-PULLBACK", "SET-PA-WEDGE", "SET-PA-H2-L2", "SET-PA-GAP-BRANCH"}
    if not required_examples <= dependency_closed:
        errors.append("Trend Pullback plus three other unknown-minimum families did not become history eligible")
    pending_cell = runtime.evaluate_cell(
        "LTF", "5m", "SET-PA-TREND-PULLBACK", "BUY",
        by_id["FIX-SET-PA-TREND-PULLBACK-PENDING"],
    )
    active_cell = runtime.evaluate_cell(
        "LTF", "5m", "SET-PA-TREND-PULLBACK", "BUY",
        by_id["FIX-SET-PA-TREND-PULLBACK-ACTIVE"],
    )
    if pending_cell["lifecycle_substate"] != "PENDING" or not (0 < fraction_of(pending_cell["lifecycle_completion"]) < 1):
        errors.append("canonical pending lifecycle progress did not remain partial")
    if active_cell["lifecycle_substate"] != "ACTIVE" or fraction_of(active_cell["lifecycle_completion"]) != 1:
        errors.append("canonical active lifecycle path did not resolve complete")
    authority = runtime.r7.authorities["SET-PA-TREND-PULLBACK"]
    candidate_next = runtime._next_required_event(authority, "CANDIDATE", {})
    pending_next = runtime._next_required_event(authority, "PENDING", {})
    armed_next = runtime._next_required_event(authority, "ARMED", {})
    if candidate_next.get("transition_group") != "PENDING" or candidate_next.get("rule_ids") != ["RULE-PA-FACT-COUNTER-DIRECTION-LEG", "RULE-PA-FACT-TREND-INVALIDATION-FALSE"]:
        errors.append("CANDIDATE next event is not the immediate pending transition delta")
    if pending_next.get("transition_group") != "ARMED" or pending_next.get("rule_ids") != ["RULE-PA-FACT-RESUMPTION-TRIGGER"]:
        errors.append("PENDING next event is not the immediate armed transition delta")
    if armed_next.get("transition_group") != "CONFIRMATION" or armed_next.get("rule_ids") != ["RULE-PA-FACT-CONFIRMATION-SATISFIED"]:
        errors.append("ARMED next event is not the immediate confirmation transition")
    if runtime._next_required_event(authority, "ACTIVE", {}) != "NONE":
        errors.append("ACTIVE next event is not NONE")
    gap_next = runtime._next_required_event(runtime.r7.authorities["SET-PA-GAP-BRANCH"], "CANDIDATE", {})
    if gap_next.get("status") != "ALTERNATIVE_TRANSITIONS" or {x["branch_id"] for x in gap_next.get("alternatives", [])} != {"CONTINUATION", "FILL_HYPOTHESIS"}:
        errors.append("canonical Gap alternative transitions were not explicit")
    groups = active_cell["lifecycle_completion"].get("canonical_transition_groups", [])
    path_ids = [rule_id for group in groups for rule_id in group["rule_ids"]]
    if len(path_ids) != len(set(path_ids)) or "RULE-PA-FACT-CONFIRMATION-SATISFIED" not in path_ids:
        errors.append("canonical lifecycle path omitted confirmation or double-counted a reused Rule")
    if runtime._lifecycle_completion({}, {}, "PENDING").get("status") != "CANNOT_DETERMINE":
        errors.append("unresolvable lifecycle denominator did not return CANNOT_DETERMINE")

    precise = [
        record("A", "BUY", fss=(2, 3)),
        record("B", "BUY", fss=(667, 1001)),
    ]
    ranked = runtime.rank_pool(precise, "ACTIVE_POOL")
    if ranked["strongest"] == "NONE" or ranked["strongest"][0]["setup_id"] != "A":
        errors.append("ranking used rounded display values instead of exact ratios")
    tied = runtime.rank_pool([record("A", "BUY"), record("B", "BUY")], "ACTIVE_POOL")
    if tied.get("tie_state") != "CO_LEADING_VALID_READS" or len(tied.get("strongest", [])) != 2:
        errors.append("deterministic tie preservation failed")
    if runtime.rank_pool([], "ACTIVE_POOL").get("strongest") != "NONE":
        errors.append("empty active pool did not return NONE")
    mixed = runtime.rank_pool([
        record("A", "BUY", state="ACTIVE_BUY"),
        record("P", "BUY", state="PENDING_BUY", fss=(1, 1)),
    ], "ACTIVE_POOL")
    if any(x["setup_id"] == "P" for x in mixed["ranked"]):
        errors.append("active and pending pools were mixed")
    gated = runtime.rank_pool([record("A", "BUY", qualified=False)], "ACTIVE_POOL")
    if gated.get("strongest") != "NONE":
        errors.append("failed hard gate was allowed to become strongest")

    anchor = record("A", "BUY")
    anchor["frame_role"] = "LTF"
    support = record("A", "BUY")
    support["frame_role"] = "MTF"
    complement = record("B", "BUY")
    complement["frame_role"] = "HTF"
    tables = {"LTF": [anchor], "MTF": [support], "HTF": [complement]}
    evidence = runtime._cross_timeframe(tables)[("LTF", "A", "BUY")]
    flags = {flag for row in evidence["comparisons"] for flag in row["flags"]}
    if not {"SUPPORTING", "REINFORCING", "COMPLEMENTARY"} <= flags:
        errors.append(f"support/reinforcement/complement classification failed: {flags}")
    conflict = record("C", "SELL", state="ACTIVE_SELL")
    conflict["frame_role"] = "HTF"
    evidence2 = runtime._cross_timeframe({"LTF": [anchor], "MTF": [support], "HTF": [conflict]})[("LTF", "A", "BUY")]
    if "CONFLICTING" not in {flag for row in evidence2["comparisons"] for flag in row["flags"]}:
        errors.append("opposite-direction conflict was not declared")
    neutral_row = record("N", "BUY", state="NO_SETUP")
    neutral_row["frame_role"] = "MTF"
    cd_row = record("U", "BUY", state="CANNOT_DETERMINE", qualified=False)
    cd_row["frame_role"] = "HTF"
    evidence3 = runtime._cross_timeframe({"LTF": [anchor], "MTF": [neutral_row], "HTF": [cd_row]})[("LTF", "A", "BUY")]
    summaries = {x["frame_role"]: x["summary_class"] for x in evidence3["comparisons"]}
    if summaries != {"MTF": "NEUTRAL", "HTF": "UNAVAILABLE"}:
        errors.append(f"neutral/unavailable classification failed: {summaries}")
    if evidence3["same_direction_support_ratio"].get("denominator") != 1:
        errors.append("unavailable frame was not excluded from the cross-timeframe denominator")
    ineligible = record("A", "BUY", qualified=False)
    ineligible["frame_role"] = "HTF"
    evidence4 = runtime._cross_timeframe({"LTF": [anchor], "MTF": [support], "HTF": [ineligible]})[("LTF", "A", "BUY")]
    htf = next(x for x in evidence4["comparisons"] if x["frame_role"] == "HTF")
    if htf["summary_class"] != "UNAVAILABLE" or evidence4["same_direction_support_ratio"].get("denominator") != 1:
        errors.append("current-looking but ineligible evidence voted or entered a denominator")
    if runtime._synthesis_eligible(ineligible):
        errors.append("ineligible current-looking cell remained a valid alternative/ranking candidate")

    hypothesis_record = deepcopy(active_cell)
    hypothesis_record["frame_role"] = "LTF"
    hypothesis_record["current_classification"] = "ACTIVE_BUY"
    match = runtime._audit_user_hypothesis({
        "frame_role": "LTF", "setup_id": hypothesis_record["setup_id"], "direction": "BUY",
        "claimed_classification": "ACTIVE_BUY", "claimed_lifecycle_substate": "ACTIVE",
    }, [hypothesis_record])
    partial_record = deepcopy(pending_cell)
    partial_record["frame_role"] = "LTF"
    partial_record["current_classification"] = "PENDING_BUY"
    partial = runtime._audit_user_hypothesis({
        "frame_role": "LTF", "setup_id": partial_record["setup_id"], "direction": "BUY",
        "claimed_classification": "ACTIVE_BUY", "claimed_lifecycle_substate": "ACTIVE",
    }, [partial_record])
    not_match = runtime._audit_user_hypothesis({
        "frame_role": "LTF", "setup_id": hypothesis_record["setup_id"], "direction": "BUY",
        "claimed_classification": "NO_SETUP",
    }, [hypothesis_record])
    cd_record = deepcopy(hypothesis_record)
    cd_record["current_classification"] = "CANNOT_DETERMINE"
    cd_record["hard_gate"]["history_status"]["status"] = NO_MORE_HISTORY_CD
    cannot = runtime._audit_user_hypothesis({
        "frame_role": "LTF", "setup_id": cd_record["setup_id"], "direction": "BUY",
        "claimed_classification": "ACTIVE_BUY",
    }, [cd_record])
    if [match["final_verdict"], partial["final_verdict"], not_match["final_verdict"], cannot["final_verdict"]] != ["MATCH", "PARTIAL_MATCH", "NOT_MATCH", "CANNOT_DETERMINE"]:
        errors.append("runtime hypothesis verdict derivation failed")
    if runtime.analyze({"mode": "STRUCTURED_OHLC", "user_hypothesis_audit": {"final_verdict": "MATCH"}}).get("result_state") != "INVALID_CALLER_INPUT":
        errors.append("caller hypothesis verdict injection was not rejected")
    accepted_raw = runtime.analyze({
        "mode": "SINGLE_FRAME_IMAGE", "requested_role": "LTF",
        "images": {"LTF": {"instrument_id": "TEST", "timeframe": "5m", "observation_cut": 30, "visible_metadata_sufficient": True}},
        "user_hypothesis": {"frame_role": "LTF", "setup_id": "SET-PA-TREND-PULLBACK", "direction": "BUY", "claimed_classification": "ACTIVE_BUY"},
    })
    if accepted_raw.get("result_state") == "INVALID_CALLER_INPUT" or accepted_raw.get("user_hypothesis_audit", {}).get("final_verdict") != "CANNOT_DETERMINE":
        errors.append("raw user_hypothesis was not accepted as a non-authoritative audit target")

    prohibited = ("win_probability", "expected_profit", "expected_return", "sharpe", "pnl", "entry_action")
    for rel in ("assets/ai-output-schema.yaml", "assets/ranking-contract.yaml", "assets/setup-strength-score-contract.yaml"):
        text = (ROOT / rel).read_text(encoding="utf-8").lower()
        if any(term in text for term in prohibited):
            errors.append(f"prohibited profitability/action field in {rel}")

    if errors:
        print("SCORING/CROSS-TF/RANKING VALIDATION: FAIL")
        for error in errors:
            print("FAIL:", error)
        return 2
    print("SCORING/CROSS-TF/RANKING VALIDATION: PASS (exact ratios; history boundary; isolated gates; relations; separate pools; ties)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
