#!/usr/bin/env python3
"""Cross-language parity for integer price math and the stateful semantic core."""
from pathlib import Path
import json, shutil, subprocess, sys, tempfile

VECTORS=[
 (402,410,400,408,100,112,108,1,2,3,0,20,20,1),
 (-12,-5,-20,-18,-10,-4,-7,0,4,1,0,31,30,1),
 (10,14,8,12,2,5,7,1,4,4,1,40,40,1),
 (10,14,8,12,2,5,7,1,1,2,0,40,40,0),
]
KEYS=["range","body","upper","lower","measured","next_state","known_at_eligible","profile_status"]

def reference(x):
    o,h,l,c,a,b,z,u,p,n,i,k,t,q=x
    nxt=-2 if not q else 5 if i else p if p in (5,6) or n<p else n
    return dict(zip(KEYS,[h-l,abs(c-o),h-max(o,c),min(o,c)-l,z+(1 if u else -1)*abs(b-a),nxt,int(k<=t),int(bool(q))]))

PYTHON='''import sys
for line in sys.stdin:
 o,h,l,c,a,b,z,u,p,n,i,k,t,q=map(int,line.split());nxt=-2 if not q else 5 if i else p if p in (5,6) or n<p else n;print(h-l,abs(c-o),h-max(o,c),min(o,c)-l,z+(1 if u else -1)*abs(b-a),nxt,int(k<=t),int(bool(q)))'''
CPP=r'''#include <algorithm>
#include <cstdlib>
#include <iostream>
int main(){long long o,h,l,c,a,b,z,u,p,n,i,k,t,q;while(std::cin>>o>>h>>l>>c>>a>>b>>z>>u>>p>>n>>i>>k>>t>>q){long long nxt=!q?-2:i?5:((p==5||p==6||n<p)?p:n);std::cout<<h-l<<" "<<std::llabs(c-o)<<" "<<h-std::max(o,c)<<" "<<std::min(o,c)-l<<" "<<z+(u?1:-1)*std::llabs(b-a)<<" "<<nxt<<" "<<(k<=t)<<" "<<(q?1:0)<<"\n";}}'''
RUST=r'''use std::io::{self,Read};fn main(){let mut s=String::new();io::stdin().read_to_string(&mut s).unwrap();let v:Vec<i64>=s.split_whitespace().map(|x|x.parse().unwrap()).collect();for x in v.chunks(14){let(o,h,l,c,a,b,z,u,p,n,i,k,t,q)=(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],x[8],x[9],x[10],x[11],x[12],x[13]);let nx=if q==0{-2}else if i==1{5}else if p==5||p==6||n<p{p}else{n};println!("{} {} {} {} {} {} {} {}",h-l,(c-o).abs(),h-o.max(c),o.min(c)-l,z+(if u==1{1}else{-1})*(b-a).abs(),nx,(k<=t)as i64,(q!=0)as i64);}}'''
GO=r'''package main
import("bufio";"fmt";"os")
func abs(x int64)int64{if x<0{return -x};return x};func max(a,b int64)int64{if a>b{return a};return b};func min(a,b int64)int64{if a<b{return a};return b}
func main(){in:=bufio.NewReader(os.Stdin);for{var o,h,l,c,a,b,z,u,p,n,i,k,t,q int64;if _,e:=fmt.Fscan(in,&o,&h,&l,&c,&a,&b,&z,&u,&p,&n,&i,&k,&t,&q);e!=nil{return};nx:=n;if q==0{nx=-2}else if i==1{nx=5}else if p==5||p==6||n<p{nx=p};eligible:=int64(0);if k<=t{eligible=1};valid:=int64(0);if q!=0{valid=1};sgn:=int64(-1);if u==1{sgn=1};fmt.Println(h-l,abs(c-o),h-max(o,c),min(o,c)-l,z+sgn*abs(b-a),nx,eligible,valid)}}'''

def parse(s): return [dict(zip(KEYS,map(int,line.split()))) for line in s.strip().splitlines()]
def run(cmd,stdin):
    p=subprocess.run(cmd,input=stdin,text=True,capture_output=True,timeout=30)
    if p.returncode: raise RuntimeError(p.stderr)
    return parse(p.stdout)

def main():
    stdin="".join(" ".join(map(str,x))+"\n" for x in VECTORS); expected=[reference(x) for x in VECTORS]
    results={};checks=[];errors=[]
    with tempfile.TemporaryDirectory(prefix="kx_pa_parity_") as td:
        d=Path(td); py=d/"parity.py";py.write_text(PYTHON);results["Python"]=run([sys.executable,str(py)],stdin);checks.append("Python:EXECUTED")
        for lang,tool,suffix,source,compile_cmd in [
          ("C++","g++","cpp",CPP,lambda s,e:["g++","-std=c++17","-O2",str(s),"-o",str(e)]),
          ("Rust","rustc","rs",RUST,lambda s,e:["rustc","-O",str(s),"-o",str(e)]),
          ("Go","go","go",GO,lambda s,e:["go","build","-o",str(e),str(s)])]:
            if shutil.which(tool):
                src=d/("parity."+suffix);exe=d/("parity_"+lang.replace("+","p"));src.write_text(source)
                subprocess.run(compile_cmd(src,exe),check=True,capture_output=True);results[lang]=run([str(exe)],stdin);checks.append(lang+":COMPILED_EXECUTED")
            else: checks.append(lang+":SOURCE_CONTRACT_ONLY_TOOLCHAIN_UNAVAILABLE")
    for lang,actual in results.items():
        if actual!=expected:errors.append(f"{lang} actual {actual} != reference {expected}")
    for lang,source in (("Python",PYTHON),("C++",CPP),("Rust",RUST),("Go",GO)):
        if "expected" in source.lower():errors.append(lang+" source contains expected-output reference")
        for token in ("abs","max","min","nxt" if lang in {"Python","C++"} else "nx"):
            if token not in source:errors.append(f"{lang} source lacks calculation token {token}")
    contract={"languages":["Python","Rust","C++","Go"],"numeric_model":"signed 64-bit integer ticks","semantic_scope":["price math","known-at eligibility","strict profile status","monotone lifecycle advance","post-ACTIVE invalidation"],"state_codes":{"0":"NO_SETUP","1":"CANDIDATE","2":"PENDING","3":"ARMED","4":"ACTIVE","5":"INVALIDATED","6":"EXPIRED","-2":"INVALID_PROFILE"},"vectors":len(VECTORS),"checks":checks,"executed_results":results}
    print(json.dumps(contract,indent=2))
    if errors:
        print("PARITY CONTRACT: FAIL");[print("FAIL:",x) for x in errors];return 2
    print("PARITY CONTRACT: PASS (available toolchains executed semantic calculations; unavailable toolchains retain complete sources)");return 0

if __name__=="__main__":sys.exit(main())
