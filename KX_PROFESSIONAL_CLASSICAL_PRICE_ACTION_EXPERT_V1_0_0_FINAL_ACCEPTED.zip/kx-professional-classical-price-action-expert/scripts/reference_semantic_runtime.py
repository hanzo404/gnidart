#!/usr/bin/env python3
"""Registry-driven MF01-C01 semantic conformance runtime.

This interpreter is for QA and semantic parity. It does not place orders and it
does not read test assertions. Setup composition is loaded only from the runtime
authority registry.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import argparse
import json
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
CD = "CANNOT_DETERMINE"
INVALID = "CANNOT_DETERMINE_WITH_INVALID_DATA"
MISSING = object()
FORMATION_ORDER = {"NO_SETUP": 0, "CANDIDATE": 1, "PENDING": 2, "ARMED": 3, "ACTIVE": 4}
TERMINAL = {"INVALIDATED", "EXPIRED"}


def load_yaml(path):
    return yaml.safe_load((ROOT / path).read_text(encoding="utf-8"))


def lookup(obj, path):
    cur = obj
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        elif isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except (ValueError, IndexError):
                return MISSING
        else:
            return MISSING
    return cur


def known_at_view(value, now):
    if isinstance(value, dict):
        if isinstance(value.get("known_at"), (int, float)) and value["known_at"] > now:
            return MISSING
        out = {}
        for key, item in value.items():
            filtered = known_at_view(item, now)
            if filtered is not MISSING:
                out[key] = filtered
        return out
    if isinstance(value, list):
        return [x for item in value if (x := known_at_view(item, now)) is not MISSING]
    return value


def bool_result(value):
    return "TRUE" if value else "FALSE"


def valid_ohlc(bars):
    """Validate DT-P1 bars without conflating market time and availability time.

    ``timestamp`` keeps its SK01-declared bar timestamp role. ``known_at`` is the
    information-availability frontier used by this runtime. They are independent
    fields and may use different clocks/encodings; consequently this validator
    never compares them for equality or cross-clock ordering.
    """
    if not isinstance(bars, list) or not bars:
        return CD
    required = {"open", "high", "low", "close", "finality", "bar_finality", "known_at", "timestamp", "session_id", "index"}
    previous_known_at = None
    previous_index = None
    for bar in bars:
        if not isinstance(bar, dict) or not required <= set(bar):
            return CD
        if bar["finality"] != bar["bar_finality"] or bar["bar_finality"] not in {"DEVELOPING", "CONFIRMED", "REVISED"}:
            return INVALID
        if type(bar["known_at"]) not in {int, float} or isinstance(bar["known_at"], bool):
            return INVALID
        if bar["timestamp"] is None or isinstance(bar["timestamp"], (dict, list, bool)):
            return INVALID
        if type(bar["index"]) is not int:
            return INVALID
        if any(type(bar[field]) not in {int, float} or isinstance(bar[field], bool) for field in ("open", "high", "low", "close")):
            return INVALID
        if bar["high"] < max(bar["open"], bar["close"]) or bar["low"] > min(bar["open"], bar["close"]) or bar["high"] < bar["low"]:
            return INVALID
        if previous_known_at is not None and bar["known_at"] <= previous_known_at:
            return INVALID
        if previous_index is not None and bar["index"] <= previous_index:
            return INVALID
        previous_known_at = bar["known_at"]
        previous_index = bar["index"]
    return "TRUE"


def level_bounds(obj):
    if not isinstance(obj, dict):
        return None
    if "lower" in obj and "upper" in obj:
        return obj["lower"], obj["upper"]
    if "low" in obj and "high" in obj:
        return obj["low"], obj["high"]
    if "value" in obj:
        return obj["value"], obj["value"]
    return None


class SemanticRuntime:
    def __init__(self):
        self.setup_doc = load_yaml("assets/setup-catalog.yaml")
        self.rule_doc = load_yaml("assets/rule-catalog.yaml")
        self.profile_doc = load_yaml("assets/parameter-profile-registry.yaml")
        self.event_doc = load_yaml("assets/style-event-registry.yaml")
        self.state_doc = load_yaml("assets/state-model.yaml")
        self.import_doc = load_yaml("assets/foundation-import-manifest.yaml")
        self.authority_doc = load_yaml("assets/runtime-authority-registry.yaml")
        self.caller_doc = load_yaml("assets/caller-input-contract.yaml")
        self.setups = {x["setup_id"]: x for x in self.setup_doc["setups"]}
        self.rules = {x["rule_id"]: x for x in self.rule_doc["rules"]}
        self.profiles = {x["profile_id"]: x for x in self.profile_doc["profiles"]}
        self.events = {x["event_id"]: x for x in self.event_doc["events"]}
        self.authorities = {x["setup_id"]: x for x in self.authority_doc["setup_runtime_authorities"]}
        self.allowed_normalized_inputs = set(self.caller_doc["machine_contract"]["allowed_normalized_input_keys"])
        self.parameter_schema = self.profile_doc["machine_parameter_schema"]
        self.allowed_parameters_by_setup = self.profile_doc["allowed_parameters_by_setup_id"]
        self.required_parameters_by_setup = self.profile_doc["required_parameters_by_setup_id"]
        self.owner_map = self._owner_map()
        self.executed_rules = set()

    def _owner_map(self):
        result = {}
        for foundation in self.import_doc["mandatory_foundations"]:
            record = {
                "skill_id": foundation["skill_id"],
                "version": str(foundation["version"]),
                "sha256": foundation["sha256"],
            }
            for oid in foundation.get("source_object_ids", []):
                if oid in result and result[oid] != record:
                    raise ValueError(f"duplicate Foundation owner for {oid}")
                result[oid] = record
        declared = self.import_doc.get("canonical_object_owner_map", {})
        if declared != result:
            raise ValueError("canonical Foundation owner map diverges from accepted import records")
        return result

    def validate_caller(self, payload):
        normalized = payload.get("normalized_inputs")
        if not isinstance(normalized, dict):
            return CD
        if set(normalized) - self.allowed_normalized_inputs:
            return INVALID
        params = normalized.get("profile_parameters", {})
        if not isinstance(params, dict):
            return INVALID
        if isinstance(payload.get("foundation_objects"), dict) and payload["foundation_objects"].get("events"):
            return INVALID
        return "TRUE"

    def validate_parameters(self, setup_id, params):
        """Validate only registry-declared non-semantic parameters, without defaults."""
        if not isinstance(params, dict):
            return CD
        allowed = set(self.allowed_parameters_by_setup.get(setup_id, []))
        required = set(self.required_parameters_by_setup.get(setup_id, []))
        if not allowed or set(params) - allowed:
            return INVALID
        if not required <= set(params):
            return CD
        for name, value in params.items():
            spec = self.parameter_schema.get(name)
            if not isinstance(spec, dict):
                return INVALID
            if spec.get("type") == "boolean":
                if type(value) is not bool:
                    return INVALID
                continue
            if spec.get("type") == "uint32":
                if type(value) is not int:
                    return INVALID
                if value < spec.get("minimum", 0) or value > spec.get("maximum", 2**32 - 1):
                    return INVALID
                continue
            return INVALID
        return "TRUE"

    def validate_foundations(self, payload):
        bars = lookup(payload, "raw_dt_p1.bars")
        state = valid_ohlc(bars)
        if state != "TRUE":
            return state
        provenance = payload.get("foundation_object_provenance")
        objects = payload.get("foundation_objects")
        if not isinstance(provenance, dict) or not provenance or not isinstance(objects, dict):
            return CD
        if set(provenance) != set(objects):
            return INVALID
        by_index = {b["index"]: b for b in bars}
        by_time = {b["known_at"]: b for b in bars}

        def check_record(record, obj):
            if not isinstance(record, dict) or not isinstance(obj, dict):
                return False
            oid = record.get("source_object_id")
            expected = self.owner_map.get(oid)
            if not expected:
                return False
            for key in ("skill_id", "foundation_skill_id", "owner_skill_id"):
                if record.get(key) != expected["skill_id"]:
                    return False
            if str(record.get("foundation_version")) != expected["version"] or record.get("foundation_sha256") != expected["sha256"]:
                return False
            if obj.get("source_object_id") != oid:
                return False
            if obj.get("foundation_skill_id") != expected["skill_id"] or str(obj.get("foundation_version")) != expected["version"]:
                return False
            if obj.get("foundation_sha256") != expected["sha256"]:
                return False
            indices = record.get("raw_indices", [])
            if any(i not in by_index for i in indices):
                return False
            dependency_time = max([by_index[i]["known_at"] for i in indices] or [0])
            return record.get("known_at", -1) >= dependency_time and obj.get("known_at", -1) >= dependency_time

        for key, record in provenance.items():
            obj = objects.get(key)
            if isinstance(obj, list):
                items = record.get("item_records", [])
                if len(items) != len(obj) or any(not check_record(r, x) for r, x in zip(items, obj)):
                    return INVALID
            elif not check_record(record, obj):
                return INVALID
        for key in ("test_bar", "retest_bar", "return_bar", "mother_bar"):
            obj = objects.get(key)
            if isinstance(obj, dict) and obj.get("known_at") in by_time:
                raw = by_time[obj["known_at"]]
                if any(field in obj and obj[field] != raw[field] for field in ("open", "high", "low", "close")):
                    return INVALID
        if bars and all(b["open"] == b["high"] == b["low"] == b["close"] for b in bars):
            if any(k in objects for k in ("trend", "head_shoulders", "triangle", "pushes", "pullback_legs")):
                return INVALID
        return "TRUE"

    @staticmethod
    def _event_time(bars, predicate, after=None):
        for i, bar in enumerate(bars):
            if after is not None and bar["known_at"] <= after:
                continue
            if predicate(i, bar):
                return bar["known_at"]
        return None

    @staticmethod
    def _recursive_known_at_values(value):
        values = []
        if isinstance(value, dict):
            if type(value.get("known_at")) in {int, float}:
                values.append(value["known_at"])
            for item in value.values():
                values.extend(SemanticRuntime._recursive_known_at_values(item))
        elif isinstance(value, list):
            for item in value:
                values.extend(SemanticRuntime._recursive_known_at_values(item))
        return values

    @staticmethod
    def _same_instance_bars(view, confirmed_only=False):
        bars = lookup(view, "raw_dt_p1.bars")
        session_id = lookup(view, "normalized_inputs.session_id")
        if not isinstance(bars, list):
            return []
        result = [bar for bar in bars if bar.get("session_id") == session_id]
        if confirmed_only:
            result = [bar for bar in result if bar.get("bar_finality") == "CONFIRMED"]
        return result

    def _view_at_cut(self, payload, setup_id, authority, direction, cut):
        view = deepcopy(payload)
        view["setup_id"] = setup_id
        view["normalized_inputs"]["evaluation_time"] = cut
        session_id = view["normalized_inputs"].get("session_id")
        view["raw_dt_p1"]["bars"] = [
            bar for bar in view["raw_dt_p1"]["bars"]
            if bar["known_at"] <= cut and bar.get("session_id") == session_id
        ]
        filtered = known_at_view(view.get("foundation_objects", {}), cut)
        view["foundation_objects"] = {} if filtered is MISSING else filtered
        view["runtime"] = {"output_direction": direction, **authority["direction_branches"][direction]}
        return view

    def first_candidate_known_at(self, setup_id, payload, direction, authority=None):
        """Return the earliest cut where the canonical candidate Rules all hold.

        The scan is over information-availability frontiers, not raw history
        positions. It is scoped to the setup instance's session and direction.
        """
        authority = authority or self.authorities.get(setup_id)
        if not authority or direction not in {"BUY", "SELL"}:
            return None
        now = lookup(payload, "normalized_inputs.evaluation_time")
        if type(now) not in {int, float}:
            return None
        session_id = lookup(payload, "normalized_inputs.session_id")
        raw_bars = lookup(payload, "raw_dt_p1.bars")
        if not isinstance(raw_bars, list):
            return None
        frontiers = {
            bar["known_at"] for bar in raw_bars
            if bar.get("session_id") == session_id and bar.get("known_at") <= now
        }
        frontiers.update(
            value for value in self._recursive_known_at_values(payload.get("foundation_objects", {}))
            if value <= now
        )
        candidate_ids = authority.get("candidate_rule_ids", [])
        if not candidate_ids:
            return None
        for cut in sorted(frontiers):
            view = self._view_at_cut(payload, setup_id, authority, direction, cut)
            if not self._same_instance_bars(view, confirmed_only=True):
                continue
            derived = self.derive_events(view, authority, first_candidate_known_at=None)
            if derived is MISSING:
                continue
            view["derived_events"] = derived
            outcomes = [self.execute_rule(rule_id, view) for rule_id in candidate_ids]
            if outcomes and all(outcome == "TRUE" for outcome in outcomes):
                return cut
        return None

    def derive_events(self, view, authority, first_candidate_known_at=None):
        raw_bars = lookup(view, "raw_dt_p1.bars")
        if not isinstance(raw_bars, list):
            return MISSING
        bars = self._same_instance_bars(view, confirmed_only=True)
        if not bars:
            return {}
        direction = lookup(view, "runtime.evidence_direction")
        output_direction = lookup(view, "runtime.output_direction")
        tolerance = self.profile_parameter(view, "tolerance_ticks")
        if direction not in {"UP", "DOWN"} or output_direction not in {"BUY", "SELL"} or not isinstance(tolerance, int) or tolerance < 0:
            return MISSING
        fo = view.get("foundation_objects", {})
        boundary = None
        for key in authority.get("event_derivation", {}).get("boundary_key_precedence", ["boundary", "range", "consolidation", "mother_bar"]):
            candidate = fo.get(key)
            if level_bounds(candidate):
                boundary = candidate
                break
        bounds = level_bounds(boundary)
        breakout_time = breakout_index = None
        if bounds:
            lower, upper = bounds
            for i in range(1, len(bars)):
                prior, current = bars[i - 1], bars[i]
                if authority.get("event_derivation", {}).get("boundary_must_be_known_before_cross") and current["known_at"] < boundary.get("known_at", -1):
                    continue
                crossed = prior["close"] <= upper + tolerance and current["close"] > upper + tolerance if direction == "UP" else prior["close"] >= lower - tolerance and current["close"] < lower - tolerance
                if crossed:
                    breakout_time, breakout_index = current["known_at"], i
                    break
        follow_time = reclaim_time = None
        if breakout_index is not None:
            break_close = bars[breakout_index]["close"]
            lower, upper = bounds
            for bar in bars[breakout_index + 1:]:
                if follow_time is None and ((direction == "UP" and bar["close"] > break_close) or (direction == "DOWN" and bar["close"] < break_close)):
                    follow_time = bar["known_at"]
                if reclaim_time is None and ((direction == "UP" and bar["close"] <= upper + tolerance) or (direction == "DOWN" and bar["close"] >= lower - tolerance)):
                    reclaim_time = bar["known_at"]
        resumption_time = None
        for i in range(1, len(bars)):
            prior, current = bars[i - 1], bars[i]
            if direction == "UP" and prior["close"] < prior["open"] and current["close"] > prior["high"] + tolerance:
                resumption_time = current["known_at"]; break
            if direction == "DOWN" and prior["close"] > prior["open"] and current["close"] < prior["low"] - tolerance:
                resumption_time = current["known_at"]; break
        neckline_time = None
        nb = level_bounds(fo.get("neckline"))
        if nb:
            level = nb[1] if direction == "UP" else nb[0]
            for a, b in zip(bars, bars[1:]):
                if (direction == "UP" and a["close"] <= level + tolerance < b["close"]) or (direction == "DOWN" and a["close"] >= level - tolerance > b["close"]):
                    neckline_time = b["known_at"]; break
        legs = fo.get("pullback_legs") if isinstance(fo.get("pullback_legs"), list) else []
        leg_times = [x.get("known_at") for x in legs if x.get("confirmed") is True and x.get("known_at") is not None]
        first_attempt = leg_times[0] if len(leg_times) > 0 else None
        first_failure = leg_times[1] if len(leg_times) > 1 else None
        second_attempt = leg_times[2] if len(leg_times) > 2 else None
        branch_trigger = None
        gap_selected_branch = None
        gap_continuation_time = None
        gap_fill_time = None
        gap = fo.get("gap")
        if authority.get("analysis_branch_mode") == "AUTO_EVALUATE_ALL" and isinstance(gap, dict) and gap.get("prior_session_close") is not None and gap.get("current_session_open") is not None:
            opened_up = gap["current_session_open"] > gap["prior_session_close"]
            for bar in bars:
                if gap_continuation_time is None and ((opened_up and bar["close"] > gap["current_session_open"] + tolerance) or (not opened_up and bar["close"] < gap["current_session_open"] - tolerance)):
                    gap_continuation_time = bar["known_at"]
                if gap_fill_time is None and ((opened_up and bar["close"] < gap["current_session_open"]) or (not opened_up and bar["close"] > gap["current_session_open"])):
                    gap_fill_time = bar["known_at"]
            continuation_direction = "BUY" if opened_up else "SELL"
            gap_selected_branch = "CONTINUATION" if output_direction == continuation_direction else "FILL_HYPOTHESIS"
            branch_trigger = gap_continuation_time if gap_selected_branch == "CONTINUATION" else gap_fill_time
        candle_confirmation = None
        for prior, current in zip(bars, bars[1:]):
            relation = current["high"] <= prior["high"] and current["low"] >= prior["low"] or current["high"] >= prior["high"] and current["low"] <= prior["low"] or min(current["open"], current["close"]) <= min(prior["open"], prior["close"]) and max(current["open"], current["close"]) >= max(prior["open"], prior["close"])
            if relation:
                candle_confirmation = current["known_at"]
                break
        policy = authority["confirmation_policy"]
        primary_by_policy = {
            "FOLLOW_THROUGH": follow_time, "RESUMPTION": resumption_time,
            "OPPOSITE_AFTER_RECLAIM": reclaim_time, "NECKLINE_CROSS": neckline_time,
            "SECOND_ENTRY": second_attempt, "CANDLE_RELATION": candle_confirmation,
            "BOUNDARY_CROSS": breakout_time, "RANGE_RETURN": reclaim_time or resumption_time,
            "GAP_BRANCH": branch_trigger,
        }
        if policy == "DIRECTIONAL_AFTER_PRIMARY":
            primary_spec = authority.get("confirmation_primary", {})
            if primary_spec.get("kind") == "DERIVED_EVENT":
                primary = {
                    "breakout_time": breakout_time,
                    "follow_through_time": follow_time,
                    "reclaim_time": reclaim_time,
                    "resumption_time": resumption_time,
                    "neckline_cross_time": neckline_time,
                    "candle_confirmation_time": candle_confirmation,
                    "branch_trigger_time": branch_trigger,
                    "first_attempt_time": first_attempt,
                    "first_failure_time": first_failure,
                    "second_attempt_time": second_attempt,
                }.get(primary_spec.get("key"))
            elif primary_spec.get("kind") == "FOUNDATION_KNOWN_AT":
                source = fo.get(primary_spec.get("key"))
                primary = source.get("known_at") if isinstance(source, dict) else None
            else:
                primary = None
        else:
            primary = primary_by_policy.get(policy)
        wanted = "UP" if output_direction == "BUY" else "DOWN"
        confirmation_time = confirmation_direction = None
        if primary is not None:
            if policy in {"FOLLOW_THROUGH", "RESUMPTION", "NECKLINE_CROSS", "SECOND_ENTRY", "CANDLE_RELATION", "BOUNDARY_CROSS", "GAP_BRANCH"}:
                confirmation_time = primary
                confirmation_direction = wanted
            else:
                for bar in bars:
                    if bar["known_at"] <= primary:
                        continue
                    bar_direction = "UP" if bar["close"] > bar["open"] else "DOWN" if bar["close"] < bar["open"] else None
                    if bar_direction == wanted:
                        confirmation_time, confirmation_direction = bar["known_at"], bar_direction
                        break
        expiry_count = self.profile_parameter(view, "expiry_confirmed_bars")
        post_candidate_bars = [
            bar for bar in bars
            if first_candidate_known_at is not None and bar["known_at"] > first_candidate_known_at
        ]
        expiry_index = expiry_count - 1 if isinstance(expiry_count, int) else None
        expiry_time = (
            post_candidate_bars[expiry_index]["known_at"]
            if isinstance(expiry_index, int) and 0 <= expiry_index < len(post_candidate_bars)
            else None
        )
        invalidation_time = None
        invalidation = authority["invalidation_policy"]
        inv_bounds = None
        for key in invalidation["foundation_key_precedence"]:
            inv_bounds = level_bounds(fo.get(key))
            if inv_bounds:
                break
        if inv_bounds:
            lower, upper = inv_bounds
            if confirmation_time is not None:
                invalidation_time = self._event_time(
                    bars,
                    lambda i, b: b["close"] < lower - tolerance if output_direction == "BUY" else b["close"] > upper + tolerance,
                    after=confirmation_time,
                )
        return {
            "breakout_time": breakout_time, "follow_through_time": follow_time, "reclaim_time": reclaim_time,
            "resumption_time": resumption_time, "confirmation_time": confirmation_time,
            "confirmation_direction": confirmation_direction, "neckline_cross_time": neckline_time,
            "first_attempt_time": first_attempt, "first_failure_time": first_failure,
            "second_attempt_time": second_attempt, "branch_trigger_time": branch_trigger,
            "gap_selected_branch": gap_selected_branch,
            "gap_continuation_time": gap_continuation_time, "gap_fill_time": gap_fill_time,
            "opposite_confirmation_time": confirmation_time if policy == "OPPOSITE_AFTER_RECLAIM" or authority.get("confirmation_must_be_opposite_to_evidence") else None,
            "candle_confirmation_time": candle_confirmation, "invalidation_time": invalidation_time,
            "first_candidate_known_at": first_candidate_known_at,
            "expiry_time": expiry_time, "reset_time": None,
        }

    @staticmethod
    def profile_parameter(view, name):
        return lookup(view, "normalized_inputs.profile_parameters." + name)

    def compare_event_before(self, view, event_path, limit_path):
        event, limit = lookup(view, event_path), lookup(view, limit_path)
        if event is MISSING or limit is MISSING:
            return CD
        if event is None:
            return "FALSE"
        return "TRUE" if limit is None else bool_result(event <= limit)

    def last_two(self, view, path):
        bars = lookup(view, path)
        return (bars[-2], bars[-1]) if valid_ohlc(bars) == "TRUE" and len(bars) >= 2 and bars[-2]["finality"] == bars[-1]["finality"] == "CONFIRMED" else None

    def execute_rule(self, rule_id, view):
        self.executed_rules.add(rule_id)
        rule = self.rules[rule_id]
        contract = rule.get("executable_contract") or {"operation": "REQUIRED_INPUTS_PRESENT"}
        op = contract["operation"]
        now = lookup(view, "normalized_inputs.evaluation_time")
        if op == "DT_P1_AND_FOUNDATION_VALID":
            return self.validate_foundations(view)
        if op == "COMPOSITE_RULE_IDS":
            values = [self.execute_rule(x, view) for x in contract["rule_ids"]]
            return INVALID if INVALID in values else CD if CD in values else bool_result(all(x == "TRUE" for x in values))
        if op == "MTF_CONFIRMED_ONLY":
            obj = view.get("foundation_objects", {}).get("parent_context") or view.get("foundation_objects", {}).get("context")
            return CD if not isinstance(obj, dict) else bool_result(obj.get("confirmed") is True and obj.get("known_at", 10**30) <= now)
        if op == "REQUIRED_INPUTS_PRESENT":
            return bool_result(bool(lookup(view, "raw_dt_p1.bars")) and bool(view.get("foundation_objects")))
        if op in {"NO_TRADE_CLASSIFY", "NON_EXECUTABLE_CLASSIFICATION"}:
            return CD
        if op == "DATA_FIREWALL_CLEAR":
            forbidden = {"resting_liquidity", "executed_volume", "aggressor_side", "participant_identity", "intent", "l2", "l3"}
            return bool_result(not forbidden & set(view.get("normalized_inputs", {})))
        if op == "PRODUCE_STYLE_EVENT":
            value = lookup(view, contract["output_path"])
            return CD if value is MISSING else bool_result(value is not None)
        if op in {"TRENDLINE_INTERACTION", "CHANNEL_INTERACTION"}:
            bars, geometry = lookup(view, contract["bars_path"]), lookup(view, contract["geometry_path"])
            tolerance = self.profile_parameter(view, contract["tolerance_parameter"])
            if valid_ohlc(bars) != "TRUE" or not isinstance(geometry, dict) or not isinstance(tolerance, int): return CD
            if geometry.get("source_object_id") not in self.owner_map or geometry.get("confirmed") is not True: return INVALID
            bar = bars[-1]
            if op == "TRENDLINE_INTERACTION":
                return CD if geometry.get("value") is None else bool_result(bar["low"] - tolerance <= geometry["value"] <= bar["high"] + tolerance)
            return CD if geometry.get("lower") is None or geometry.get("upper") is None else bool_result(bar["low"] >= geometry["lower"] - tolerance and bar["high"] <= geometry["upper"] + tolerance)
        if op == "PROFILE_MATCH":
            pid = lookup(view, "normalized_inputs.profile_id")
            return CD if pid not in self.profiles else bool_result(view["setup_id"] in self.profiles[pid].get("applies_to_setup_ids", []))
        if op == "FIELD_EQ":
            value = lookup(view, contract["path"]); return CD if value is MISSING else bool_result(value == contract["value"])
        if op == "FIELD_IN":
            value = lookup(view, contract["path"]); return CD if value is MISSING else bool_result(value in contract["values"])
        if op == "OBJECT_CONFIRMED":
            obj = lookup(view, contract["path"])
            return CD if not isinstance(obj, dict) or "known_at" not in obj else bool_result(obj.get("confirmed") is True and obj["known_at"] <= now)
        if op == "LAST_BAR_CONFIRMED":
            bars = lookup(view, contract["bars_path"]); state = valid_ohlc(bars)
            return state if state != "TRUE" else bool_result(bars[-1]["finality"] == "CONFIRMED" and bars[-1]["known_at"] <= now)
        if op == "INTERVAL_INTERSECTS":
            bar, zone = lookup(view, contract["bar_path"]), lookup(view, contract["zone_path"])
            return CD if not isinstance(bar, dict) or not isinstance(zone, dict) else bool_result(max(bar["low"], zone["lower"]) <= min(bar["high"], zone["upper"]))
        if op == "BOUNDARY_TEST":
            bar, zone, direction = lookup(view, contract["bar_path"]), lookup(view, contract["zone_path"]), lookup(view, "runtime.evidence_direction")
            tolerance = self.profile_parameter(view, "tolerance_ticks")
            if not isinstance(bar, dict) or not isinstance(zone, dict) or direction not in {"UP", "DOWN"} or not isinstance(tolerance, int): return CD
            intersects = max(bar["low"], zone["lower"]) <= min(bar["high"], zone["upper"])
            intact = bar["close"] <= zone["upper"] + tolerance if direction == "UP" else bar["close"] >= zone["lower"] - tolerance
            return bool_result(intersects and intact)
        if op == "BOUNDED_VALUES":
            values, lower, upper = lookup(view, contract["values_path"]), lookup(view, contract["lower_path"]), lookup(view, contract["upper_path"])
            return CD if values is MISSING or lower is MISSING or upper is MISSING or not values else bool_result(all(lower <= x <= upper for x in values))
        if op == "EVENT_BEFORE": return self.compare_event_before(view, contract["event_path"], contract["limit_path"])
        if op == "CLOSE_CROSS":
            bars, boundary, direction = lookup(view, contract["bars_path"]), lookup(view, contract["boundary_path"]), lookup(view, contract["direction_path"])
            tolerance = self.profile_parameter(view, contract["tolerance_parameter"])
            if valid_ohlc(bars) != "TRUE" or len(bars) < 2 or not isinstance(boundary, dict) or direction not in {"UP", "DOWN"} or not isinstance(tolerance, int): return CD
            level = boundary["upper"] if direction == "UP" else boundary["lower"]
            return bool_result(any(a["close"] <= level + tolerance < b["close"] for a, b in zip(bars, bars[1:]))) if direction == "UP" else bool_result(any(a["close"] >= level - tolerance > b["close"] for a, b in zip(bars, bars[1:])))
        if op == "COUNTER_DIRECTION_LEG":
            context, legs = lookup(view, contract["context_path"]), lookup(view, contract["legs_path"])
            wanted = "DOWN" if context == "TREND_UP" else "UP" if context == "TREND_DOWN" else None
            return CD if wanted is None or not isinstance(legs, list) else bool_result(any(x.get("confirmed") is True and x.get("direction") == wanted for x in legs))
        if op in {"BODY_CONTAINS", "BAR_RELATION"}:
            pair = self.last_two(view, contract["bars_path"])
            if not pair: return CD
            prior, current = pair
            inclusive = self.profile_parameter(view, contract.get("inclusive_parameter", "inclusive_equality"))
            if inclusive is MISSING: inclusive = True
            if op == "BODY_CONTAINS":
                p0, p1 = sorted((prior["open"], prior["close"])); c0, c1 = sorted((current["open"], current["close"]))
                return bool_result(c0 <= p0 and c1 >= p1) if inclusive else bool_result(c0 < p0 and c1 > p1)
            result = {"HIGH_COVERS": current["high"] >= prior["high"], "LOW_COVERS": current["low"] <= prior["low"], "HIGH_WITHIN": current["high"] <= prior["high"], "LOW_WITHIN": current["low"] >= prior["low"]}[contract["relation"]]
            return bool_result(result)
        if op == "CLOSE_LOCATION":
            bars = lookup(view, contract["bars_path"])
            if valid_ohlc(bars) != "TRUE": return CD
            bar = bars[-1]; span = bar["high"] - bar["low"]
            num, den = self.profile_parameter(view, contract["minimum_parameter"]), self.profile_parameter(view, contract["denominator_parameter"])
            if span <= 0 or not isinstance(num, int) or not isinstance(den, int) or den <= 0: return CD
            distance = bar["close"] - bar["low"] if lookup(view, "runtime.output_direction") == "BUY" else bar["high"] - bar["close"]
            return bool_result(distance * den >= span * num)
        if op == "EVENT_ORDER":
            values = [lookup(view, p) for p in contract["paths"]]
            if any(v is MISSING or v is None for v in values): return CD
            if not all(a < b for a, b in zip(values, values[1:])): return "FALSE"
            before = lookup(view, contract.get("before_optional_path", "")) if contract.get("before_optional_path") else None
            return bool_result(before in (MISSING, None) or values[-1] < before)
        if op == "OBJECT_BETWEEN":
            obj, start, end = lookup(view, contract["path"]), lookup(view, contract["start_path"]), lookup(view, contract["end_path"])
            return CD if not isinstance(obj, dict) or start is MISSING or end is MISSING else bool_result(obj.get("confirmed") is True and start < obj.get("known_at", -1) < end)
        if op == "NUM_LE_PARAMETER":
            value, threshold = lookup(view, contract["path"]), self.profile_parameter(view, contract["parameter"])
            return CD if value is MISSING or threshold is MISSING else bool_result(value <= threshold)
        if op == "HEAD_BEYOND_SHOULDERS":
            extrema = lookup(view, contract["path"])
            if not isinstance(extrema, list) or len(extrema) != 3: return CD
            values = [x.get("price") for x in extrema]
            if any(x is None for x in values): return CD
            return bool_result(values[1] < values[0] and values[1] < values[2]) if lookup(view, "runtime.output_direction") == "BUY" else bool_result(values[1] > values[0] and values[1] > values[2])
        if op == "OPPOSITE_CONFIRMATION":
            evidence_path = next(v for k, v in contract.items() if k.endswith("direction_path") and k != "event_direction_path")
            event_direction, evidence_direction = lookup(view, contract["event_direction_path"]), lookup(view, evidence_path)
            time_result = self.compare_event_before(view, contract["event_time_path"], contract["expiry_path"])
            return CD if event_direction not in {"UP", "DOWN"} or evidence_direction not in {"UP", "DOWN"} or time_result == CD else bool_result(time_result == "TRUE" and event_direction != evidence_direction)
        if op == "FIELD_BETWEEN":
            value, lower, upper = lookup(view, contract["path"]), lookup(view, contract["lower_path"]), lookup(view, contract["upper_path"])
            return CD if MISSING in (value, lower, upper) else bool_result(lower <= value <= upper)
        if op == "DISTANCE_LE_PARAMETER":
            a, b, threshold = lookup(view, contract["a_path"]), lookup(view, contract["b_path"]), self.profile_parameter(view, contract["parameter"])
            return CD if MISSING in (a, b, threshold) else bool_result(abs(a - b) <= threshold)
        if op == "NO_EVENT_BEFORE":
            event, limit = lookup(view, contract["event_path"]), lookup(view, contract["limit_path"])
            return CD if event is MISSING or limit is MISSING else bool_result(event is None or event > limit)
        if op == "SESSION_GAP":
            prior, current = lookup(view, contract["prior_close_path"]), lookup(view, contract["current_open_path"])
            return CD if prior is MISSING or current is MISSING else bool_result(current != prior)
        if op == "COUNT_EQ":
            values = lookup(view, contract["path"]); return CD if not isinstance(values, list) else bool_result(len(values) == contract["value"])
        if op == "COUNT_CONFIRMED":
            values = lookup(view, contract["path"]); return CD if not isinstance(values, list) else bool_result(sum(x.get("confirmed") is True for x in values) == contract["value"])
        if op == "CONVERGENCE":
            start, end = lookup(view, contract["start_path"]), lookup(view, contract["end_path"])
            return CD if start is MISSING or end is MISSING else bool_result(start > end >= 0)
        if op == "ALTERNATING_SEQUENCE":
            values, minimum = lookup(view, contract["path"]), self.profile_parameter(view, contract["minimum_count_parameter"])
            if not isinstance(values, list) or not isinstance(minimum, int): return CD
            seq = [x.get(contract["field"]) for x in values]
            return bool_result(len(seq) >= minimum and all(a != b and a is not None and b is not None for a, b in zip(seq, seq[1:])))
        if op == "WEDGE_CONTEXT":
            pushes, context = lookup(view, contract["pushes_path"]), lookup(view, contract["context_path"])
            if not isinstance(pushes, list) or context is MISSING: return CD
            directions = {x.get("direction") for x in pushes if x.get("confirmed") is True}
            return bool_result(len(pushes) == 3 and len(directions) == 1 and context in {"TREND_UP", "TREND_DOWN", "RANGE"})
        if op in {"WICK_BODY_RATIO", "REJECTION_AT_LOCATION"}:
            bars = lookup(view, contract["bars_path"]); state = valid_ohlc(bars)
            if state != "TRUE": return state
            side = lookup(view, contract.get("side_path", "runtime.rejection_side"))
            num, den = self.profile_parameter(view, contract["ratio_num_parameter"]), self.profile_parameter(view, contract["ratio_den_parameter"])
            if side not in {"LOWER", "UPPER"} or not isinstance(num, int) or not isinstance(den, int) or den <= 0: return CD
            def ratio_ok(bar):
                body = abs(bar["close"] - bar["open"])
                wick = min(bar["open"], bar["close"]) - bar["low"] if side == "LOWER" else bar["high"] - max(bar["open"], bar["close"])
                return body > 0 and wick * den >= body * num
            if op == "WICK_BODY_RATIO": return bool_result(any(ratio_ok(x) for x in bars))
            location, tolerance = lookup(view, contract["location_path"]), self.profile_parameter(view, "tolerance_ticks")
            return CD if not isinstance(location, dict) or not isinstance(tolerance, int) else bool_result(any(ratio_ok(x) for x in bars) and location.get("distance_ticks", tolerance + 1) <= tolerance)
        if op == "BROOKS_TWO_LEGGED_PULLBACK":
            legs, classification, context = lookup(view, contract["legs_path"]), lookup(view, contract["classification_path"]), lookup(view, contract["context_path"])
            if not isinstance(legs, list) or classification not in {"H2", "L2"} or context is MISSING or any(x.get("confirmed") is not True for x in legs): return CD
            directions = [x.get("direction") for x in legs]
            return bool_result(context == "TREND_UP" and directions == ["DOWN", "UP", "DOWN"]) if classification == "H2" else bool_result(context == "TREND_DOWN" and directions == ["UP", "DOWN", "UP"])
        raise ValueError(f"unsupported operation {op} for {rule_id}")

    def _profile_check(self, view, authority):
        ni = view["normalized_inputs"]
        profile_id = ni.get("profile_id")
        if profile_id not in authority["parameter_profile_ids"] or profile_id not in self.profiles:
            return CD
        if view["setup_id"] not in self.profiles[profile_id].get("applies_to_setup_ids", []):
            return INVALID
        params = ni.get("profile_parameters")
        if len(authority.get("event_profile_ids", [])) != 1 or authority["event_profile_ids"][0] not in self.profiles:
            return INVALID
        if authority.get("reset_policy", {}).get("mode") != "NOT_SUPPORTED":
            return INVALID
        if authority.get("expiry_policy", {}).get("mode") != "CONFIRMED_BARS":
            return INVALID
        return self.validate_parameters(view["setup_id"], params)

    def evaluate_branch_details(self, setup_id, payload, direction):
        """Evaluate one directional setup instance and expose its time authority.

        The returned metadata is derived exclusively from caller evidence and the
        registry composition. It is used by QA, AI and engine mirrors; it is not
        accepted as caller input.
        """
        empty = {
            "state": INVALID, "first_candidate_known_at": None,
            "expiry_time": None, "confirmation_time": None,
            "invalidation_time": None, "instance_id": None,
        }
        if setup_id not in self.authorities or direction not in {"BUY", "SELL"}:
            return empty
        caller_state = self.validate_caller(payload)
        if caller_state != "TRUE":
            return {**empty, "state": caller_state}
        view = deepcopy(payload)
        view["setup_id"] = setup_id
        authority = self.authorities[setup_id]
        profile_state = self._profile_check(view, authority)
        if profile_state != "TRUE":
            return {**empty, "state": profile_state}
        now = lookup(view, "normalized_inputs.evaluation_time")
        if type(now) not in {int, float}:
            return {**empty, "state": CD}
        foundation_state = self.validate_foundations(view)
        if foundation_state != "TRUE":
            return {**empty, "state": foundation_state}
        full_payload = deepcopy(view)
        first_candidate = self.first_candidate_known_at(setup_id, full_payload, direction, authority)
        view = self._view_at_cut(full_payload, setup_id, authority, direction, now)
        derived = self.derive_events(view, authority, first_candidate_known_at=first_candidate)
        instance_id = None
        if first_candidate is not None:
            ni = view["normalized_inputs"]
            instance_id = {
                "setup_id": setup_id,
                "direction": direction,
                "instrument_id": ni.get("instrument_id"),
                "timeframe": ni.get("timeframe"),
                "session_id": ni.get("session_id"),
                "profile_id": ni.get("profile_id"),
                "first_candidate_known_at": first_candidate,
            }
        details = {
            **empty,
            "first_candidate_known_at": first_candidate,
            "instance_id": instance_id,
        }
        if derived is MISSING:
            return {**details, "state": CD}
        view["derived_events"] = derived
        details.update({
            "expiry_time": derived.get("expiry_time"),
            "confirmation_time": derived.get("confirmation_time"),
            "invalidation_time": derived.get("invalidation_time"),
        })
        for event in self.events.values():
            if event.get("status", "ACTIVE") != "ACTIVE":
                continue
            for producer_id in event.get("producer_rule_or_procedure_ids", []):
                if producer_id in self.rules:
                    self.execute_rule(producer_id, view)
        if valid_ohlc(view["raw_dt_p1"]["bars"]) != "TRUE" or not self._same_instance_bars(view, confirmed_only=True):
            return {**details, "state": CD}
        rule_ids = []
        for key in ("context_rule_ids", "candidate_rule_ids", "pending_rule_ids", "armed_rule_ids", "trigger_rule_ids", "confirmation_rule_ids", "active_rule_ids", "invalidation_rule_ids", "expiry_rule_ids"):
            rule_ids.extend(authority.get(key, []))
        outcomes = {rid: self.execute_rule(rid, view) for rid in dict.fromkeys(rule_ids) if self.rules[rid].get("status", "ACTIVE") == "ACTIVE"}
        if INVALID in outcomes.values():
            return {**details, "state": INVALID}
        confirmation = derived["confirmation_time"]
        expiry = derived["expiry_time"]
        # Expiry can only exist after a real candidate. If expiry and first
        # activation share a frontier, expiry closes the pre-ACTIVE instance.
        if isinstance(expiry, (int, float)) and expiry <= now and (confirmation is None or expiry <= confirmation):
            return {**details, "state": "EXPIRED"}
        # Post-ACTIVE invalidation is meaningful only when activation preceded it.
        if (
            confirmation is not None
            and (expiry is None or confirmation < expiry)
            and derived["invalidation_time"] is not None
            and derived["invalidation_time"] <= now
        ):
            return {**details, "state": "INVALIDATED"}
        def all_true(key):
            ids = authority[key]
            return bool(ids) and all(outcomes.get(rid) == "TRUE" for rid in ids)
        for state, key in (("ACTIVE", "active_rule_ids"), ("ARMED", "armed_rule_ids"), ("PENDING", "pending_rule_ids"), ("CANDIDATE", "candidate_rule_ids")):
            if all_true(key):
                return {**details, "state": state}
        candidate_values = [outcomes.get(x) for x in authority["candidate_rule_ids"]]
        state = "NO_SETUP" if "FALSE" in candidate_values else CD
        return {**details, "state": state}

    def evaluate_branch(self, setup_id, payload, direction):
        return self.evaluate_branch_details(setup_id, payload, direction)["state"]

    def evaluate_all(self, setup_id, payload):
        details = {direction: self.evaluate_branch_details(setup_id, payload, direction) for direction in ("BUY", "SELL")}
        branches = {direction: item["state"] for direction, item in details.items()}
        out = {
            "setup_id": setup_id, "known_at": lookup(payload, "normalized_inputs.evaluation_time"), "directional_states": branches,
            "pending_buy_setups": [], "pending_sell_setups": [], "active_buy_setups": [], "active_sell_setups": [],
            "invalidated_setups": [], "expired_setups": [], "cannot_determine_items": [],
        }
        for direction, state in branches.items():
            item = {
                "setup_id": setup_id, "direction": direction, "state": state,
                "runtime_authority_id": self.authorities[setup_id]["authority_id"],
                "first_candidate_known_at": details[direction]["first_candidate_known_at"],
                "expiry_time": details[direction]["expiry_time"],
                "instance_id": details[direction]["instance_id"],
            }
            if state == "PENDING": out["pending_buy_setups" if direction == "BUY" else "pending_sell_setups"].append(item)
            elif state == "ACTIVE": out["active_buy_setups" if direction == "BUY" else "active_sell_setups"].append(item)
            elif state == "INVALIDATED": out["invalidated_setups"].append(item)
            elif state == "EXPIRED": out["expired_setups"].append(item)
            elif state in {CD, INVALID}: out["cannot_determine_items"].append(item)
        return out

    def evaluate_sequence(self, setup_id, payload, cuts, direction):
        previous, path, prior_cut = "NO_SETUP", [], None
        for cut in cuts:
            now = cut["evaluation_time"] if isinstance(cut, dict) else cut
            if prior_cut is not None and now < prior_cut: return INVALID
            prior_cut = now
            view = deepcopy(payload); view["normalized_inputs"]["evaluation_time"] = now
            snapshot = self.evaluate_branch(setup_id, view, direction)
            if previous in TERMINAL: state = previous
            elif snapshot in TERMINAL: state = snapshot
            elif snapshot in FORMATION_ORDER and FORMATION_ORDER[snapshot] >= FORMATION_ORDER.get(previous, 0): state = snapshot
            elif previous == "ACTIVE": state = "ACTIVE"
            else: state = previous if snapshot in {CD, "NO_SETUP"} else snapshot
            previous = state; path.append(state)
        return path

    def derive_event_for_test(self, setup_id, payload, direction, event_id):
        if setup_id not in self.authorities or event_id not in self.events: return MISSING
        view = deepcopy(payload)
        now = lookup(view, "normalized_inputs.evaluation_time")
        if not isinstance(now, (int, float)): return MISSING
        view["raw_dt_p1"]["bars"] = [b for b in view["raw_dt_p1"]["bars"] if b["known_at"] <= now]
        filtered = known_at_view(view.get("foundation_objects", {}), now)
        view["foundation_objects"] = {} if filtered is MISSING else filtered
        authority = self.authorities[setup_id]
        view["runtime"] = {"output_direction": direction, **authority["direction_branches"][direction]}
        full_payload = deepcopy(payload)
        full_payload["setup_id"] = setup_id
        first_candidate = self.first_candidate_known_at(setup_id, full_payload, direction, authority)
        derived = self.derive_events(view, authority, first_candidate_known_at=first_candidate)
        path = self.events[event_id].get("output_path", "").removeprefix("derived_events.")
        return derived.get(path, MISSING) if isinstance(derived, dict) else MISSING

    def derive_analysis_branch_for_test(self, setup_id, payload, direction):
        """Expose an internally selected analysis branch for executable QA only."""
        if setup_id not in self.authorities or direction not in {"BUY", "SELL"}:
            return MISSING
        view = deepcopy(payload)
        now = lookup(view, "normalized_inputs.evaluation_time")
        if not isinstance(now, (int, float)) or not isinstance(view.get("raw_dt_p1"), dict):
            return MISSING
        view["raw_dt_p1"]["bars"] = [b for b in view["raw_dt_p1"].get("bars", []) if b.get("known_at", 10**30) <= now]
        filtered = known_at_view(view.get("foundation_objects", {}), now)
        view["foundation_objects"] = {} if filtered is MISSING else filtered
        authority = self.authorities[setup_id]
        view["runtime"] = {"output_direction": direction, **authority["direction_branches"][direction]}
        full_payload = deepcopy(payload)
        full_payload["setup_id"] = setup_id
        first_candidate = self.first_candidate_known_at(setup_id, full_payload, direction, authority)
        derived = self.derive_events(view, authority, first_candidate_known_at=first_candidate)
        return derived.get("gap_selected_branch", MISSING) if isinstance(derived, dict) else MISSING

    def evaluate_rule_fixture(self, row):
        rule_id = row.get("rule_id")
        if rule_id not in self.rules:
            return CD
        view = deepcopy(row)
        setup_id = row.get("setup_id")
        if setup_id in self.authorities and isinstance(row.get("normalized_inputs"), dict):
            direction = (row.get("test_assertions") or {}).get("direction", "BUY")
            now = lookup(view, "normalized_inputs.evaluation_time")
            if isinstance(now, (int, float)) and isinstance(view.get("raw_dt_p1"), dict):
                view["raw_dt_p1"]["bars"] = [b for b in view["raw_dt_p1"].get("bars", []) if b.get("known_at", 10**30) <= now]
                filtered = known_at_view(view.get("foundation_objects", {}), now)
                view["foundation_objects"] = {} if filtered is MISSING else filtered
                authority = self.authorities[setup_id]
                view["runtime"] = {"output_direction": direction, **authority["direction_branches"][direction]}
                full_payload = deepcopy(row)
                full_payload["setup_id"] = setup_id
                first_candidate = self.first_candidate_known_at(setup_id, full_payload, direction, authority)
                derived = self.derive_events(view, authority, first_candidate_known_at=first_candidate)
                if derived is not MISSING:
                    view["derived_events"] = derived
        return self.execute_rule(rule_id, view)

    def evaluate_utility(self, row):
        fixture_type = row.get("fixture_type")
        op, data = row.get("operation"), row.get("input", {})
        if fixture_type == "GOVERNANCE_CONTRACT" and op == "assert_inactive_rule":
            rule = self.rules.get(data.get("rule_id"), {})
            return "TRUE" if rule.get("status") == data.get("required_status") and all(
                not authority.get("reset_rule_ids") for authority in self.authorities.values()
            ) else "FALSE"
        if fixture_type == "LIVE_REPLAY_REVISION":
            records = data.get("records", [])
            if any(records[i]["known_at"] > records[i + 1]["known_at"] for i in range(len(records) - 1)): return INVALID
            return [[r["revision_id"] for r in records if r["known_at"] <= cut] for cut in data.get("cuts", [])]
        if fixture_type == "VISUAL_CONTRACT":
            forbidden = {"resting_liquidity", "executed_volume", "aggressor_side", "participant_identity", "intent", "l2", "l3"}
            required = {"object_id", "time_coordinate", "price_ticks", "known_at", "bar_finality", "lineage_variant", "profile_id", "source_object_ids"}
            return INVALID if forbidden & set(data) else "TRUE" if required <= set(data) and data["bar_finality"] in {"DEVELOPING", "CONFIRMED", "REVISED"} else CD
        if fixture_type == "STATE_TRANSITION":
            transitions = {x["transition_id"]: x for x in self.state_doc["transitions"]}
            transition = transitions[row["transition_id"]]; ni = row["normalized_inputs"]
            if ni.get("event_known_at", 10**30) > ni.get("evaluation_time", -1): return CD
            return transition["to_state"] if ni.get("from_state") == transition["from_state"] and ni.get("event_condition") == transition["event_condition"] else "FALSE"
        if op == "validate_ohlc":
            if not {"open", "high", "low", "close"} <= set(data): return CD
            return "TRUE" if data["high"] >= max(data["open"], data["close"]) and data["low"] <= min(data["open"], data["close"]) else INVALID
        if op == "closed_bar_eligible":
            if not {"bar_finality", "bar_known_at", "evaluation_time"} <= set(data): return CD
            return "TRUE" if data["bar_finality"] == "CONFIRMED" and data["bar_known_at"] <= data["evaluation_time"] else CD
        if op == "variant_resolve":
            requested = data.get("requested_variant")
            if requested is not None: return data.get("result_by_variant", {}).get(requested, CD)
            values = [data.get("result_by_variant", {}).get(v, CD) for v in data.get("supported_variants", [])]
            return values[0] if values and all(v == values[0] for v in values) else "VARIANT_CONFLICT"
        if op == "data_firewall":
            forbidden = {"resting_liquidity", "executed_volume", "aggressor_side", "participant_identity", "intent", "l2", "l3"}
            return CD if data.get("available_contract") == "DT-P1" and data.get("requested_inference") in forbidden else "TRUE"
        if op in {"inside_bar", "outside_bar", "body_engulf"}:
            prior, current = data.get("prior", {}), data.get("current", {})
            required = {"open", "high", "low", "close", "finality"}
            if not required <= set(prior) or not required <= set(current) or prior["finality"] != "CONFIRMED" or current["finality"] != "CONFIRMED": return CD
            if op == "inside_bar": result = current["high"] <= prior["high"] and current["low"] >= prior["low"]
            elif op == "outside_bar": result = current["high"] >= prior["high"] and current["low"] <= prior["low"]
            else:
                p0, p1 = sorted((prior["open"], prior["close"])); c0, c1 = sorted((current["open"], current["close"])); result = c0 <= p0 and c1 >= p1
            return bool_result(result)
        if op == "rejection_bar":
            bar = data.get("bar", {})
            if not {"open", "high", "low", "close", "finality"} <= set(bar) or bar["finality"] != "CONFIRMED": return CD
            body = abs(bar["close"] - bar["open"])
            if body == 0: return CD
            wick = min(bar["open"], bar["close"]) - bar["low"] if data.get("side") == "LOWER" else bar["high"] - max(bar["open"], bar["close"])
            return bool_result(wick * data["min_wick_to_body_den"] >= body * data["min_wick_to_body_num"] and data.get("location_valid") is True)
        return CD


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("fixture_json", nargs="?")
    parser.add_argument("--setup-id")
    args = parser.parse_args()
    runtime = SemanticRuntime()
    if not args.fixture_json or not args.setup_id:
        print(json.dumps({"runtime": "READY", "setups": len(runtime.authorities), "caller_direction": "PROHIBITED"}, sort_keys=True))
        return 0
    payload = json.loads(Path(args.fixture_json).read_text(encoding="utf-8"))
    print(json.dumps(runtime.evaluate_all(args.setup_id, payload), sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
