#!/usr/bin/env python3
from decimal import Decimal
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
CD = "CANNOT_DETERMINE"
INVALID = "CANNOT_DETERMINE_WITH_INVALID_DATA"


def calculate(op, x):
    try:
        if op == "price_to_ticks":
            q = Decimal(str(x["price"])) / Decimal(str(x["tick_size"]))
            return int(q) if q == q.to_integral_value() else CD
        if op == "bar_range": return x["high_ticks"] - x["low_ticks"]
        if op == "body": return abs(x["close_ticks"] - x["open_ticks"])
        if op == "upper_wick": return x["high_ticks"] - max(x["open_ticks"], x["close_ticks"])
        if op == "lower_wick": return min(x["open_ticks"], x["close_ticks"]) - x["low_ticks"]
        if op == "close_location":
            d = x["high_ticks"] - x["low_ticks"]
            return [x["close_ticks"] - x["low_ticks"], d] if d > 0 else CD
        if op == "overlap": return max(0, min(x["high_a"], x["high_b"]) - max(x["low_a"], x["low_b"]))
        if op == "gap_up": return max(0, x["current_low"] - x["prior_high"])
        if op == "gap_down": return max(0, x["prior_low"] - x["current_high"])
        if op == "midpoint": return [x["low_ticks"] + x["high_ticks"], 2]
        if op == "range_position":
            d = x["range_high"] - x["range_low"]
            return [x["price_ticks"] - x["range_low"], d] if d > 0 else CD
        if op == "cross_up":
            return x["prior_close"] <= x["boundary"] + x["tolerance"] and x["current_close"] > x["boundary"] + x["tolerance"]
        if op == "cross_down":
            return x["prior_close"] >= x["boundary"] - x["tolerance"] and x["current_close"] < x["boundary"] - x["tolerance"]
        if op == "reclaim":
            return x["close_ticks"] <= x["boundary"] + x["tolerance"] if x["direction"] == "UP" else x["close_ticks"] >= x["boundary"] - x["tolerance"]
        if op == "retracement":
            impulse = abs(x["impulse_end"] - x["impulse_start"])
            return [abs(x["pullback_end"] - x["impulse_end"]), impulse] if impulse else CD
        if op == "measured_move":
            d = abs(x["segment_end"] - x["segment_start"])
            return x["projection_anchor"] + d if x["direction"] == "UP" else x["projection_anchor"] - d
        if op == "channel_projection":
            return x["line_value_at_t"] + x["translation_ticks"] if x["direction"] == "UP" else x["line_value_at_t"] - x["translation_ticks"]
        if op == "equal_ticks":
            return INVALID if x["tolerance"] < 0 else abs(x["a_ticks"] - x["b_ticks"]) <= x["tolerance"]
        if op == "window_high":
            a, b, v = x["start_index"], x["end_index"], x["confirmed_high_ticks"]
            return max(v[a:b+1]) if 0 <= a <= b < len(v) else CD
        if op == "window_low":
            a, b, v = x["start_index"], x["end_index"], x["confirmed_low_ticks"]
            return min(v[a:b+1]) if 0 <= a <= b < len(v) else CD
        if op == "sequential_count": return sum(1 for e in x["event_classes"] if e == x["target_class"])
        if op == "pivot_known":
            i = x["candidate_index"] + x["right_confirmation_bars"]
            return x["bar_known_at"][i] if 0 <= i < len(x["bar_known_at"]) else CD
        if op == "parent_known": return x["parent_finality"] == "CONFIRMED" and x["parent_known_at"] <= x["evaluation_time"]
        if op == "parameter_resolve":
            for key in ("caller_value", "profile_value", "authoritative_default"):
                if x.get(key) is not None: return x[key]
            return CD
        if op == "variant_resolve":
            if x.get("requested_variant") is not None:
                return x["result_by_variant"].get(x["requested_variant"], CD)
            vals = [x["result_by_variant"].get(v, CD) for v in x["supported_variants"]]
            return vals[0] if vals and all(v == vals[0] for v in vals) else "VARIANT_CONFLICT"
    except (KeyError, TypeError, ValueError, ArithmeticError):
        return CD
    raise ValueError(f"unknown operation {op}")


def main():
    data = yaml.safe_load((ROOT / "assets/semantic-fixtures.yaml").read_text())
    catalog = yaml.safe_load((ROOT / "assets/formula-catalog.yaml").read_text())
    formulas = {x["formula_or_procedure_id"]:x for x in catalog["formula_procedures"]}
    formula_ids = set(formulas)
    vectors = [x for x in data["fixtures"] if x["fixture_type"] == "MATH_GOLDEN"]
    errors = []
    seen = set()
    for row in vectors:
        fid = row["formula_or_procedure_id"]
        if fid not in formula_ids: errors.append(f"unknown formula {fid}"); continue
        if row.get("operation") != formulas[fid].get("operation_id"):
            errors.append(f"{row['fixture_id']}: operation does not match canonical formula operation_id"); continue
        actual = calculate(row["operation"], row["input"])
        if actual != row["expected_result"]: errors.append(f"{row['fixture_id']}: actual={actual!r} expected={row['expected_result']!r}")
        seen.add(fid)
    missing = formula_ids - seen
    if missing: errors.append("formulas without executed golden vectors: " + ", ".join(sorted(missing)))
    if errors:
        print("MATH CONTRACT: FAIL")
        for e in errors: print("FAIL:", e)
        return 2
    print(f"MATH CONTRACT: PASS ({len(vectors)} executable vectors; {len(formula_ids)} contracts)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
